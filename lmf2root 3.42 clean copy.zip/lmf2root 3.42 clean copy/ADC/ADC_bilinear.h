#ifndef __ADC_bilinear_h_
#define __ADC_bilinear_h_

#pragma warning(disable : 4800)

#include <math.h>

//struct Entry {
//	double	val;
//	int		nbr;
//	double	error;
//};

#include "ADC_trilinear.h"


#endif