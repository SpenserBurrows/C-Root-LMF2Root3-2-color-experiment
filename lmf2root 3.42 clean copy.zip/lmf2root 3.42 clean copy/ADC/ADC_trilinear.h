#ifndef __ADC_trilinear_h_
#define __ADC_trilinear_h_

#pragma warning(disable : 4800)

#include <math.h>



#endif