#pragma warning(disable : 4996)
#include "CH_Ranges.h"

namespace CH 
{

	range_class::range_class() {
	//	this->range_map_from = new double[NUM_PARTICLE_TYPES][NUM_VARS_MAX];
	//	this->range_map_to = new double[NUM_PARTICLE_TYPES][NUM_VARS_MAX];
	//	this->range_map_bins = new int[NUM_PARTICLE_TYPES][NUM_VARS_MAX];
		prepare_tags();
		init_default_values();
	}

	range_class::~range_class() {
	//	delete this->range_map_from;
	//	delete this->range_map_to;
	//	delete this->range_map_bins;
	}

	void range_class::prepare_tags() {
		// particle types
		for(int i=0;i<16;i++)
			this->particle_types.push_back("ELECTRON");	
		for(int i=0;i<16;i++)
			this->particle_types.push_back("ION");
		this->particle_types.push_back("PROJECTILE");
		this->particle_types.push_back("DIATOMIC");
		this->particle_types.push_back("POLYATOMIC");

		//single particle variables
		this->single_vars.push_back("TOF");
		this->single_vars.push_back("P");
		this->single_vars.push_back("PX");
		this->single_vars.push_back("PY");
		this->single_vars.push_back("PZ");
		this->single_vars.push_back("ENERGY");
		this->single_vars.push_back("PHILAB");
		this->single_vars.push_back("CTELAB");
		
		// diatomic molecule variables
		this->diatomic_vars.push_back("PREL");
		this->diatomic_vars.push_back("PRELX");
		this->diatomic_vars.push_back("PRELY");
		this->diatomic_vars.push_back("PRELZ");
		this->diatomic_vars.push_back("PCM");
		this->diatomic_vars.push_back("PCMX");
		this->diatomic_vars.push_back("PCMY");
		this->diatomic_vars.push_back("PCMZ");
		this->diatomic_vars.push_back("KER");

		// polyatomic molecule variables
		this->polyatomic_vars.push_back("PCM");
		this->polyatomic_vars.push_back("PCMX");
		this->polyatomic_vars.push_back("PCMY");
		this->polyatomic_vars.push_back("PCMZ");
		this->polyatomic_vars.push_back("KER");
	
	}

	void range_class::init_default_values() {
		// electrons
		for(int i=0;i<16;i++) {
			this->range_map_from[RA_ELECTRON+i][TOF] = 0.0;
			this->range_map_from[RA_ELECTRON+i][P] = 0.0;
			this->range_map_from[RA_ELECTRON+i][PX] = -2.0;
			this->range_map_from[RA_ELECTRON+i][PY] = -2.0;
			this->range_map_from[RA_ELECTRON+i][PZ] = -2.0;
			this->range_map_from[RA_ELECTRON+i][ENERGY] = 0.0;
			this->range_map_from[RA_ELECTRON+i][PHILAB] = -180.0;
			this->range_map_from[RA_ELECTRON+i][CTELAB] = -1.0;

			this->range_map_to[RA_ELECTRON+i][TOF] = 125.0;
			this->range_map_to[RA_ELECTRON+i][P] = 2.0;
			this->range_map_to[RA_ELECTRON+i][PX] = 2.0;
			this->range_map_to[RA_ELECTRON+i][PY] = 2.0;
			this->range_map_to[RA_ELECTRON+i][PZ] = 2.0;
			this->range_map_to[RA_ELECTRON+i][ENERGY] = 20.0;
			this->range_map_to[RA_ELECTRON+i][PHILAB] = 180.0;
			this->range_map_to[RA_ELECTRON+i][CTELAB] = 1.0;

			this->range_map_bins[RA_ELECTRON+i][TOF] = 250;
			this->range_map_bins[RA_ELECTRON+i][P] = 100;
			this->range_map_bins[RA_ELECTRON+i][PX] = 100;
			this->range_map_bins[RA_ELECTRON+i][PY] = 100;
			this->range_map_bins[RA_ELECTRON+i][PZ] = 100;
			this->range_map_bins[RA_ELECTRON+i][ENERGY] = 100;
			this->range_map_bins[RA_ELECTRON+i][PHILAB] = 72;
			this->range_map_bins[RA_ELECTRON+i][CTELAB] = 72;

			// ions
			this->range_map_from[RA_ION+i][TOF] = 0.0;
			this->range_map_from[RA_ION+i][P] = 0.0;
			this->range_map_from[RA_ION+i][PX] = -10.0;
			this->range_map_from[RA_ION+i][PY] = -10.0;
			this->range_map_from[RA_ION+i][PZ] = -10.0;
			this->range_map_from[RA_ION+i][ENERGY] = 0.0;
			this->range_map_from[RA_ION+i][PHILAB] = -180.0;
			this->range_map_from[RA_ION+i][CTELAB] = -1.0;

			this->range_map_to[RA_ION+i][TOF] = 8000.0;
			this->range_map_to[RA_ION+i][P] = 10.0;
			this->range_map_to[RA_ION+i][PX] = 10.0;
			this->range_map_to[RA_ION+i][PY] = 10.0;
			this->range_map_to[RA_ION+i][PZ] = 10.0;
			this->range_map_to[RA_ION+i][ENERGY] = 0.1;
			this->range_map_to[RA_ION+i][PHILAB] = 180.0;
			this->range_map_to[RA_ION+i][CTELAB] = 1.0;

			this->range_map_bins[RA_ION+i][TOF] = 4000;
			this->range_map_bins[RA_ION+i][P] = 50;
			this->range_map_bins[RA_ION+i][PX] = 50;
			this->range_map_bins[RA_ION+i][PY] = 50;
			this->range_map_bins[RA_ION+i][PZ] = 50;
			this->range_map_bins[RA_ION+i][ENERGY] = 50;
			this->range_map_bins[RA_ION+i][PHILAB] = 72;
			this->range_map_bins[RA_ION+i][CTELAB] = 72;
		}

		// projectile
		this->range_map_from[RA_PROJECTILE][TOF] = 0.0;
		this->range_map_from[RA_PROJECTILE][P] = 0.0;
		this->range_map_from[RA_PROJECTILE][PX] = -1.0;
		this->range_map_from[RA_PROJECTILE][PY] = -1.0;
		this->range_map_from[RA_PROJECTILE][PZ] = -1.0;
		this->range_map_from[RA_PROJECTILE][ENERGY] = 0.0;
		this->range_map_from[RA_PROJECTILE][PHILAB] = -180.0;
		this->range_map_from[RA_PROJECTILE][CTELAB] = -1.0;

		this->range_map_to[RA_PROJECTILE][TOF] = 8000.0;
		this->range_map_to[RA_PROJECTILE][P] = 1.0;
		this->range_map_to[RA_PROJECTILE][PX] = 1.0;
		this->range_map_to[RA_PROJECTILE][PY] = 1.0;
		this->range_map_to[RA_PROJECTILE][PZ] = 1.0;
		this->range_map_to[RA_PROJECTILE][ENERGY] = 0.1;
		this->range_map_to[RA_PROJECTILE][PHILAB] = 180.0;
		this->range_map_to[RA_PROJECTILE][CTELAB] = 1.0;

		this->range_map_bins[RA_PROJECTILE][TOF] = 4000;
		this->range_map_bins[RA_PROJECTILE][P] = 50;
		this->range_map_bins[RA_PROJECTILE][PX] = 50;
		this->range_map_bins[RA_PROJECTILE][PY] = 50;
		this->range_map_bins[RA_PROJECTILE][PZ] = 50;
		this->range_map_bins[RA_PROJECTILE][ENERGY] = 50;
		this->range_map_bins[RA_PROJECTILE][PHILAB] = 72;
		this->range_map_bins[RA_PROJECTILE][CTELAB] = 72;

		// diatomic molecule
		this->range_map_from[RA_DIATOMIC][PREL] = 0.0;
		this->range_map_from[RA_DIATOMIC][PRELX] = -200.0;
		this->range_map_from[RA_DIATOMIC][PRELY] = -200.0;
		this->range_map_from[RA_DIATOMIC][PRELZ] = -200.0;
		this->range_map_from[RA_DIATOMIC][PCM] = 0.0;
		this->range_map_from[RA_DIATOMIC][PCMX] = -20.0;
		this->range_map_from[RA_DIATOMIC][PCMY] = -20.0;
		this->range_map_from[RA_DIATOMIC][PCMZ] = -20.0;
		this->range_map_from[RA_DIATOMIC][KINER] = 0.0;

		this->range_map_to[RA_DIATOMIC][PREL] = 200.0;
		this->range_map_to[RA_DIATOMIC][PRELX] = 200.0;
		this->range_map_to[RA_DIATOMIC][PRELY] = 200.0;
		this->range_map_to[RA_DIATOMIC][PRELZ] = 200.0;
		this->range_map_to[RA_DIATOMIC][PCM] = 20.0;
		this->range_map_to[RA_DIATOMIC][PCMX] = 20.0;
		this->range_map_to[RA_DIATOMIC][PCMY] = 20.0;
		this->range_map_to[RA_DIATOMIC][PCMZ] = 20.0;
		this->range_map_to[RA_DIATOMIC][KINER] = 20.0;

		this->range_map_bins[RA_DIATOMIC][PREL] = 200;
		this->range_map_bins[RA_DIATOMIC][PRELX] = 200;
		this->range_map_bins[RA_DIATOMIC][PRELY] = 200;
		this->range_map_bins[RA_DIATOMIC][PRELZ] = 200;
		this->range_map_bins[RA_DIATOMIC][PCM] = 100;
		this->range_map_bins[RA_DIATOMIC][PCMX] = 100;
		this->range_map_bins[RA_DIATOMIC][PCMY] = 100;
		this->range_map_bins[RA_DIATOMIC][PCMZ] = 100;
		this->range_map_bins[RA_DIATOMIC][KINER] = 40;

		// polyatomic molecule

		this->range_map_from[RA_POLYATOMIC][P_PCM] = 0.0;
		this->range_map_from[RA_POLYATOMIC][P_PCMX] = -20.0;
		this->range_map_from[RA_POLYATOMIC][P_PCMY] = -20.0;
		this->range_map_from[RA_POLYATOMIC][P_PCMZ] = -20.0;
		this->range_map_from[RA_POLYATOMIC][P_KINER] = 0.0;

		this->range_map_to[RA_POLYATOMIC][P_PCM] = 20.0;
		this->range_map_to[RA_POLYATOMIC][P_PCMX] = 20.0;
		this->range_map_to[RA_POLYATOMIC][P_PCMY] = 20.0;
		this->range_map_to[RA_POLYATOMIC][P_PCMZ] = 20.0;
		this->range_map_to[RA_POLYATOMIC][P_KINER] = 20.0;

		this->range_map_bins[RA_POLYATOMIC][P_PCM] = 100;
		this->range_map_bins[RA_POLYATOMIC][P_PCMX] = 100;
		this->range_map_bins[RA_POLYATOMIC][P_PCMY] = 100;
		this->range_map_bins[RA_POLYATOMIC][P_PCMZ] = 100;
		this->range_map_bins[RA_POLYATOMIC][P_KINER] = 40;
	}

	double range_class::get_from(int particle_type, int var) {
		return this->range_map_from[particle_type][var];
	}

	double range_class::get_to(int particle_type, int var) {
		return this->range_map_to[particle_type][var];
	}

	int range_class::get_bins(int particle_type, int var) {
		return this->range_map_bins[particle_type][var];
	}

	void range_class::set_from(int particle_type, int var, double val) {
		this->range_map_from[particle_type][var] = val;
	}

	void range_class::set_to(int particle_type, int var, double val) {
		this->range_map_to[particle_type][var] = val;
	}

	void range_class::set_bins(int particle_type, int var, int val) {
		this->range_map_bins[particle_type][var] = val;
	}

	void range_class::set_all(int particle_type, int var, int bins, double from, double to) {
		this->range_map_bins[particle_type][var] = bins;
		this->range_map_from[particle_type][var] = from;
		this->range_map_to[particle_type][var] = to;
	}

	void range_class::pass_on(int particle_type, int var, int bins, double from, double to) {
		
		// single particles
		if(particle_type < RA_PROJECTILE) {
			switch (var) {
			case P:
				set_all(particle_type, PX, bins, -to, to);
				set_all(particle_type, PY, bins, -to, to);
				set_all(particle_type, PZ, bins, -to, to);
				//set_all(particle_type, ENERGY, bins, from, to);				
			//case ENERGY:
				//set_all(particle_type, P, bins, from, to);
				//set_all(particle_type, PX, bins, -to, to);
				//set_all(particle_type, PY, bins, -to, to);
				//set_all(particle_type, PZ, bins, -to, to);
			}
		}
	}
}
