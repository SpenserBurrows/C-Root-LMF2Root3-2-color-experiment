#include "CH_Histograms.h"

namespace CH
{
	void histograms_class::plot_electrons(reaction_struct *cur_reaction, electron_class ** e, int ehit, double *scan_val) 
	{
		histo_handler *Hist = this->Hist_e;
		range_class *rg = cur_reaction->rng;
		int rgt = RA_ELECTRON;

		// limit to 16 hits.. 
		if(ehit>15)
			ehit=15;

		// histogram index stuff
		int hmax = HISTS_PER_CHANNEL; // overall number of ColAHelL histograms per reaction/channel
		int hoff = hmax*15*(int)cur_reaction->reac_num;

		char reaction_dir[360];
//		char x_axis_title[80];
//		char y_axis_title[80];
		char rootdir[360];
		char ndir[360];
		char tdir[360];

		if(this->use_master_folder) {
			strcpy(reaction_dir,this->CH_master_folder);
			strcat(reaction_dir,cur_reaction->name);
		} else
			strcpy(reaction_dir,cur_reaction->name);		

		strcpy(rootdir,reaction_dir);
		strcat(rootdir,"/electrons");

		for(int i=0;i<(int)ehit;i++) {
			
			strcpy(ndir,rootdir);
			sprintf(tdir,"/hit_%i",i);
			strcat(ndir,tdir);
			strcpy(tdir,ndir);
		
			if(e[i]->valid) {

				// fill standard histograms
				Hist->fill(hoff+hmax*i+0,"electron_energy",e[i]->energy(),1.,"electron energy",rg->get_bins(rgt+i,ENERGY),rg->get_from(rgt+i,ENERGY),rg->get_to(rgt+i,ENERGY),"electron energy [eV]",strcat(ndir,"/energy"));
				Hist->fill(hoff+hmax*i+1,"phi_vs_electron_energy",e[i]->raw.phi,e[i]->energy(),1.,"electron energy vs. phi on detector",rg->get_bins(rgt+i,PHILAB),rg->get_from(rgt+i,PHILAB),rg->get_to(rgt+i,PHILAB),"phi [deg]",rg->get_bins(rgt+i,ENERGY),rg->get_from(rgt+i,ENERGY),rg->get_to(rgt+i,ENERGY),"electron energy [eV]",ndir); 
				Hist->fill(hoff+hmax*i+2,"ctheta_vs_electron_energy",e[i]->mom.Cos_Theta(),e[i]->energy(),1.,"electron energy vs. cos(theta_z)",rg->get_bins(rgt+i,CTELAB),rg->get_from(rgt+i,CTELAB),rg->get_to(rgt+i,CTELAB),"ctheta",rg->get_bins(rgt+i,ENERGY),rg->get_from(rgt+i,ENERGY),rg->get_to(rgt+i,ENERGY),"electron energy [eV]",ndir); 
				
				strcpy(ndir,tdir);
				Hist->fill(hoff+hmax*i+3,"px_vs_py",e[i]->mom.x,e[i]->mom.y,1.,"p_x vs. p_y",rg->get_bins(rgt+i,PX),rg->get_from(rgt+i,PX),rg->get_to(rgt+i,PX),"p_x [a.u.]",rg->get_bins(rgt+i,PY),rg->get_from(rgt+i,PY),rg->get_to(rgt+i,PY),"p_y [a.u.]",strcat(ndir,"/momenta"));
				Hist->fill(hoff+hmax*i+4,"px_vs_pz",e[i]->mom.x,e[i]->mom.z,1.,"p_x vs. p_z",rg->get_bins(rgt+i,PX),rg->get_from(rgt+i,PX),rg->get_to(rgt+i,PX),"p_x [a.u.]",rg->get_bins(rgt+i,PZ),rg->get_from(rgt+i,PZ),rg->get_to(rgt+i,PZ),"p_z [a.u.]",ndir);
				Hist->fill(hoff+hmax*i+5,"py_vs_pz",e[i]->mom.y,e[i]->mom.z,1.,"p_y vs. p_z",rg->get_bins(rgt+i,PY),rg->get_from(rgt+i,PY),rg->get_to(rgt+i,PY),"p_y [a.u.]",rg->get_bins(rgt+i,PZ),rg->get_from(rgt+i,PZ),rg->get_to(rgt+i,PZ),"p_z [a.u.]",ndir);
				Hist->fill(hoff+hmax*i+6,"p_mag",e[i]->mom.Mag(),1.,"|p|",rg->get_bins(rgt+i,P),rg->get_from(rgt+i,P),rg->get_to(rgt+i,P),"|p| [a.u.]",ndir);

				strcpy(ndir,tdir);
				Hist->fill(hoff+hmax*i+7,"phi",e[i]->mom.Phi_deg(),1.,"phi in the labframe",rg->get_bins(rgt+i,PHILAB),rg->get_from(rgt+i,PHILAB),rg->get_to(rgt+i,PHILAB),"phi [deg]",strcat(ndir,"/angles_labframe"));
				Hist->fill(hoff+hmax*i+8,"ctheta",e[i]->mom.Cos_Theta(),1.,"cos(theta) in the labframe",rg->get_bins(rgt+i,CTELAB),rg->get_from(rgt+i,CTELAB),rg->get_to(rgt+i,CTELAB),"cos(theta)",ndir);
			
				// labframe frame ADs for beta etc.
				if(cur_reaction->LF_cond->type > -1) {

					if((e[i]->energy() > cur_reaction->LF_cond->emin) && (e[i]->energy() < cur_reaction->LF_cond->emax)) {
						CH_vector photon_dir = CH_vector(1.0,0.0,0);
						CH_vector pol_dir = CH_vector(0,1.0,0);
						CH_vector perp_dir = CH_vector(0,0,1.0);

						Coordinate_System lf = Coordinate_System(photon_dir,pol_dir);
						CH_vector e_LF;
						e_LF = lf.project_vector(e[i]->mom);

						strcat(ndir,"/photo-electron");

						switch(cur_reaction->LF_cond->type) { 						
						case 0: // linear light 
							Hist->fill(hoff+hmax*i+9,"ctheta to pol (dipole)",cos(e[i]->mom.Angle(pol_dir)),1.,"ctheta /w resp. to light propagation",72,-1.0,1.0,"phi [deg]",ndir);	
							// We need to restrict to cases where we are in the plane photon_dir x pol_dir
							if(fabs(e[i]->mom.Angle_deg(perp_dir)-90.0)<20.0) {
								Hist->fill(hoff+hmax*i+10,"ctheta to light (non-dipole)",cos(e[i]->mom.Angle(photon_dir)),1.,"ctheta /w resp. to light propagation",72,-1.0,1.0,"phi [deg]",ndir);	
							}
							break;					
						case 1: // circular light
							// We can integrate over all planes which include the photon_dir
							//Hist->fill(hoff+hmax*i+11,"ctheta to light",cos(e[i]->mom.Angle(photon_dir)),1.,"cos(theta) /w resp. to light propagation",36,-1.0,1.0,"cos(theta)",ndir);
							Hist->fill(hoff + hmax*i + 11, "ctheta to light vs ee", cos(e[i]->mom.Angle(photon_dir)), e[i]->energy(), 1., "cos(theta) /w resp. to light propagation vs electron energy [eV]", 36, -1.0, 1.0, "cos(theta)", 100, 0.0, 15.0, "electron energy [eV]", ndir);
							break;
						}
						Hist->fill(hoff+hmax*i+12,"LFAD3D",e_LF.Phi_deg(),e_LF.Cos_Theta(),1.,"phi vs. cos(theta) in the photon frame",72,-180.0,180.0,"phi [deg]",72,-1.0,1.0,"cos(theta)",ndir);
					}
				}

				strcpy(ndir,tdir);
				Hist->fill(hoff+hmax*i+13,"px_vs_tof(valid)",e[i]->raw.data.tof,e[i]->mom.x,1.,"B-check x",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",rg->get_bins(rgt+i,PX),rg->get_from(rgt+i,PX),rg->get_to(rgt+i,PX),"p_x [a.u.]",strcat(ndir,"/raw/B-orientation"));
				Hist->fill(hoff+hmax*i+14,"py_vs_tof(valid)",e[i]->raw.data.tof,e[i]->mom.y,1.,"B-check y",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",rg->get_bins(rgt+i,PY),rg->get_from(rgt+i,PY),rg->get_to(rgt+i,PY),"p_y [a.u.]",ndir);
			}

			strcpy(ndir,tdir);
			Hist->fill(hoff+hmax*i+15,"position",e[i]->raw.data.x,e[i]->raw.data.y,1.,"position",400,-1.*edet_size,edet_size,"x [mm]",400,-1.*edet_size,edet_size,"y [mm]",strcat(ndir,"/raw"));
			Hist->fill(hoff+hmax*i+16,"tof",e[i]->raw.data.tof,1.,"time-of-flight",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",ndir);
			Hist->fill(hoff+hmax*i+17,"wiggle",e[i]->raw.data.tof,(sqrt(e[i]->raw.data.x*e[i]->raw.data.x+e[i]->raw.data.y*e[i]->raw.data.y)),1.,"wiggles",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",200,-1.,edet_size,"r [mm]",ndir);
			Hist->fill(hoff+hmax*i+18,"fish_x",e[i]->raw.data.tof,e[i]->raw.data.x,1.,"x-fish",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",200,-1.*edet_size,edet_size,"x [mm]",ndir);
			Hist->fill(hoff+hmax*i+19,"fish_y",e[i]->raw.data.tof,e[i]->raw.data.y,1.,"y-fish",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",200,-1.*edet_size,edet_size,"y [mm]",ndir);
			if ( fabs(e[i]->raw.data.y)<10. ) 
				Hist->fill(hoff+hmax*i+20,"fish_filet_x",e[i]->raw.data.tof,e[i]->raw.data.x,1.,"x-fish filet",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",200,-1.*edet_size,edet_size,"x [mm]",ndir);
			if ( fabs(e[i]->raw.data.x)<10. ) 
				Hist->fill(hoff+hmax*i+21,"fish_filet_y",e[i]->raw.data.tof,e[i]->raw.data.y,1.,"y-fish filet",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",200,-1.*edet_size,edet_size,"y [mm]",ndir);
			
			strcpy(ndir,tdir);
			Hist->fill(hoff+hmax*i+22,"px_vs_tof(all)",e[i]->raw.data.tof,e[i]->mom.x,1.,"B-check x",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",rg->get_bins(rgt+i,PX),rg->get_from(rgt+i,PX),rg->get_to(rgt+i,PX),"p_x [a.u.]",strcat(ndir,"/raw/B-orientation"));
			Hist->fill(hoff+hmax*i+23,"py_vs_tof(all)",e[i]->raw.data.tof,e[i]->mom.y,1.,"B-check y",rg->get_bins(rgt+i,TOF),rg->get_from(rgt+i,TOF),rg->get_to(rgt+i,TOF),"tof [ns]",rg->get_bins(rgt+i,PY),rg->get_from(rgt+i,PY),rg->get_to(rgt+i,PY),"p_y [a.u.]",ndir);			
		}
			
		Hist->fill(hoff+hmax+24,"ehit",ehit,1.,"number of hits electron",43,-1.25,20.25,"number of hits",rootdir);

		// electron multihit histograms 
		int e1 = 0;
		int e2 = 0;
		bool twoelec = false;
		CH_vector pesum;
		if(cur_reaction->two_elec) {
			strcpy(ndir,rootdir);
			sprintf(tdir,"/coincidence");
			strcat(ndir,tdir);
			strcpy(tdir,ndir);

			// look for first electron
			for(int i=0;i<ehit;i++) {
				if(e[i]->valid) {
					if(e[i]->energy()>cur_reaction->e_master_min && e[i]->energy()<cur_reaction->e_master_max) {
						e1 = i;
						twoelec = true;
						break;
					}
				}
			}
			// look for second electron
			if(twoelec) {
				twoelec = false;
				for(int i=0;i<ehit;i++) {
					if(e[i]->valid && i!=e1) {
						e2 = i;
						twoelec = true;
						break;
					}
				}
			}
	
			if(twoelec) {
				Hist->fill(hoff+hmax*15+25,"electron_energy_1_vs_2",e[e1]->energy(),e[e2]->energy(),1.0,"electron energy 1st electron vs. 2nd electron",rg->get_bins(rgt,ENERGY),rg->get_from(rgt,ENERGY),rg->get_to(rgt,ENERGY),"energy electron 1 [eV]",rg->get_bins(rgt,ENERGY),rg->get_from(rgt,ENERGY),rg->get_to(rgt,ENERGY),"energy electron 2 [eV]",ndir);
				Hist->fill(hoff+hmax*15+26,"electron_energy_1_vs_2_sym",e[e1]->energy(),e[e2]->energy(),0.5,"electron energy 1st electron vs. 2nd electron",rg->get_bins(rgt,ENERGY),rg->get_from(rgt,ENERGY),rg->get_to(rgt,ENERGY),"energy electron 1 [eV]",rg->get_bins(rgt,ENERGY),rg->get_from(rgt,ENERGY),rg->get_to(rgt,ENERGY),"energy electron 2 [eV]",ndir);
				Hist->fill(hoff+hmax*15+26,"electron_energy_1_vs_2_sym",e[e2]->energy(),e[e1]->energy(),0.5,"electron energy 1st electron vs. 2nd electron",rg->get_bins(rgt,ENERGY),rg->get_from(rgt,ENERGY),rg->get_to(rgt,ENERGY),"energy electron 1 [eV]",rg->get_bins(rgt,ENERGY),rg->get_from(rgt,ENERGY),rg->get_to(rgt,ENERGY),"energy electron 2 [eV]",ndir);

				Hist->fill(hoff+hmax*15+27,"energy_sharing",e[e1]->energy()/(e[e1]->energy() + e[e2]->energy()),0.5,"electron energy sharing",50,0.0,1.0,"energy sharing",ndir);
				Hist->fill(hoff+hmax*15+27,"energy_sharing",e[e2]->energy()/(e[e1]->energy() + e[e2]->energy()),0.5,"electron energy sharing",50,0.0,1.0,"energy sharing",ndir);	

				if(cur_reaction->e_master_min<0.0) {
					Hist->fill(hoff+hmax*15+28,"energy_sharing_vs_ctheta",cos(e[e1]->mom.Angle(e[e2]->mom)),e[e1]->energy()/(e[e1]->energy() + e[e2]->energy()),0.5,"electron energy sharing vs. angle between electrons",36,-1.0,1.0,"cos(theta_e1_e2)",50,0.0,1.0,"energy sharing",ndir);
					Hist->fill(hoff+hmax*15+28,"energy_sharing_vs_ctheta",cos(e[e2]->mom.Angle(e[e1]->mom)),e[e2]->energy()/(e[e1]->energy() + e[e2]->energy()),0.5,"electron energy sharing vs. angle between electrons",36,-1.0,1.0,"cos(theta_e1_e2)",50,0.0,1.0,"energy sharing",ndir);	
				} else {
					Hist->fill(hoff+hmax*15+29,"energy_sharing_vs_ctheta",cos(e[e2]->mom.Angle(e[e1]->mom)),e[e2]->energy()/(e[e1]->energy() + e[e2]->energy()),0.5,"electron energy sharing vs. angle between electrons",36,-1.0,1.0,"cos(theta_e1_e2)",50,0.0,1.0,"energy sharing",ndir);	
				}

				Hist->fill(hoff+hmax*15+30,"electron_sum_energy",e[e1]->energy()+e[e2]->energy(),1.0,"electron sum energy",rg->get_bins(rgt,ENERGY),rg->get_from(rgt,ENERGY),2*rg->get_to(rgt,ENERGY),"energy sum electron [eV]",ndir);

				strcpy(ndir,tdir);
				pesum = e[e1]->mom + e[e2]->mom;
				Hist->fill(hoff+hmax*15+31,"p_sumx_vs_p_sumy",pesum.x,pesum.y,1.,"p_sum_x vs. p_sum_y",90,-1.5,1.5,"p_sum_x [a.u.]",90,-1.5,1.5,"p_sum_y [a.u.]",strcat(ndir,"/electron sum momenta"));
				Hist->fill(hoff+hmax*15+32,"p_sumx_vs_p_sumz",pesum.x,pesum.z,1.,"p_sum_x vs. p_sum_z",90,-1.5,1.5,"p_sum_x [a.u.]",90,-1.5,1.5,"p_sum_z [a.u.]",ndir);
				Hist->fill(hoff+hmax*15+33,"p_sumy_vs_p_sumz",pesum.y,pesum.z,1.,"p_sum_y vs. p_sum_z",90,-1.5,1.5,"p_sum_y [a.u.]",90,-1.5,1.5,"p_sum_z [a.u.]",ndir);				
				Hist->fill(hoff+hmax*15+34,"p_sum",pesum.Mag(),1.,"|p_sum|",50,0.0,2.5,"|p_sum| [a.u.]",ndir);

				strcpy(ndir,tdir);
				// Create Newton/elec frame plots 
				Coordinate_System eframe = Coordinate_System(e[e1]->mom, e[e2]->mom);
				CH_vector eFrame_mom;
				eFrame_mom = eframe.project_vector(e[2]->mom);
				Hist->fill(hoff+hmax*15+35,"electron_frame_norm._all",eFrame_mom.z/e[e1]->mom.Mag(),eFrame_mom.x/e[e1]->mom.Mag(),1.,"p_e2 relative to p_e1 (normalized to e1)",80,-2.5,1.5,"pz",60,0.0,3.0,"py",strcat(ndir,"/relative momenta"));
				if(e[e1]->energy()/(e[e1]->energy() + e[e2]->energy())<0.25)
					Hist->fill(hoff+hmax*15+36,"electron_frame_norm._slow",eFrame_mom.z/e[e1]->mom.Mag(),eFrame_mom.x/e[e1]->mom.Mag(),1.,"p_e2 relative to p_e1 (norm. to e1), e1 slow",80,-2.5,1.5,"pz",60,0.0,3.0,"py",ndir);
				if(e[e1]->energy()/(e[e1]->energy() + e[e2]->energy())>0.25 && e[e1]->energy()/(e[e1]->energy() + e[e2]->energy())<0.75)
					Hist->fill(hoff+hmax*15+37,"electron_frame_norm._mid",eFrame_mom.z/e[e1]->mom.Mag(),eFrame_mom.x/e[e1]->mom.Mag(),1.,"p_e2 relative to p_e1 (norm. to e1), ee1=ee2",80,-2.5,1.5,"pz",60,0.0,3.0,"py",ndir);
				if(e[e1]->energy()/(e[e1]->energy() + e[e2]->energy())>0.75)
					Hist->fill(hoff+hmax*15+38,"electron_frame_norm._fast",eFrame_mom.z/e[e1]->mom.Mag(),eFrame_mom.x/e[e1]->mom.Mag(),1.,"p_e2 relative to p_e1 (norm. to e1), e1 fast",80,-2.5,1.5,"pz",60,0.0,3.0,"py",ndir);
	
				Hist->fill(hoff+hmax*15+39,"electron_frame_all",eFrame_mom.z,eFrame_mom.x,1.,"p_e2 relative to p_e1",80,-2.5,1.5,"pz",60,0.0,3.0,"py",ndir);
				if(e[e1]->energy()/(e[e1]->energy() + e[e2]->energy())<0.25)
					Hist->fill(hoff+hmax*15+40,"electron_frame_slow",eFrame_mom.z,eFrame_mom.x,1.,"p_e2 relative to p_e1, e1 slow",80,-2.5,1.5,"pz",60,0.0,3.0,"py",ndir);
				if(e[e1]->energy()/(e[e1]->energy() + e[e2]->energy())>0.25 && e[e1]->energy()/(e[e1]->energy() + e[e2]->energy())<0.75)
					Hist->fill(hoff+hmax*15+41,"electron_frame_mid",eFrame_mom.z,eFrame_mom.x,1.,"p_e2 relative to p_e1, ee1=ee2",80,-2.5,1.5,"pz",60,0.0,3.0,"py",ndir);
				if(e[e1]->energy()/(e[e1]->energy() + e[e2]->energy())>0.75)
					Hist->fill(hoff+hmax*15+42,"electron_frame_fast",eFrame_mom.z,eFrame_mom.x,1.,"p_e2 relative to p_e1, e1 fast",80,-2.5,1.5,"pz",60,0.0,3.0,"py",ndir);

				strcpy(ndir,tdir);
				Hist->fill(hoff+hmax*15+43,"dt_vs_dx",e[e2]->raw.data.time-e[e1]->raw.data.time,e[e2]->raw.data.x-e[e1]->raw.data.x,1.,"Multihit check dt vs. dx",88,-2.0,20,"dt [ns]",120,-30.0,30.0,"dx [mm]",strcat(ndir,"/multihit checks"));
				Hist->fill(hoff+hmax*15+44,"dt_vs_dy",e[e2]->raw.data.time-e[e1]->raw.data.time,e[e2]->raw.data.y-e[e1]->raw.data.y,1.,"Multihit check dt vs. dy",88,-2.0,20,"dt [ns]",120,-30.0,30.0,"dy [mm]",ndir);
				double dR=sqrt(pow((e[e2]->raw.data.x - e[e1]->raw.data.x),2)-pow((e[e2]->raw.data.y - e[e1]->raw.data.y),2)); 
				Hist->fill(hoff+hmax*15+45,"dt_vs_dR",e[e2]->raw.data.time-e[e1]->raw.data.time,dR,1.,"Multihit check dt vs. dR",88,-2.0,20,"dt [ns]",60,0.0,30.0,"dR [mm]",ndir);
			
				// two electron labframe frame ADs for beta etc.
				if (cur_reaction->LF_cond->type > -1) {
					strcpy(ndir, tdir);
					double esum = e[e1]->energy() + e[e2]->energy();
					CH_vector DiElec = e[e1]->mom + e[e2]->mom;
					if ((esum > cur_reaction->LF_cond->emin) && (esum < cur_reaction->LF_cond->emax)) {
						CH_vector photon_dir = CH_vector(1.0, 0.0, 0);
						CH_vector pol_dir = CH_vector(0, 1.0, 0);
						CH_vector perp_dir = CH_vector(0, 0, 1.0);

						Coordinate_System lf = Coordinate_System(photon_dir, pol_dir);
						CH_vector e_LF;
						e_LF = lf.project_vector(DiElec);

						strcat(ndir, "/angles_labframe");

						switch (cur_reaction->LF_cond->type) {
						case 0: // linear light 
							Hist->fill(hoff + hmax*15 + 46, "phi_to_pol(dipole)", DiElec.Angle_deg(pol_dir), 1., "phi /w resp. to light propagation", 72, -180.0, 180.0, "phi [deg]", ndir);
							// We need to restrict to cases where we are in the plane photon_dir x pol_dir
							if (fabs(DiElec.Angle_deg(perp_dir))<20.0) {
								Hist->fill(hoff + hmax*15 + 47, "phi_to_light(non-dipole)", DiElec.Angle_deg(photon_dir), 1., "phi /w resp. to light propagation", 72, -180.0, 180.0, "phi [deg]", ndir);
							}
							break;
						case 1: // circular light
								// We can integrate over all planes which include the photon_dir
							Hist->fill(hoff + hmax*15 + 48, "ctheta_to_light", cos(DiElec.Angle(photon_dir)), 1., "cos(theta) /w resp. to light propagation", 24, -1.0, 1.0, "cos(theta)", ndir);
							break;
						}
						Hist->fill(hoff + hmax*15 + 49, "LFAD3D", e_LF.Phi_deg(), e_LF.Cos_Theta(), 1., "phi vs. cos(theta) in the photon frame", 36, -180.0, 180.0, "phi [deg]", 24, -1.0, 1.0, "cos(theta)", ndir);
					}
				}
			}
		}

		if(cur_reaction->photon_scan) {
			strcpy(ndir,reaction_dir);
			sprintf(tdir,"/photon_energy_scan/electrons");
			strcat(ndir,tdir);
			strcpy(tdir,ndir);

			int phbins = int((cur_reaction->ph_max - cur_reaction->ph_min)/cur_reaction->ph_step);
			
			// We will plot only the first valid electron here, so find it... 
			int i;
			for(i=0;i<(int)ehit;i++) {
				if(e[i]->valid)
				break;
			}

			Hist->fill(hoff+hmax*15+50,"hv_vs_p",scan_val[cur_reaction->ph_scan_channel],e[i]->mom.Mag(),1.,"Photon energy vs. |p|",phbins, cur_reaction->ph_min, cur_reaction->ph_max,"hv [eV]",rg->get_bins(rgt+i,P),rg->get_from(rgt+i,P),rg->get_to(rgt+i,P),"|p| [a.u.]",ndir);
			Hist->fill(hoff+hmax*15+51,"hv_vs_energy",scan_val[cur_reaction->ph_scan_channel],e[i]->energy(),1.,"Photon energy vs. electron energy",phbins, cur_reaction->ph_min, cur_reaction->ph_max,"hv [eV]",rg->get_bins(rgt+i,ENERGY),rg->get_from(rgt+i,ENERGY),rg->get_to(rgt+i,ENERGY),"electron energy [eV]",ndir);
			if(twoelec) {
				Hist->fill(hoff+hmax*15+52,"hv_vs_psum",scan_val[cur_reaction->ph_scan_channel],pesum.Mag(),1.,"Photon energy vs. |p|",phbins, cur_reaction->ph_min, cur_reaction->ph_max,"hv [eV]",50,0.0,2.5,"|psum| [a.u.]",ndir);
				Hist->fill(hoff+hmax*15+53,"hv_vs_electron_sum_energy",scan_val[cur_reaction->ph_scan_channel],e[e1]->energy()+e[e2]->energy(),1.,"Photon energy vs. electron sum energy",phbins, cur_reaction->ph_min, cur_reaction->ph_max,"hv [eV]",50,0.0,20.0,"electron sum energy [eV]",ndir);			
			}
		}
	}
}