#include "CH_particle.h"
#include "CH_Spectrometer.h"
#include "CH_Basics.h"
#include "CH_FUN_Lowlevel.h"

#include "Math.h"

namespace CH
{

	particle_class::particle_class()
	{
		this->raw.m = 0.0;
		this->raw.q = 0.0;
		this->channel = 0;
		this->valid = false;

		this->mom.x = -1000.0;
		this->mom.y = -1000.0;
		this->mom.z = -1000.0;

		this->cor.dt = 0.0;
		this->cor.dx = 0.0;
		this->cor.dy = 0.0;
		this->cor.overall_stretch = 1.0;
		this->cor.x_stretch = 1.0;
		this->cor.y_stretch = 1.0;

		this->t_mean = 0.0;
		this->t_width = -1.0;
	}

	particle_class::~particle_class()
	{
	}

	void particle_class::set_raw(particle_raw *rawdata) {
		this->raw.data = rawdata->data;
		this->raw.m = rawdata->m;
		this->raw.q = rawdata->q;
		this->raw.method = rawdata->method;
		this->raw.phi = rawdata->phi;
	}

	void particle_class::set_raw(double x, double y, double t, int method) {
		this->raw.data.x = x;
		this->raw.data.y = y;
		this->raw.data.tof = t;

		this->raw.phi = 0;
		this->raw.method = method;
	}

	void particle_class::calc_phi_pos() {
		this->raw.phi = atan2(this->raw.data.x, this->raw.data.y)/PI*180.0;
	}

	void particle_class::set_channel(int channel) {
		this->channel = channel;
	}

	void particle_class::set_channel(int channel, bool valid) {
		this->channel = channel;
		this->valid = valid;
	}
	void particle_class::set_valid(bool valid) {
		this->valid = valid;
	}

	void particle_class::set_t_mean(double t) {
		this->t_mean = t;
	}

	void particle_class::set_t_width(double t) {
		this->t_width = t;
	}

	void particle_class::shift_stretch_raw(cor_param * fac) {
		this->raw.data.x += fac->dx;
		this->raw.data.x *= fac->x_stretch;
		this->raw.data.x *= fac->overall_stretch;

		this->raw.data.y += fac->dy;
		this->raw.data.y *= fac->y_stretch;
		this->raw.data.y *= fac->overall_stretch;

		this->raw.data.tof += fac->dt;

		if(fac->mir_x)
			this->raw.data.x *= -1.0;
		if(fac->mir_y)
			this->raw.data.y *= -1.0;
	}

	void particle_class::shift_stretch_mom(mom_cor_param * fac) {
		this->mom.x += fac->dx;
		this->mom.y += fac->dy;
		this->mom.z += fac->dz;

		this->mom.x *= fac->x_stretch * fac->overall_stretch;
		this->mom.y *= fac->y_stretch * fac->overall_stretch;
		this->mom.z *= fac->z_stretch * fac->overall_stretch;

		if(fac->mir_x)
			this->mom.x *= -1.0;
		if(fac->mir_y)
			this->mom.y *= -1.0;
		if(fac->mir_z)
			this->mom.z *= -1.0;
	}

	void particle_class::rotate_raw(double ang) {
		ang = ang/180.*PI;

		double x_temp = cos(ang) * this->raw.data.x - sin(ang) * this->raw.data.y;
		double y_temp = sin(ang) * this->raw.data.x + cos(ang) * this->raw.data.y;
		this->raw.data.x = x_temp;
		this->raw.data.y = y_temp;
	}

	void particle_class::autotune() {

		int bins_phi = 36;
		int bins_ctheta = 30;
		double corr_tab[36][30];

		int pbin = (int)(((this->mom.Phi()+3.14152)/3.14152/2.0)*(bins_phi));
		if(pbin==bins_phi)
			pbin-=1;
		int ctbin = (int)((cos(this->mom.Theta())+1.0)/2.0*(bins_ctheta));
		
		// parabola-spline-interpolation (1D, in ctheta)
		// ---------------------------------------
		/*
		double ctbin_double = ((cos(this->mom.Theta())+1.0)/2.0*(bins_ctheta));
		double cfac = ps_get_y_at_x(corr_tab[pbin], bins_ctheta, ctbin_double);
		*/
		// bilinear-interpolation
		// ---------------------------------------
		/*
		double ctbin_double = ((cos(this->mom.Theta())+1.0)/2.0*(bins_ctheta));
		double pbin_double = (((this->mom.Phi()+3.14152)/3.14152/2.0)*(bins_phi));
		int x1 = pbin;
		int x2 = pbin + 1;
		int y1 = ctbin;
		int y2 = ctbin + 1;
		
		double cfac_lin1 =  ((double)x2 - pbin_double) * corr_tab[x1][y1] + (pbin_double - (double)x1) * corr_tab[x2 % bins_phi][y1];
		double cfac_lin2 =  ((double)x2 - pbin_double) * corr_tab[x1][y2] + (pbin_double - (double)x1) * corr_tab[x2 % bins_phi][y2];
		double cfac = ((double)y2 - ctbin_double) * cfac_lin1 + (ctbin_double - (double)y1) * cfac_lin2;
		*/
		// no interpolation
		// ---------------------------------------
		double cfac = corr_tab[pbin][ctbin]; 
		
		this->mom = this->mom * cfac;
	}

	void particle_class::process(spectrometer_class *spect) { //, const std::vector<std::vector<double>> &tofs_and_moms, const std::vector<double> & adjustment_coeff) {
		double x = this->raw.data.x;
		double y = this->raw.data.y;
		double t = this->raw.data.tof;

		// first correct raw data with individual correction parameters
		x += cor.dx;
		x *= cor.x_stretch;
		x *= cor.overall_stretch;

		y += cor.dy;
		y *= cor.y_stretch;
		y *= cor.overall_stretch;

		t += cor.dt;
		
		// include jet velocity for ions (angle is with respect to y-axis)
		if(this->raw.m >= 1.0) {
			double sh_vjet = spect->VJet * 1000.0 * t * 1e-9; 
			x -= sh_vjet * sin(spect->AngJet/180.0*PI);
			y -= sh_vjet * cos(spect->AngJet/180.0*PI);
		}

		// calculate momenta
		this->mom.x = calc_px(t, x, y, this->raw.m, this->raw.q, spect->Bfield_ns, spect->Bfield_clockwise);
		this->mom.y = calc_py(t, x, y, this->raw.m, this->raw.q, spect->Bfield_ns, spect->Bfield_clockwise);

		if(this->raw.m < 1.0) { 
			if(spect->electron_side->linear_approximation) 
				this->mom.z = spect->electron_side->Efields[0] * (t - spect->MeanTOFe) / 124.38;  
			else
				this->mom.z = - tof2mom_3accel(t, spect->electron_side->lengths[0], spect->electron_side->lengths[1], spect->electron_side->lengths[2], spect->electron_side->Efields[0], spect->electron_side->Efields[1], spect->electron_side->Efields[2], fabs(this->raw.q), this->raw.m);
		} else {
			if(spect->ion_side->linear_approximation) {	
				this->mom.z = - spect->ion_side->Efields[0] * this->raw.q * (t - this->t_mean) / 124.38;  // according to Markus' diploma thesis
			} 
/*			else if(spect->ion_side->interpolation_approximation ){
				if (tofs_and_moms.size() > 1) {
					this->mom.z = interpolation2mom(t, tofs_and_moms);
					this->mom.z = this->mom.z + adjustment_coeff[0] * x + adjustment_coeff[1] * (x*x) + adjustment_coeff[2] * y + adjustment_coeff[3] * (y*y) + adjustment_coeff[4] * sqrt((x*x) + (y*y));
				}
				else {
					printf("\nERROR: Interpolation point array is empty!!!\n");
				}

			}*/
			else {
				this->mom.z = tof2mom_3accel(t, spect->ion_side->lengths[0], spect->ion_side->lengths[1], spect->ion_side->lengths[2], spect->ion_side->Efields[0], spect->ion_side->Efields[1], spect->ion_side->Efields[2], this->raw.q, this->raw.m);			
			}
		}
	}

	void particle_class::process(spectrometer_class *spect, double x, double y, double t) { //, const std::vector<std::vector<double>> &tofs_and_moms, const std::vector<double> & adjustment_coeff) { //for ion_matrix (polyatomic class)
		
		//this->raw.data.x / y / tof MUST NOT BE CHANGED inside this function, otherwise polyatomic::sort_ion_matrix will explode!
		// first correct raw data with individual correction parameters
		x += cor.dx;
		x *= cor.x_stretch;
		x *= cor.overall_stretch;

		y += cor.dy;
		y *= cor.y_stretch;
		y *= cor.overall_stretch;

		t += cor.dt;
		
		// include jet velocity for ions (angle is with respect to y-axis)
		if(this->raw.m >= 1.0) {
			double sh_vjet = spect->VJet * 1000.0 * t * 1e-9; 
			x -= sh_vjet * sin(spect->AngJet/180.0*PI);
			y -= sh_vjet * cos(spect->AngJet/180.0*PI);
		}

		// calculate momenta
		this->mom.x = calc_px(t, x, y, this->raw.m, this->raw.q, spect->Bfield_ns, spect->Bfield_clockwise);
		this->mom.y = calc_py(t, x, y, this->raw.m, this->raw.q, spect->Bfield_ns, spect->Bfield_clockwise);

		if(this->raw.m < 1.0) { 
			if(spect->electron_side->linear_approximation) 
				this->mom.z = spect->electron_side->Efields[0] * (t - spect->MeanTOFe) / 124.38;  
			else
				this->mom.z = - tof2mom_3accel(t, spect->electron_side->lengths[0], spect->electron_side->lengths[1], spect->electron_side->lengths[2], spect->electron_side->Efields[0], spect->electron_side->Efields[1], spect->electron_side->Efields[2], fabs(this->raw.q), this->raw.m);
		} else {
			if(spect->ion_side->linear_approximation) {	
				this->mom.z = - spect->ion_side->Efields[0] * this->raw.q * (t - this->t_mean) / 124.38;  // according to Markus' diploma thesis
			} 
			/*else if(spect->ion_side->interpolation_approximation ){
				if (tofs_and_moms.size() != 0) {
					this->mom.z = interpolation2mom(t, tofs_and_moms);
					this->mom.z = this->mom.z + adjustment_coeff[0] * x + adjustment_coeff[1] * (x*x) + adjustment_coeff[2] * y + adjustment_coeff[3] * (y*y) + adjustment_coeff[4] * sqrt((x*x) + (y*y));
				}
				else {
					printf("\nERROR: Interpolation point array is empty!!!\n");
				}

			}	*/		
			else {
				this->mom.z = tof2mom_3accel(t, spect->ion_side->lengths[0], spect->ion_side->lengths[1], spect->ion_side->lengths[2], spect->ion_side->Efields[0], spect->ion_side->Efields[1], spect->ion_side->Efields[2], this->raw.q, this->raw.m);			
			}
		}
	}

	double particle_class::energy() 
	{
		return this->mom.Mag() * this->mom.Mag() / (2.0 * this->raw.m * MASSAU) * EVAU;
	}

	bool particle_class::check_tof(double tof_from, double tof_to, int channel, bool invalidate)
	{
		if((this->raw.data.tof < tof_from) || (raw.data.tof > tof_to))
		{
			if(invalidate)
				this->valid = false;
			return false;
		}
		if(channel>=0)
			this->channel = channel;	
		return true;
	}

	bool particle_class::check_mom(double px_width, double py_width, double pz_width, int channel, bool invalidate)
	{
		if(fabs(mom.x)>px_width)
		{
			if(invalidate)
				this->valid = false;
			return false;
		}
		if(fabs(mom.y)>py_width)
		{
			if(invalidate)
				this->valid = false;
			return false;
		}
		if(fabs(mom.z)>pz_width)
		{
			if(invalidate)
				this->valid = false;
			return false;
		}
		if(channel>=0)
			this->channel = channel;
		return true;
	}


	bool particle_class::check_energy(double energy_from, double energy_to, int channel, bool invalidate)
	{
		if((this->energy() < energy_from) || (this->energy() > energy_to))
		{
			if(invalidate)
				this->valid = false;
			return false;
		}
		if(channel>=0)
			this->channel = channel;
		return true;
	}

	bool particle_class::check_validity(double var, double min, double max, bool negate)
	{
		if(negate) {
			if(var < min || var >= max)
				return false;
			else 
				return this->valid;
		} else {
			if(var > min && var <= max)
				return false;
			else 
				return this->valid;
		}
	}

	void particle_class::invalidate(rtag_struct* rtag) 
	{
		switch (rtag->tag_type) {
		
		case RTAG_X:
			this->valid = check_validity(this->raw.data.x,rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_Y:
			this->valid = check_validity(this->raw.data.y,rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_TOF:
			this->valid = check_validity(this->raw.data.tof,rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_PX:
			this->valid = check_validity(this->mom.x,rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_PY:
			this->valid = check_validity(this->mom.y,rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_PZ:
			this->valid = check_validity(this->mom.z,rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_PXY:
			this->valid = check_validity(sqrt(this->mom.x*this->mom.x + this->mom.y*this->mom.y),rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_PXZ:
			this->valid = check_validity(sqrt(this->mom.x*this->mom.x + this->mom.z*this->mom.z),rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_PYZ:
			this->valid = check_validity(sqrt(this->mom.y*this->mom.y + this->mom.z*this->mom.z),rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_P:
			this->valid = check_validity(this->mom.Mag(),rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_PHI_DEG:
			this->valid = check_validity(this->mom.Phi_deg(),rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_PHIPOS:
			this->valid = check_validity(this->raw.phi,rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_THETA_DEG:
			this->valid = check_validity(this->mom.Theta_deg(),rtag->min,rtag->max,rtag->negate);
			break;
		case RTAG_ENERGY:
			this->valid = check_validity(this->energy(),rtag->min,rtag->max,rtag->negate);
			break;

		default:
			break;
		}

	}

}