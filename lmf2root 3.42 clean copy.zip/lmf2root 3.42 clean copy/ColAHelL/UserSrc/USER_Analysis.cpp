#include "..\Src\CH_Histograms.h"
#include "assert.h"
#include "Math.h"
#include <vector>
#include <string.h>
#include <iostream>
#include <fstream>
#include <string>     // std::string, std::to_string



namespace CH
{

	void histograms_class::UserAnalysis(reaction_struct *reac, electron_class ** e, ion_class ** r, diatomic_class * mol, polyatomic_class * big_mol, CH_event_struct *evt) {
		
	///*	
		// Number of possible user histograms.
		MaxUserHists = 20000;

		histo_handler *Hist = this->Hist_User;
		int ehit = evt->e.num_hits;
		int rhit = evt->r.num_hits;
		
		// Example how to acces scanning values from scanning array...
		// get the pointer of the vector!
		double* scan_val = 0;
		if(evt->scanval.size()>0)
			scan_val = &evt->scanval[0];


		#undef  AUTO
		#define AUTO __LINE__ //returns the line number in the current file. Can be used to make life easier for histogram numbering.


		char reaction_dir[360];

		if (this->use_master_folder) {
			strcpy(reaction_dir, this->CH_master_folder);
			strcat(reaction_dir, reac->name);
		}
		else
			strcpy(reaction_dir, reac->name);

		int ID = reac->ID;
		string dir = reaction_dir;
		string old_dir = reaction_dir;
		
		//Custom Plot
		//H2 -> H + p + e-
		if (ID == 7) {//Use tag from presort 
			dir = reaction_dir;
			dir += "/TinyTestH2->Hp+e-";//Name the directory for the reaction

			//Hist->fill1(Plot #, "Plot Title", variable, 1.0, "Display Title", # of bins, Min value, Max value, "Axis label", dir.c_str());

			Hist->fill1(AUTO, "Electron Energy", e[0]->energy(), 1.0, "Electron Energy", 100, 0, 5, "eV", dir.c_str());

			//Hist->fill2(Plot #, "Plot Title", x variable, y variable, 1.0, "Display Title", # of x bins, Min x, Max x, "x axis label", # of y bins, Min y, Max y, "y axis label", dir.c_str());

			Hist->fill2(AUTO, "EE vs RE", r[0]->energy(), e[0]->energy(), 1.0, "Electron energy vs Recoil energy", 400, 0, 10, "Recoil energy", 400, 0, 10, "Electron energy", dir.c_str());
		}












		//H2 -> H p+ e-
		double xlow = -.9;
		double xhigh = .67;
		double ylow = .355;
		double yhigh = 1.9;
		double zlow = 6.45;
		double zhigh = 7.9;

		 ylow = .2;
		 yhigh = 2.05;


		 ylow = .2;
	 ylow = 0;

		 yhigh = 2.05;
	 yhigh = 2.1;

		 zlow = 6.35;
		 zhigh = 8;
		 xhigh = 0.8;
		 xlow = -1.1;
		 double pxcent = -.08;
		 double pycent = 1.05;
		 double pxyradius = 1.25;


		if (ID == 7) {//Tiny using tag from presort 
					//Since default relative momentum, KER, and MFPAD all hate me and refuse to work
					double tinymom_relx = (r[0]->mom.x) / 2.0;
					double tinymom_rely = (r[0]->mom.y) / 2.0;
					double tinymom_relz = (r[0]->mom.z) / 2.0;
					double tinymom_relmag = sqrt(pow(tinymom_relx, 2) + pow(tinymom_rely, 2) + pow(tinymom_relz, 2));
					double tinyreducded_mass = r[0]->raw.m * MASSAU;
					double tiny_ker = (tinymom_relmag * tinymom_relmag / (2.0 * tinyreducded_mass))*EVAU;
					double tiny_mfpad = cos(e[0]->mom.Angle(r[0]->mom));
					double tinyKErec = pow(r[0]->mom.Mag(), 2) / (2 * r[0]->raw.m*MASSAU) *EVAU;
					double tinyKEelec = pow(e[0]->mom.Mag(), 2) / (2 * e[0]->raw.m*MASSAU) *EVAU;
					double tinyKE = tinyKErec + tinyKEelec;

					double etofmin = 0;
					double etofmax = 200;
					double rtofmin = 4900;
					double rtofmax = 5100;

					dir = reaction_dir;
					dir += "/TinyTestHe->He+e-";


					dir += "/All Methods";
					Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
					Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					
					Hist->fill2(AUTO, "Electron Wiggles", e[0]->raw.data.tof, sqrt(e[0]->raw.data.x * e[0]->raw.data.x + e[0]->raw.data.y * e[0]->raw.data.y), 1.0, "Electron Wiggles", 350, 0., 350, "TOF (ns)", 120, 0, 40, "radius [mm]", dir.c_str());

					
					Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 2011, -1., 20., "rec p (au)", 2011, -1, 20., "elec p (au)", dir.c_str());
					Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 2011, -1., 100., "rec KE eV", 2011, -1, 100., "elec KE eV", dir.c_str());
					Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
					Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
					Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine TOF vs Etime", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (all methods)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (all methods)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (all methods)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", dir.c_str());
					Hist->fill1(AUTO, "Number of hits", evt->e.num_hits, 1.0, "Number Electron Hits (all methods)", 10, 0, 11, "", dir.c_str());
					Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
					Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (all methods)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (all methods)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
					Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum x", r[0]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum y", r[0]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum z", r[0]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
					Hist->fill1(AUTO, "psum rec x", r[0]->mom.x + r[1]->mom.x, 1.0, "psum x (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec y", r[0]->mom.y + r[1]->mom.y, 1.0, "psum y (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec z", r[0]->mom.z + r[1]->mom.z, 1.0, "psum z (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());


					dir += "/Tiny MFPAD";
					Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
					Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 2000, 0., 15, "eV", dir.c_str());

					Hist->fill1(AUTO, "MFPAD tiny", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


					Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
					Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());


					dir = reaction_dir;
					dir += "/TinyTestHe->He+e-";








				}



	}
		

		}
		//*/	

