#include "CH_Histograms.h"

// Standard histograms for reactions of "DIATOMIC", "DIATOMIC_DISS", "DIATOMIC_ELEC" and "DIATOMIC_DISS" type
namespace CH
{

	// there is nothing to plot in case we did not have a reaction definition
	void histograms_class::plot_diatomic(reaction_struct *cur_reaction, diatomic_class * mol, electron_class ** e, int ehit, double *scan_val) 
	{
		histo_handler *Hist = this->Hist_ions;
		range_class *rg = cur_reaction->rng;
		int rgti = RA_ION;
		int rgtd = RA_DIATOMIC;
		int rgte = RA_ELECTRON;

		// histogram index stuff
		int hmax = HISTS_PER_CHANNEL; // overall number of ColAHelL histograms per reaction/channel
		int hoff = hmax*15*(int)cur_reaction->reac_num;

		// limit to 16 hits.. 
		if(ehit>15)
			ehit=15;

		char reaction_dir[360];
//		char x_axis_title[80];
//		char y_axis_title[80];

		char rootdir[360];
		char ndir[360];
		char alldir[360];
		char tdir[360];
		char talldir[360];

		if(this->use_master_folder) {
			strcpy(reaction_dir,this->CH_master_folder);
			strcat(reaction_dir,cur_reaction->name);
		} else
			strcpy(reaction_dir,cur_reaction->name);		

		strcpy(rootdir,reaction_dir);

		// fill standard ion histograms.
		ion_class *r[2];
			
		r[0] = mol->ion[0];
		r[1] = mol->ion[1];

		for(int i=0; i<2;i++) {
			strcpy(ndir,rootdir); sprintf(tdir,"/ion_%i",i); strcat(ndir,tdir); strcpy(tdir,ndir);

			Hist->fill(hoff+hmax*i+0,"ion_energy",r[i]->energy(),1.,"ion energy",rg->get_bins(rgti+i,ENERGY),rg->get_from(rgti+i,ENERGY),rg->get_to(rgti+i,ENERGY),"ion energy [eV]",strcat(ndir,"/energy"));
			Hist->fill(hoff+hmax*i+1,"phi_vs_ion_energy",r[i]->raw.phi,r[i]->energy(),1.,"ion energy vs. phi on detector",rg->get_bins(rgti+i,PHILAB),rg->get_from(rgti+i,PHILAB),rg->get_to(rgti+i,PHILAB),"phi [deg]",rg->get_bins(rgti+i,ENERGY),rg->get_from(rgti+i,ENERGY),rg->get_to(rgti+i,ENERGY),"ion energy [eV]",ndir); 
			Hist->fill(hoff+hmax*i+2,"ctheta_vs_ion_energy",r[i]->mom.Cos_Theta(),r[i]->energy(),1.,"ion energy vs. cos(theta_z)",rg->get_bins(rgti+i,CTELAB),rg->get_from(rgti+i,CTELAB),rg->get_to(rgti+i,CTELAB),"ctheta",rg->get_bins(rgti+i,ENERGY),rg->get_from(rgti+i,ENERGY),rg->get_to(rgti+i,ENERGY),"ion energy [eV]",ndir); 
						
			strcpy(ndir,tdir);
			Hist->fill(hoff+hmax*i+3,"px_vs_py",r[i]->mom.x,r[i]->mom.y,1.,"p_x vs. p_y",rg->get_bins(rgti+i,PX),rg->get_from(rgti+i,PX),rg->get_to(rgti+i,PX),"p_x [a.u.]",rg->get_bins(rgti+i,PY),rg->get_from(rgti+i,PY),rg->get_to(rgti+i,PY),"p_y [a.u.]",strcat(ndir,"/momenta"));
			Hist->fill(hoff+hmax*i+4,"px_vs_pz",r[i]->mom.x,r[i]->mom.z,1.,"p_x vs. p_z",rg->get_bins(rgti+i,PX),rg->get_from(rgti+i,PX),rg->get_to(rgti+i,PX),"p_x [a.u.]",rg->get_bins(rgti+i,PZ),rg->get_from(rgti+i,PZ),rg->get_to(rgti+i,PZ),"p_z [a.u.]",ndir);
			Hist->fill(hoff+hmax*i+5,"py_vs_pz",r[i]->mom.y,r[i]->mom.z,1.,"p_y vs. p_z",rg->get_bins(rgti+i,PY),rg->get_from(rgti+i,PY),rg->get_to(rgti+i,PY),"p_y [a.u.]",rg->get_bins(rgti+i,PZ),rg->get_from(rgti+i,PZ),rg->get_to(rgti+i,PZ),"p_z [a.u.]",ndir);
			Hist->fill(hoff+hmax*i+6,"p_mag",r[i]->mom.Mag(),1.,"|p|",rg->get_bins(rgti+i,P),rg->get_from(rgti+i,P),rg->get_to(rgti+i,P),"|p| [a.u.]",ndir);

			strcpy(ndir,tdir);
			Hist->fill(hoff+hmax*i+7,"phi",r[i]->mom.Phi_deg(),1.,"phi in the labframe",rg->get_bins(rgti+i,PHILAB),rg->get_from(rgti+i,PHILAB),rg->get_to(rgti+i,PHILAB),"phi [deg]",strcat(ndir,"/angles_labframe"));
			Hist->fill(hoff+hmax*i+8,"ctheta",r[i]->mom.Cos_Theta(),1.,"cos(theta) in the labframe",rg->get_bins(rgti+i,CTELAB),rg->get_from(rgti+i,CTELAB),rg->get_to(rgti+i,CTELAB),"cos(theta)",ndir);

			strcpy(ndir,tdir);
			Hist->fill(hoff+hmax*i+9,"position",r[i]->raw.data.x,r[i]->raw.data.y,1.,"position",400,-1.*rdet_size,rdet_size,"x [mm]",400,-1.*rdet_size,rdet_size,"y [mm]",strcat(ndir,"/raw"));
			Hist->fill(hoff+hmax*i+10,"tof",r[i]->raw.data.tof,1.,"time-of-flight",rg->get_bins(rgti+i,TOF),rg->get_from(rgti+i,TOF),rg->get_to(rgti+i,TOF),"tof [ns]",ndir);
			Hist->fill(hoff+hmax*i+11,"wiggle",r[i]->raw.data.tof,(sqrt(r[i]->raw.data.x*r[i]->raw.data.x+r[i]->raw.data.y*r[i]->raw.data.y)),1.,"wiggles",rg->get_bins(rgti+i,TOF),rg->get_from(rgti+i,TOF),rg->get_to(rgti+i,TOF),"tof [ns]",200,-1.,rdet_size,"r [mm]",ndir);
			Hist->fill(hoff+hmax*i+12,"fish_x",r[i]->raw.data.tof,r[i]->raw.data.x,1.,"x-fish",rg->get_bins(rgti+i,TOF),rg->get_from(rgti+i,TOF),rg->get_to(rgti+i,TOF),"tof [ns]",200,-1.*rdet_size,rdet_size,"x [mm]",ndir);
			Hist->fill(hoff+hmax*i+13,"fish_y",r[i]->raw.data.tof,r[i]->raw.data.y,1.,"y-fish",rg->get_bins(rgti+i,TOF),rg->get_from(rgti+i,TOF),rg->get_to(rgti+i,TOF),"tof [ns]",200,-1.*rdet_size,rdet_size,"y [mm]",ndir);
			if ( fabs(r[i]->raw.data.y)<10. ) 
				Hist->fill(hoff+hmax*i+14,"fish_filet_x",r[i]->raw.data.tof,r[i]->raw.data.x,1.,"x-fish filet",rg->get_bins(rgti+i,TOF),rg->get_from(rgti+i,TOF),rg->get_to(rgti+i,TOF),"tof [ns]",200,-1.*rdet_size,rdet_size,"x [mm]",ndir);
			if ( fabs(r[i]->raw.data.x)<10. ) 
				Hist->fill(hoff+hmax*i+15,"fish_filet_y",r[i]->raw.data.tof,r[i]->raw.data.y,1.,"y-fish filet",rg->get_bins(rgti+i,TOF),rg->get_from(rgti+i,TOF),rg->get_to(rgti+i,TOF),"tof [ns]",200,-1.*rdet_size,rdet_size,"y [mm]",ndir);
					
		}

		// fill standard diatomic histograms
		strcpy(ndir,rootdir); sprintf(tdir,"/mol_ion");	strcat(ndir,tdir); strcpy(tdir,ndir);

		Hist->fill(hoff+hmax+16,"p_relx_vs_p_rely",mol->mom_rel.x,mol->mom_rel.y,1.,"relative momentum x vs. y",rg->get_bins(rgtd,PRELX),rg->get_from(rgtd,PRELX),rg->get_to(rgtd,PRELX),"p_relx [a.u.]",rg->get_bins(rgtd,PRELY),rg->get_from(rgtd,PRELY),rg->get_to(rgtd,PRELY),"p_rely [a.u.]",strcat(ndir,"/momenta"));
		Hist->fill(hoff+hmax+17,"p_relx_vs_p_relz",mol->mom_rel.x,mol->mom_rel.z,1.,"relative momentum x vs. z",rg->get_bins(rgtd,PRELX),rg->get_from(rgtd,PRELX),rg->get_to(rgtd,PRELX),"p_relx [a.u.]",rg->get_bins(rgtd,PRELZ),rg->get_from(rgtd,PRELZ),rg->get_to(rgtd,PRELZ),"p_relz [a.u.]",ndir);
		Hist->fill(hoff+hmax+18,"p_rely_vs_p_relz",mol->mom_rel.y,mol->mom_rel.z,1.,"relative momentum y vs. z",rg->get_bins(rgtd,PRELY),rg->get_from(rgtd,PRELY),rg->get_to(rgtd,PRELY),"p_rely [a.u.]",rg->get_bins(rgtd,PRELZ),rg->get_from(rgtd,PRELZ),rg->get_to(rgtd,PRELZ),"p_relz [a.u.]",ndir);
		Hist->fill(hoff+hmax+19,"p_sumx_vs_p_sumy",mol->mom_cm.x,mol->mom_cm.y,1.,"center of mass momentum x vs. y",rg->get_bins(rgtd,PCMX),rg->get_from(rgtd,PCMX),rg->get_to(rgtd,PCMX),"p_cmx [a.u.]",rg->get_bins(rgtd,PCMY),rg->get_from(rgtd,PCMY),rg->get_to(rgtd,PCMY),"p_cmy [a.u.]",ndir);
		Hist->fill(hoff+hmax+20,"p_sumx_vs_p_sumz",mol->mom_cm.x,mol->mom_cm.z,1.,"center of mass momentum x vs. z",rg->get_bins(rgtd,PCMX),rg->get_from(rgtd,PCMX),rg->get_to(rgtd,PCMX),"p_cmx [a.u.]",rg->get_bins(rgtd,PCMZ),rg->get_from(rgtd,PCMZ),rg->get_to(rgtd,PCMZ),"p_cmz [a.u.]",ndir);
		Hist->fill(hoff+hmax+21,"p_sumy_vs_p_sumz",mol->mom_cm.y,mol->mom_cm.z,1.,"center of mass momentum y vs. z",rg->get_bins(rgtd,PCMY),rg->get_from(rgtd,PCMY),rg->get_to(rgtd,PCMY),"p_cmy [a.u.]",rg->get_bins(rgtd,PCMZ),rg->get_from(rgtd,PCMZ),rg->get_to(rgtd,PCMZ),"p_cmz [a.u.]",ndir);
		Hist->fill(hoff+hmax+22,"ion1_px_vs_ion2_px",mol->ion[0]->mom.x,mol->ion[1]->mom.x,1.,"momentum ion1 vs. ion2 x-direction",rg->get_bins(rgti,PX),rg->get_from(rgti,PX),rg->get_to(rgti,PX),"p_1x [a.u.]",rg->get_bins(rgti,PX),rg->get_from(rgti,PX),rg->get_to(rgti,PX),"p_2x [a.u.]",ndir);
		Hist->fill(hoff+hmax+23,"ion1_py_vs_ion2_py",mol->ion[0]->mom.y,mol->ion[1]->mom.y,1.,"momentum ion1 vs. ion2 y-direction",rg->get_bins(rgti,PY),rg->get_from(rgti,PX),rg->get_to(rgti,PX),"p_1y [a.u.]",rg->get_bins(rgti,PY),rg->get_from(rgti,PX),rg->get_to(rgti,PX),"p_2y [a.u.]",ndir);
		Hist->fill(hoff+hmax+24,"ion1_pz_vs_ion2_pz",mol->ion[0]->mom.z,mol->ion[1]->mom.z,1.,"momentum ion1 vs. ion2 z-direction",rg->get_bins(rgti,PZ),rg->get_from(rgti,PX),rg->get_to(rgti,PX),"p_1z [a.u.]",rg->get_bins(rgti,PZ),rg->get_from(rgti,PX),rg->get_to(rgti,PX),"p_2z [a.u.]",ndir);

		Hist->fill(hoff+hmax+25,"p_relx_vs_p_sumz",mol->mom_rel.x,mol->mom_cm.z,1.,"rel. mom. x vs. cm. mom. z",rg->get_bins(rgtd,PRELX),rg->get_from(rgtd,PRELX),rg->get_to(rgtd,PRELX),"p_relx [a.u.]",rg->get_bins(rgtd,PCMZ),rg->get_from(rgtd,PCMZ),rg->get_to(rgtd,PCMZ),"p_cmz [a.u.]",ndir);
		Hist->fill(hoff+hmax+26,"p_rely_vs_p_sumz",mol->mom_rel.y,mol->mom_cm.z,1.,"rel. mom. y vs. cm. mom. z",rg->get_bins(rgtd,PRELY),rg->get_from(rgtd,PRELY),rg->get_to(rgtd,PRELY),"p_rely [a.u.]",rg->get_bins(rgtd,PCMZ),rg->get_from(rgtd,PCMZ),rg->get_to(rgtd,PCMZ),"p_cmz [a.u.]",ndir);

		Hist->fill(hoff+hmax+27,"p_sum_vs_KER",mol->mom_cm.Mag(),mol->KER(),1.,"center of mass momentum vs. KER",rg->get_bins(rgtd,PCM),rg->get_from(rgtd,PCM),rg->get_to(rgtd,PCM),"|pcm| [a.u.]",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER [eV]",ndir); 

		strcpy(ndir,tdir);
		Hist->fill(hoff+hmax+28,"phi_vs_KER",mol->mom_rel.Phi_deg(),mol->KER(),1.,"phi rel. mom. vs. KER",72,-180.0,180.0,"phi [deg]",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER [eV]",ndir); 
		Hist->fill(hoff+hmax+29,"ctheta_vs_KER",mol->mom_rel.Cos_Theta(),mol->KER(),1.,"cos(rel. mom.) vs. KER",72,-1.0,1.0,"ctheta",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER [eV]",ndir); 
		Hist->fill(hoff+hmax+30,"KER",mol->KER(),1.,"kinetic energy release",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER [eV]",ndir);

		// fill standard diatomic coincidence histograms
		if(ehit>0) {
			strcpy(ndir,rootdir); sprintf(tdir,"/mol_coincidence");	strcat(ndir,tdir); strcpy(tdir,ndir); 
			strcpy(alldir,rootdir);	strcat(alldir,"/mol_coincidence/all_hits");	strcpy(talldir,alldir);

			double e_sum_en = 0.0;
			int valid_electrons = 0;

			for(int i=0;i<(int)ehit;i++) {

				if(e[i]->valid) {
					e_sum_en += e[i]->energy();
					valid_electrons++;
					strcpy(ndir,rootdir); sprintf(tdir,"/mol_coincidence/elec_hit_%i",valid_electrons); strcat(ndir,tdir); strcpy(tdir,ndir);

					Hist->fill(hoff+hmax*valid_electrons+31,"KER_vs_electron_energy",mol->KER(),e[i]->energy(),1.,"kinetic energy release vs. electron energy",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER [eV]",rg->get_bins(rgte+i,ENERGY),rg->get_from(rgte+i,ENERGY),rg->get_to(rgte+i,ENERGY),"electron energy [eV]",ndir);
					Hist->fill(hoff+hmax*15+32,"KER_vs_electron_energy",mol->KER(),e[i]->energy(),1.,"kinetic energy release vs. electron energy",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER [eV]",rg->get_bins(rgte+i,ENERGY),rg->get_from(rgte+i,ENERGY),rg->get_to(rgte+i,ENERGY),"electron energy [eV]",alldir);

					Hist->fill(hoff+hmax*valid_electrons+33,"KER_vs_KER+electron_energy",mol->KER(),mol->KER()+e[i]->energy(),1.,"kinetic energy release vs. sum energy",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER [eV]",100,0.0,35.0,"KER + electron energy [eV]",ndir);
					Hist->fill(hoff+hmax*15+34,"KER_vs_KER+electron_energy",mol->KER(),mol->KER()+e[i]->energy(),1.,"kinetic energy release vs. sum energy",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER [eV]",100,0.0,35.0,"KER + electron energy [eV]",alldir);

					Hist->fill(hoff+hmax*valid_electrons+35,"p_sumx_vs_p_ex",mol->mom_cm.x,e[i]->mom.x,1.,"psum_x vs. p_ex",50,-20.5,20.5,"psum_x [a.u.]",50,-2.5,2.5,"pe_x [a.u.]",strcat(ndir,"/mol_psum"));
					Hist->fill(hoff+hmax*valid_electrons+36,"p_sumy_vs_p_ey",mol->mom_cm.y,e[i]->mom.y,1.,"psum_y vs. p_ey",50,-20.5,20.5,"psum_y [a.u.]",50,-2.5,2.5,"pe_y [a.u.]",ndir);
					Hist->fill(hoff+hmax*valid_electrons+37,"p_sumz_vs_p_ez",mol->mom_cm.z,e[i]->mom.z,1.,"psum_z vs. p_ez",50,-20.5,20.5,"psum_z [a.u.]",50,-2.5,2.5,"pe_z [a.u.]",ndir);

					Hist->fill(hoff+hmax*15+38,"p_sumx_vs_p_ex",mol->mom_cm.x,e[i]->mom.x,1.,"psum_x vs. p_ex",50,-20.5,20.5,"psum_x [a.u.]",50,-2.5,2.5,"pe_x [a.u.]",strcat(alldir,"/mol_psum"));
					Hist->fill(hoff+hmax*15+39,"p_sumy_vs_p_ey",mol->mom_cm.y,e[i]->mom.y,1.,"psum_y vs. p_ey",50,-20.5,20.5,"psum_y [a.u.]",50,-2.5,2.5,"pe_y [a.u.]",alldir);
					Hist->fill(hoff+hmax*15+40,"p_sumz_vs_p_ez",mol->mom_cm.z,e[i]->mom.z,1.,"psum_z vs. p_ez",50,-20.5,20.5,"psum_z [a.u.]",50,-2.5,2.5,"pe_z [a.u.]",alldir);

					strcpy(ndir,tdir);
					strcpy(alldir,talldir);

				}
			}

			if (valid_electrons > 1) {
				Hist->fill(hoff + hmax*15 + 41, "KER_vs_electron_sum_energy", mol->KER(), e_sum_en, 1., "kinetic energy release vs. electron sum energy",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER), "KER [eV]", 200, 0.0, 50.0, "esum energy [eV]", alldir);
				Hist->fill(hoff + hmax*15 + 42,"KER_vs_total_ kin.energy", mol->KER(), e_sum_en + mol->KER(), 1., "kinetic energy release vs. total kinetic energy",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER), "KER [eV]", 200, 0.0, 50.0, "total energy [eV]", alldir);
				Hist->fill(hoff + hmax*15 + 43, "Total_kin.energy", e_sum_en + mol->KER(), 1., "Total kinetic energy", 200, 0.0, 50.0, "total energy [eV]", alldir);
			}
		}

// Special histograms: molecular frame !
// ========================================================------------
		if(cur_reaction->MF_cond->type > -1) {		
			int valid_electrons = 0;

			CH_vector photon_dir = CH_vector(1.0,0.0,0);
			Coordinate_System mf_circ = Coordinate_System(photon_dir,mol->mom_rel);

			CH_vector pol_dir = CH_vector(0,1.0,0);
			Coordinate_System mf = Coordinate_System(mol->mom_rel, pol_dir);

			CH_vector e_MF;

			for(int i=0;i<(int)ehit;i++) {
				if(e[i]->valid) {
					valid_electrons++;
					strcpy(ndir,rootdir); sprintf(tdir,"/mol_coincidence/elec_hit_%i/mol_frame",valid_electrons); strcat(ndir,tdir); strcpy(tdir,ndir);
					strcpy(alldir,rootdir);	strcat(alldir,"/mol_coincidence/all_hits/mol_frame"); strcpy(talldir,alldir);

					if((mol->KER() > cur_reaction->MF_cond->rmin) && (mol->KER() < cur_reaction->MF_cond->rmax)) {
						Hist->fill(hoff+hmax*valid_electrons+44, "PA-MFPAD_vs_electron_energy",cos(mol->mom_rel.Angle(e[i]->mom)),e[i]->energy(),1.,"polarization averaged mol. frame ang. distribution",96,-1.,1.,"cos(theta)",rg->get_bins(rgte+i,ENERGY),rg->get_from(rgte+i,ENERGY),rg->get_to(rgte+i,ENERGY),"electron energy [eV]",ndir);
						Hist->fill(hoff+hmax*15+44,"PA-MFPAD_vs_electron_energy",cos(mol->mom_rel.Angle(e[i]->mom)),e[i]->energy(),1.,"polarization averaged mol. frame ang. distribution",96,-1.,1.,"cos(theta)",rg->get_bins(rgte+i,ENERGY),rg->get_from(rgte+i,ENERGY),rg->get_to(rgte+i,ENERGY),"electron energy [eV]",alldir);					
					}

					// circular light has a different mol frame.. 
					if(cur_reaction->MF_cond->type==1)
						e_MF = mf_circ.project_vector(e[i]->mom);
					else
						e_MF = mf.project_vector(e[i]->mom);
					
					if((mol->KER() > cur_reaction->MF_cond->rmin) && (mol->KER() < cur_reaction->MF_cond->rmax) && (e[i]->energy() > cur_reaction->MF_cond->emin) && (e[i]->energy() < cur_reaction->MF_cond->emax)) {
						Hist->fill(hoff+hmax*valid_electrons+45,"MFPAD3D_all_orientations",e_MF.Phi_deg(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-180.,180.,"Phi",24,-1.0,1.0,"cos(theta)",ndir);
						Hist->fill(hoff+hmax*15+45,"MFPAD3D_all_orientations",e_MF.Phi_deg(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-180.,180.,"Phi",24,-1.0,1.0,"cos(theta)",alldir);
					}

					double open_ang_sig = 15.0;
					double open_ang_pi = 15.0;

					// sigma
					strcat(ndir,"/Sigma");
					strcat(alldir,"/Sigma");

					if((mol->KER() > cur_reaction->MF_cond->rmin) && (mol->KER() < cur_reaction->MF_cond->rmax) && (e[i]->energy() > cur_reaction->MF_cond->emin) && (e[i]->energy() < cur_reaction->MF_cond->emax)) {

						if((cur_reaction->MF_cond->type !=1 && ((mol->mom_rel.Angle_deg(pol_dir) < open_ang_sig) || (mol->mom_rel.Angle_deg(pol_dir) > (180. - open_ang_sig)))) || 
							(cur_reaction->MF_cond->type==1 && (fabs(mol->mom_rel.Angle_deg(photon_dir)-90.0) < open_ang_sig))) {
						
							Hist->fill(hoff+hmax*valid_electrons+46,"MFPAD3D",e_MF.Phi_deg(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-180.,180.,"Phi",24,-1.0,1.0,"cos(theta)",ndir);
							Hist->fill(hoff+hmax*15+46,"MFPAD3D",e_MF.Phi_deg(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-180.,180.,"Phi",24,-1.0,1.0,"cos(theta)",alldir);

							if(cur_reaction->MF_cond->type==1) { // Plot phi and restrict electron plane for circ. case 
								if(fabs(e[i]->mom.Angle_deg(photon_dir)-90.0) < open_ang_sig) {
									Hist->fill(hoff+hmax*valid_electrons+47,"MFPAD",e_MF.Phi_deg(),1.,"molecular frame angular distribution",72,-180.,180.,"Phi",ndir);						
									Hist->fill(hoff+hmax*15+47,"MFPAD",e_MF.Phi_deg(),1.,"molecular frame angular distribution",72,-180.,180.,"Phi",alldir);
								}
							} else { // Plot cos(theta) for lin. case
								Hist->fill(hoff+hmax*valid_electrons+47,"MFPAD",e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-1.,1.,"cos(theta)",ndir);
								Hist->fill(hoff+hmax*15+47,"MFPAD",e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-1.,1.,"cos(theta)",alldir);
							}
						}
					}
					if((e[i]->energy() > cur_reaction->MF_cond->emin) && (e[i]->energy() < cur_reaction->MF_cond->emax)) {
						if(cur_reaction->MF_cond->type==1) { // Plot phi and restrict electron plane for circ. case 
							if(fabs(e[i]->mom.Angle_deg(photon_dir)-90.0) < open_ang_sig) {
								Hist->fill(hoff+hmax*valid_electrons+48,"KER_vs_MFPAD",mol->KER(),e_MF.Phi_deg(),1.,"molecular frame angular distribution vs. KER",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER[eV]",36,-180.,180.,"Phi",ndir);
								Hist->fill(hoff+hmax*15+48,"KER_vs_MFPAD",mol->KER(),e_MF.Phi_deg(),1.,"molecular frame angular distribution vs. KER",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER[eV]",36,-180.,180.,"Phi",alldir);	
							}
						} else { // Plot cos(theta) for lin. case
							Hist->fill(hoff+hmax*valid_electrons+48,"KER_vs_MFPAD",mol->KER(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution vs. KER",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER[eV]",36,-1.,1.,"cos(theta)",ndir);
							Hist->fill(hoff+hmax*15+48,"KER_vs_MFPAD",mol->KER(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution vs. KER",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER[eV]",36,-1.,1.,"cos(theta)",alldir);				
						}
					}

					// Pi
					strcpy(ndir,tdir); strcat(ndir,"/Pi");
					strcpy(alldir,talldir); strcat(alldir,"/Pi");

					if((mol->KER() > cur_reaction->MF_cond->rmin) && (mol->KER() < cur_reaction->MF_cond->rmax) && (e[i]->energy() > cur_reaction->MF_cond->emin) && (e[i]->energy() < cur_reaction->MF_cond->emax)) {

					
						if((cur_reaction->MF_cond->type !=1 && fabs(mol->mom_rel.Angle_deg(pol_dir)-90) < open_ang_pi) ||
							(cur_reaction->MF_cond->type==1 && ((mol->mom_rel.Angle_deg(photon_dir) < open_ang_pi) || (mol->mom_rel.Angle_deg(photon_dir) > (180. - open_ang_pi)))) ) {
						
							Hist->fill(hoff+hmax*valid_electrons+49,"MFPAD3D",e_MF.Phi_deg(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-180.,180.,"Phi",24,-1.0,1.0,"cos(theta)",ndir);
							Hist->fill(hoff+hmax*15+49,"MFPAD3D",e_MF.Phi_deg(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-180.,180.,"Phi",24,-1.0,1.0,"cos(theta)",alldir);

							if(cur_reaction->MF_cond->type==1) { // Plot phi and restrict electron plane for circ. case 
								if(fabs(e[i]->mom.Angle_deg(pol_dir)-90.0) < 15) {
									Hist->fill(hoff+hmax*valid_electrons+50,"MFPAD",e_MF.Phi_deg(),1.,"molecular frame angular distribution",72,-180.,180.,"Phi",ndir);						
									Hist->fill(hoff+hmax*15+50,"MFPAD",e_MF.Phi_deg(),1.,"molecular frame angular distribution",72,-180.,180.,"Phi",alldir);
								}
							} else { // Plot cos(theta) for lin. case
								if(fabs(e_MF.Phi_deg())<open_ang_pi || e_MF.Phi_deg()>180.0 - open_ang_pi || e_MF.Phi_deg() < -180.0 + open_ang_pi) {
									Hist->fill(hoff+hmax*valid_electrons+50,"MFPAD",e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-1.,1.,"cos(theta)",ndir);
									Hist->fill(hoff+hmax*15+50,"MFPAD",e_MF.Cos_Theta(),1.,"molecular frame angular distribution",36,-1.,1.,"cos(theta)",alldir);
								}
							}
						}
					}
					if((e[i]->energy() > cur_reaction->MF_cond->emin) && (e[i]->energy() < cur_reaction->MF_cond->emax)) {
						if(cur_reaction->MF_cond->type==1) { // Plot phi and restrict electron plane for circ. case 
							if(fabs(e[i]->mom.Angle_deg(pol_dir)-90.0) < 15) {
								Hist->fill(hoff+hmax*valid_electrons+60,"KER_vs_MFPAD",mol->KER(),e_MF.Phi_deg(),1.,"molecular frame angular distribution vs. KER",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER[eV]",36,-180.,180.,"Phi",ndir);
								Hist->fill(hoff+hmax*15+60,"KER_vs_MFPAD",mol->KER(),e_MF.Phi_deg(),1.,"molecular frame angular distribution vs. KER",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER[eV]",36,-180.,180.,"Phi",alldir);	
							}
						} else { // Plot cos(theta) for lin. case
							if(fabs(e_MF.Phi_deg())<open_ang_pi || e_MF.Phi_deg()>180.0 - open_ang_pi || e_MF.Phi_deg() < -180.0 + open_ang_pi) {
								Hist->fill(hoff+hmax*valid_electrons+60,"KER_vs_MFPAD",mol->KER(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution vs. KER",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER[eV]",36,-1.,1.,"cos(theta)",ndir);
								Hist->fill(hoff+hmax*15+60,"KER_vs_MFPAD",mol->KER(),e_MF.Cos_Theta(),1.,"molecular frame angular distribution vs. KER",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER[eV]",36,-1.,1.,"cos(theta)",alldir);	
							}
						}
					}
				}
			}
			

			// F-functions (for linear light only, so far)
			if(cur_reaction->MF_cond->type==0) {	

				strcpy(alldir,rootdir);	strcat(alldir,"/mol_coincidence/all_hits/mol_frame/F-functions"); strcpy(talldir,alldir);
				int valid_electrons = 0;

				CH_vector pol_dir = CH_vector(0,1.0,0);
				Coordinate_System mf = Coordinate_System(mol->mom_rel, pol_dir);
				CH_vector e_MF;

				// F00 array, needs to be extracted in 1st run
				double F00[60] = {0.0331143,0.086728,0.15138,0.167148,0.244415,0.249146,0.301183,0.301183,0.294875,0.345335,0.376873,0.397372,0.405256,0.419448,0.466754,0.504599,0.581866,0.655979,0.611827,0.663863,0.736399,0.745861,0.745861,0.767937,0.84205,0.79159,0.804205,0.778975,0.778975,0.81682,0.801051,0.772668,0.76636,0.736399,0.719054,0.772668,0.756899,0.771091,0.71117,0.734823,0.643364,0.708016,0.61025,0.632326,0.525099,0.462024,0.444678,0.414717,0.432063,0.359527,0.359527,0.356373,0.310644,0.290145,0.238108,0.203417,0.175033,0.107227,0.0914586,0.0268068};

				for(int i=0;i<(int)ehit;i++) {
					if(e[i]->valid) {
						valid_electrons++;
						strcpy(ndir,rootdir); sprintf(tdir,"/mol_coincidence/elec_hit_%i/mol_frame/F-functions",valid_electrons); strcat(ndir,tdir); strcpy(tdir,ndir);

						if((mol->KER() > cur_reaction->MF_cond->rmin) && (mol->KER() < cur_reaction->MF_cond->rmax) && (e[i]->energy() > cur_reaction->MF_cond->emin) && (e[i]->energy() < cur_reaction->MF_cond->emax)) {
							
							Hist->fill(hoff+hmax*valid_electrons+61, "F00",e_MF.Theta_deg(),1.0,"theta",60,0.,180.,"theta",ndir);
							Hist->fill(hoff+hmax*15+61, "F00",e_MF.Theta_deg(),1.0,"theta",60,0.,180.,"theta",alldir);
							
							if(mol->mom_rel.Angle_deg(pol_dir)>60.0 && mol->mom_rel.Angle_deg(pol_dir)<120.0) {
								Hist->fill(hoff+hmax*valid_electrons+62, "F20",e_MF.Theta_deg(),1.0,"theta",60,0.,180.,"theta",ndir);
								Hist->fill(hoff+hmax*15+62, "F20",e_MF.Theta_deg(),1.0,"theta",60,0.,180.,"theta",alldir);
							}

							if(fabs(cos(2.0*e_MF.Phi()))>0.2) {
								int ind = (int)e_MF.Theta_deg()/3;

								double w = (1.0 - 2.0*F00[ind])/cos(2.0*e_MF.Phi());
								Hist->fill(hoff+hmax*valid_electrons+63, "F22",e_MF.Theta_deg(),w,"theta",60,0.,180.,"theta",ndir);
								Hist->fill(hoff+hmax*15+63, "F22",e_MF.Theta_deg(),w,"theta",60,0.,180.,"theta",alldir);

								w = (1.0 - F00[ind])/cos(e_MF.Phi());
								if(mol->mom_rel.Angle_deg(pol_dir)<90.0) {								
									Hist->fill(hoff+hmax*valid_electrons+64, "F21",e_MF.Theta_deg(),w,"theta",60,0.,180.,"theta",ndir);
									Hist->fill(hoff+hmax*15+64, "F21",e_MF.Theta_deg(),w,"theta",60,0.,180.,"theta",alldir);
								} else {
									Hist->fill(hoff+hmax*valid_electrons+64, "F21",e_MF.Theta_deg(),-w,"theta",60,0.,180.,"theta",ndir);
									Hist->fill(hoff+hmax*15+64, "F21",e_MF.Theta_deg(),-w,"theta",60,0.,180.,"theta",alldir);
								}
							}
						}
					}
				}
			}
		}

// Special histograms: Photon energy scan !
// ========================================================------------
		if(cur_reaction->photon_scan) {
			int phbins = int((cur_reaction->ph_max - cur_reaction->ph_min)/cur_reaction->ph_step);

			strcpy(ndir,reaction_dir); sprintf(tdir,"/photon_energy_scan"); strcat(ndir,tdir);
			Hist->fill(hoff+hmax+65,"hv",scan_val[cur_reaction->ph_scan_channel],1.,"Photon energy",phbins, cur_reaction->ph_min, cur_reaction->ph_max,"hv [eV]",ndir);
			
			strcpy(ndir,reaction_dir); sprintf(tdir,"/photon_energy_scan/ions"); strcat(ndir,tdir);
			Hist->fill(hoff+hmax+66,"hv_vs_KER",scan_val[cur_reaction->ph_scan_channel],mol->KER(),1.,"Photon energy vs. KER",phbins, cur_reaction->ph_min, cur_reaction->ph_max,"hv [eV]",rg->get_bins(rgtd,KINER),rg->get_from(rgtd,KINER),rg->get_to(rgtd,KINER),"KER [eV]",ndir);
		}
	}
}