#include "..\Src\CH_Histograms.h"
#include "assert.h"
#include "Math.h"
#include <vector>
#include <string.h>
#include <iostream>
#include <fstream>
#include <string>     // std::string, std::to_string

int getasypar = 0;
int quickcal = 0;
int eventnumber = 0;

double cph1 =0;
double chh1 =0;
double asyparh1 = 0.0;

double cph2 = 0;
double chh2 = 0;
double asyparh2 = 0.0;

double cph3 = 0;
double chh3 = 0;
double asyparh3 = 0.0;

double cph4 = 0;
double chh4 = 0;
double asyparh4 = 0.0;

double cph5 = 0;
double chh5 = 0;
double asyparh5 = 0.0;

double cph6 = 0;
double chh6 = 0;
double asyparh6 = 0.0;

double cph7 = 0;
double chh7 = 0;
double asyparh7 = 0.0;

double cph8 = 0;
double chh8 = 0;
double asyparh8 = 0.0;

double cph9 = 0;
double chh9 = 0;
double asyparh9 = 0.0;

double cph10 = 0;
double chh10 = 0;
double asyparh10 = 0.0;


double cph11 = 0;
double chh11 = 0;
double asyparh11 = 0.0;

double cph12 = 0;
double chh12 = 0;
double asyparh12 = 0.0;

double cph13 = 0;
double chh13 = 0;
double asyparh13 = 0.0;

double cph14 = 0;
double chh14 = 0;
double asyparh14 = 0.0;

double cph15 = 0;
double chh15 = 0;
double asyparh15 = 0.0;

double cph16 = 0;
double chh16 = 0;
double asyparh16 = 0.0;

double cph17 = 0;
double chh17 = 0;
double asyparh17 = 0.0;

double cph18 = 0;
double chh18 = 0;
double asyparh18 = 0.0;

double cph19 = 0;
double chh19 = 0;
double asyparh19 = 0.0;

double cph20 = 0;
double chh20 = 0;
double asyparh20 = 0.0;

double cp6 = 0;
double ch6 = 0;

double cp7 = 0;
double ch7 = 0;

double cp8 = 0;
double ch8 = 0;


double cp9 = 0;
double ch9 = 0;
double asypar9 = 0.0;

double cp10 = 0;
double ch10 = 0;
double asypar10 = 0.0;

double cp11 = 0;
double ch11 = 0;
double asypar11 = 0.0;

double cp12 = 0;
double ch12 = 0;
double asypar12 = 0.0;

namespace CH
{
	#undef  AUTO
	#define AUTO __LINE__ //returns the line number in the current file. Can be used to make life easier for histogram numbering.

	void histograms_class::UserAnalysis(reaction_struct *reac, electron_class ** e, ion_class ** r, diatomic_class * mol, polyatomic_class * big_mol, CH_event_struct *evt) {
		
	///*	
		// Number of possible user histograms.
		MaxUserHists = 20000;


		




		histo_handler *Hist = this->Hist_User;
		int ehit = evt->e.num_hits;
		int rhit = evt->r.num_hits;
		
		// Example how to acces scanning values from scanning array...
		// get the pointer of the vector!
		double* scan_val = 0;
		if(evt->scanval.size()>0)
			scan_val = &evt->scanval[0];

		char reaction_dir[360];
		
		if(this->use_master_folder) {
			strcpy(reaction_dir,this->CH_master_folder);
			strcat(reaction_dir,reac->name);
		} else
			strcpy(reaction_dir,reac->name);	

		int ID = reac->ID;
		string dir = reaction_dir;
		string old_dir = reaction_dir;
		/*
		// example: process reaction with ID 3, which is a diatomic
		if(ID == 3) {
			if(mol->valid) {
				Hist->fill1(AUTO, "KER",mol->KER(),1.0,"kinetic energy release",100,0.,15.0,"KER [eV]",reaction_dir);
				if(ehit>0) {
					if(e[0]->valid) 
						Hist->fill2(AUTO, "ctheta_ee",e[0]->mom.Cos_Theta(),e[0]->energy(),1.0,"cos theta vs electron energy",36,-1.,1.,"cos(theta)",200,0.0,10.,"electron energy [eV]",reaction_dir);
				}
			}
		}
		*/
		
		//MFPAD/KER/Prel testing bullshit
		/*
	{
		dir = reaction_dir;
		dir += "/PRelTest";

		Hist->fill1(AUTO, "Sum KER P squared over 2m", ((e[0]->mom.Mag()*e[0]->mom.Mag()) / (2 * e[0]->raw.m) + (r[0]->mom.Mag()*r[0]->mom.Mag()) / (2 * r[0]->raw.m) + (r[1]->mom.Mag()*r[1]->mom.Mag()) / (2 * r[1]->raw.m)), 1.0, "kinetic energy release", 1000, 0., 100, "KER [eV]", dir.c_str());//custom ker
		Hist->fill1(AUTO, "KER mol", mol->KER(), 1.0, "kinetic energy release", 1000, 0., .02, "KER [eV]", dir.c_str()); //default ker is fucked?
		Hist->fill1(AUTO, "e energy + r energy", e[0]->energy() + r[0]->energy(), 1.0, " energy sum", 100, 0., 100, "KER [eV]", dir.c_str());
		Hist->fill1(AUTO, "small number test", (1e-38), 1.0, "small number test", 100, 0, (2e-38), "small number test", dir.c_str());//custom ker

		Hist->fill1(AUTO, "Electron Energy", e[0]->energy(), 1.0, "electron energy ", 100, 0., 20, "E [eV]", dir.c_str());
		Hist->fill1(AUTO, "recoil Energy", r[0]->energy(), 1.0, "recoil energy ", 100, 0., 5, "E [eV]", dir.c_str());

		Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
		Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil mass ", 100, 0., 10, "m amu", dir.c_str());
		Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil mass ", 100, 0., 10, "m amu", dir.c_str());
		Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil mass ", 100, 0., 10, "q au", dir.c_str());
		Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil mass ", 100, 0., 10, "q qu", dir.c_str());

		Hist->fill1(AUTO, "mom rel x", mol->mom_rel.x, 1.0, "relative momentum in x", 1000, 0., 10, "m amu", dir.c_str());
		Hist->fill1(AUTO, "mom rel y", mol->mom_rel.y, 1.0, "relative momentum in y", 1000, 0., 10, "m amu", dir.c_str());
		Hist->fill1(AUTO, "mom rel z", mol->mom_rel.z, 1.0, "relative momentum in z", 1000, 0., 10, "m amu", dir.c_str());
		Hist->fill1(AUTO, "mom rel mag", mol->mom_rel.Mag(), 1.0, "relative momentum in x", 1000, 0., 10, "m amu", dir.c_str());

		Hist->fill1(AUTO, "mom mag e", e[0]->mom.Mag(), 1.0, "magnitude of electron momentum", 1000, 0., 10, "m amu", dir.c_str());
		Hist->fill1(AUTO, "mom mag r1", r[0]->mom.Mag(), 1.0, "magnitude of recoil 1 momentum", 1000, 0., 10, "m amu", dir.c_str());
		Hist->fill1(AUTO, "mom mag r2", r[1]->mom.Mag(), 1.0, "magnitude of recoil 2 momentum", 1000, 0., 10, "m amu", dir.c_str());

		Hist->fill1(AUTO, "reduced mass", r[0]->raw.m * MASSAU * r[1]->raw.m  * MASSAU / (r[0]->raw.m * MASSAU + r[1]->raw.m * MASSAU), 1.0, "reduced mass", 2000, 0., 2000, "m amu", dir.c_str());

		Hist->fill1(AUTO, "m0", r[0]->raw.m * MUKG, 1.0, "mass 0 in kg", 1000, 0., 1e-26, "kg", dir.c_str());
		Hist->fill1(AUTO, "m1", r[1]->raw.m * MUKG, 1.0, "mass 1 in kg", 1000, 0., 1e-26, "kg", dir.c_str());
		Hist->fill1(AUTO, "q0", r[0]->raw.q * COULOMB, 1.0, "charge 0 in coulumb", 1000, 0., 1e-18, "coulumb", dir.c_str());
		Hist->fill1(AUTO, "q1", r[1]->raw.q * COULOMB, 1.0, "charge 1 in coulumb", 1000, 0., 1e-18, "coulumb", dir.c_str());
		Hist->fill1(AUTO, "t0", r[0]->raw.data.tof * 1e-9, 1.0, "tof 0 in s", 1000, 0., 1e-6, "s", dir.c_str());
		Hist->fill1(AUTO, "t2", r[1]->raw.data.tof * 1e-9, 1.0, "tof 1 in s", 1000, 0., 1e-6, "s", dir.c_str());
		Hist->fill1(AUTO, "x1", r[0]->raw.data.x / 1000.0, 1.0, "x0 in m", 1000, 0., 1e-6, "m", dir.c_str());
		Hist->fill1(AUTO, "x2", r[1]->raw.data.x / 1000.0, 1.0, "x1 in m", 1000, 0., 1e-6, "m", dir.c_str());
		Hist->fill1(AUTO, "y1", r[0]->raw.data.y / 1000.0, 1.0, "x0 in m", 1000, 0., 1e-6, "m", dir.c_str());
		Hist->fill1(AUTO, "y2", r[1]->raw.data.y / 1000.0, 1.0, "x1 in m", 1000, 0., 1e-6, "m", dir.c_str());

		Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 10, "", dir.c_str());
		Hist->fill1(AUTO, "ker tiny", (tiny_ker), 1.0, "KER", 1000, 0., 10, "eV", dir.c_str());

		dir = reaction_dir;
		dir += "/TinyTest";
	}
	*/	
		eventnumber = eventnumber + 1;

		//A
//H2 -> H p+ e-
/*
		double xlow = -.9;
		double xhigh = .67;
		double ylow = .355;
		double yhigh = 1.9;
		double zlow = 6.45;
		double zhigh = 7.9;

		ylow = 0;
		yhigh = 2.1;
		zlow = 6.35;
		zhigh = 8;
		xhigh = 0.8;
		xlow = -1.1;
		double pxcent = -.08;
		double pycent = 1.05;
		double pxyradius = 1.25;
		*/

		double xlow = -.9;
		double xhigh = .67;
		double ylow = .355;
		double yhigh = 1.9;
		double zlow = 6.45;
		double zhigh = 7.9;

		ylow = .2;
		ylow = 0;

		yhigh = 2.05;
		yhigh = 2.1;

		zlow = 6.35;
		zhigh = 8;
		xhigh = 0.8;
		xlow = -1.1;
		double pxcent = -.08;
		double pycent = 1.05;
		double pxyradius = 1.25;
		//H2 -> H2+ e-
		if (ID == 10)// && r[0]->mom.z > 0)

		{//Tiny using tag from presort 
			//Since default relative momentum, KER, and MFPAD all hate me and refuse to work
			
			
			/*{

				if ((r[0]->mom.y < yhigh && r[0]->mom.y > ylow && r[0]->mom.z < zhigh && r[0]->mom.z > zlow) && (r[0]->mom.x > xlow && r[0]->mom.x < xhigh && r[0]->mom.z > zlow && r[0]->mom.z < zhigh) && (sqrt(pow(r[0]->mom.x - pxcent, 2) + pow(r[0]->mom.y - pycent, 2)) < pxyradius)) {//Tiny using tag from presort 

					r[0]->mom.x = -1000;
					r[0]->mom.y = -1000;
					r[0]->mom.z = -1000;
				}
				//*/

			/*
				//Horizontal sheers to flatten Phi YZ plots
				double rskewfactor = .0325;
				r[0]->mom.z = r[0]->mom.z + rskewfactor * r[0]->mom.y;
				double eskewfactor = .01;
				e[0]->mom.z = e[0]->mom.z + eskewfactor * e[0]->mom.y;
				//suggested by Thorsten to try to fix waviness in Phy xy
				double eskewfactorx = .025;
				e[0]->mom.x = e[0]->mom.x + eskewfactorx * e[0]->mom.y;
				//trying this for lulz
				double eskewfactorzx = +.01;
				e[0]->mom.z = e[0]->mom.z + eskewfactorzx * e[0]->mom.x;
				*/
				/*//Correct for Electron Momentum Kick
				r[0]->mom.x = r[0]->mom.x + .5 * e[0]->mom.x;
				r[0]->mom.y = r[0]->mom.y + .5 * e[0]->mom.y;
				r[0]->mom.z = r[0]->mom.z + .5 * e[0]->mom.z;
				//*
			}*/
			quickcal = 0;
			getasypar = 1;
			double binsize = .4;
			double asyparthreshold = cos(90 * PI / 180);
			double tinymom_relx = (2 * r[0]->mom.x + e[0]->mom.x) / 2.0;
			double tinymom_rely = (2 * r[0]->mom.y + e[0]->mom.y) / 2.0;
			double tinymom_relz = (2 * r[0]->mom.z + e[0]->mom.z) / 2.0;
			double tinymom_relmag = sqrt(pow(tinymom_relx, 2) + pow(tinymom_rely, 2) + pow(tinymom_relz, 2));
			double tinyreducded_mass = (r[0]->raw.m * r[1]->raw.m) / (r[0]->raw.m + r[1]->raw.m) * MASSAU;
			double tiny_ker = ((tinymom_relmag * tinymom_relmag) / (2.0 * tinyreducded_mass))*EVAU;

			/*
			if ((tiny_ker < 1.325 && tiny_ker > .95) && ((r[0]->raw.data.tof < 2900 && r[0]->raw.data.tof > 2700) || (r[0]->raw.data.tof < 1925 && r[0]->raw.data.tof > 1725)))

			{
				xlow = -1.5;
				xhigh = 1;
				ylow = -1;
				yhigh = 2;
				zlow = -10;
				zhigh = -8;
				pxcent = -.15;
				pycent = .5;
				pxyradius = 1.35;

				if ((r[0]->mom.y < yhigh && r[0]->mom.y > ylow && r[0]->mom.z < zhigh && r[0]->mom.z > zlow) && (r[0]->mom.x > xlow && r[0]->mom.x < xhigh && r[0]->mom.z > zlow && r[0]->mom.z < zhigh) && (sqrt(pow(r[0]->mom.x - pxcent, 2) + pow(r[0]->mom.y - pycent, 2)) < pxyradius)) {//Tiny using tag from presort 

					r[0]->mom.x = -1000;
					r[0]->mom.y = -1000;
					r[0]->mom.z = -1000;
				}

			}
			*/
			//	if ((tiny_ker < .35) && ((r[0]->raw.data.tof < 2225 && r[0]->raw.data.tof > 2125) || (r[0]->raw.data.tof < 2550 && r[0]->raw.data.tof > 2425)))
			
			/*
			if ((tiny_ker < .37))
			{
				xlow = -1.5;
				xhigh = 1.25;
				ylow = -1;
				yhigh = 2;
				zlow = -4.75;
				zhigh = -2.5;
				pxcent = .14;
				pycent = .66;
				pxyradius = 1.4;

				if ((r[0]->mom.y < yhigh && r[0]->mom.y > ylow && r[0]->mom.z < zhigh && r[0]->mom.z > zlow) && (r[0]->mom.x > xlow && r[0]->mom.x < xhigh && r[0]->mom.z > zlow && r[0]->mom.z < zhigh)) {//Tiny using tag from presort 

					r[0]->mom.x = -1000;
					r[0]->mom.y = -1000;
					r[0]->mom.z = -1000;
				}

				xlow = -1.2;
				xhigh = 1;
				ylow = -.6;
				yhigh = 2;
				zlow = .3;
				zhigh = 2.1;
				pxcent = .14;
				pycent = .66;
				pxyradius = 1.4;

				if ((r[0]->mom.y < yhigh && r[0]->mom.y > ylow && r[0]->mom.z < zhigh && r[0]->mom.z > zlow) && (r[0]->mom.x > xlow && r[0]->mom.x < xhigh && r[0]->mom.z > zlow && r[0]->mom.z < zhigh)) {//Tiny using tag from presort 

					r[0]->mom.x = -1000;
					r[0]->mom.y = -1000;
					r[0]->mom.z = -1000;
				}
			}
			*/
			/*
			e[0]->mom = e[0]->mom*.785 + e[0]->mom.Norm() *0.045;
			r[0]->mom = r[0]->mom *.94 + r[0]->mom.Norm() *0.3;// gets -1 slope 
			//*/
			e[0]->mom = e[0]->mom*.909;// +e[0]->mom.Norm() *.036;

			double ex = e[0]->mom.Mag();
			e[0]->mom = e[0]->mom.Norm() * (1.015*ex + 0.0269); // linear
			//from fit y = 1.015x + 0.0269

			//from fit y = 0.4121x2 + 0.8187x + 0.0465
			//e[0]->mom = e[0]->mom.Norm() * (0.4121*ex*ex + 0.8187*ex + 0.0465); // quadratic

			tinymom_relx = (2 * r[0]->mom.x + e[0]->mom.x) / 2.0;
			tinymom_rely = (2 * r[0]->mom.y + e[0]->mom.y) / 2.0;
			tinymom_relz = (2 * r[0]->mom.z + e[0]->mom.z) / 2.0;
			tinymom_relmag = sqrt(pow(tinymom_relx, 2) + pow(tinymom_rely, 2) + pow(tinymom_relz, 2));
			tinyreducded_mass = (r[0]->raw.m * r[1]->raw.m) / (r[0]->raw.m + r[1]->raw.m) * MASSAU;
			tiny_ker = ((tinymom_relmag * tinymom_relmag) / (2.0 * tinyreducded_mass))*EVAU;


			CH_vector tinyekick = e[0]->mom;
			tinyekick.x = .5*e[0]->mom.x;
			tinyekick.y = .5*e[0]->mom.y;
			tinyekick.z = .5*e[0]->mom.z;
			CH_vector tinycmrec = r[0]->mom + tinyekick;
			double tiny_mfpad = cos(e[0]->mom.Angle(tinycmrec));//Correct for electron momentum kick 
			//double tiny_mfpad = cos(e[0]->mom.Angle(r[0]->mom));
			//double tiny_mfpad = cos(e[0]->mom.Angle(r[0]->mom + tinyekick));//Correct for electron momentum kick without declaring an extra vector
			double tinyKErec = pow(r[0]->mom.Mag(), 2) / (2 * r[0]->raw.m*MASSAU) *EVAU;
			double tinyKEelec = pow(e[0]->mom.Mag(), 2) / (2 * e[0]->raw.m*MASSAU) *EVAU;
			double tinyKE = tinyKErec + tinyKEelec;
			double etofmin = 0;
			double etofmax = 200;
			double rtofmin = 500;
			double rtofmax = 5000;
			double recpmaggatelow = 0;
			double recpmaggatehigh = 6;
			double elecpmaggatelow = 0;
			double elecpmaggatehigh = .2;
			double elecEcenter = 0;
			double kercenter = 0;
			double ekerradius = 0;

			double thetaZthreshold = cos(45 * PI / 180);


			 etofmin = 0;
			 etofmax = 200;
			 rtofmin = 2700;
			 rtofmax = 2900;

			double tinyThetaX = atan((e[0]->mom.x) / (pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)));
			double tinyThetaY = atan((e[0]->mom.y) / (pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)));
			double tinyThetaZ = atan((e[0]->mom.z) / (pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)));

			double tinyPhiXY = atan2((e[0]->mom.x), (e[0]->mom.y));
			double tinyPhiYZ = atan2((e[0]->mom.y), (e[0]->mom.z));
			double tinyPhiZX = atan2((e[0]->mom.z), (e[0]->mom.x));

			double tinyPEXY = sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2));
			double tinyPEZY = sqrt(pow(e[0]->mom.z, 2) + pow(e[0]->mom.y, 2));
			double tinyPEXZ = sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.z, 2));

			double tinyPRXY = sqrt(pow(r[0]->mom.x, 2) + pow(r[0]->mom.y, 2));
			double tinyPRZY = sqrt(pow(r[0]->mom.z, 2) + pow(r[0]->mom.y, 2));
			double tinyPRXZ = sqrt(pow(r[0]->mom.x, 2) + pow(r[0]->mom.z, 2));

			dir = reaction_dir;
			dir += "/TinyTestH2->H2+e-";
			
			if(r[0]->raw.data.tof> 3120 &&  r[0]->raw.data.tof< 3190)
			{

				{//Momentum Angle stuff
					dir += "/Angle stuff (all P)";

					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());

					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());




					Hist->fill2(AUTO, "KER vs recoil Theta X", r[0]->mom.ThetaX(), tiny_ker, 1.0, "KER vs recoil Theta X", 150, 0, PI, "Theta X", 400, .3, 1.1, "KER", dir.c_str());
					Hist->fill2(AUTO, "KER vs recoil Theta Y", r[0]->mom.ThetaY(), tiny_ker, 1.0, "KER vs recoil Theta Y", 150, 0, PI, "Theta Y", 400, .3, 1.1, "KER", dir.c_str());
					Hist->fill2(AUTO, "KER vs recoil Theta Z", r[0]->mom.Theta(), tiny_ker, 1.0, "KER vs recoil Theta Z", 150, 0, PI, "Theta Z", 400, .3, 1.1, "KER", dir.c_str());

					Hist->fill2(AUTO, "KER vs recoil Phi XY", r[0]->mom.Phi(), tiny_ker, 1.0, "KER vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .3, 1.1, "KER", dir.c_str());
					Hist->fill2(AUTO, "KER vs recoil Phi YZ", r[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .3, 1.1, "KER", dir.c_str());
					Hist->fill2(AUTO, "KER vs recoil Phi ZX", r[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .3, 1.1, "KER", dir.c_str());

					Hist->fill2(AUTO, "Electron energy vs Theta X", e[0]->mom.ThetaX(), e[0]->energy(), 1.0, "Electron energy vs Theta X", 150, 0, PI, "Theta X", 400, .5, 1.4, "Electron energy", dir.c_str());
					Hist->fill2(AUTO, "Electron energy vs Theta Y", e[0]->mom.ThetaY(), e[0]->energy(), 1.0, "Electron energy vs Theta Y", 150, 0, PI, "Theta Y", 400, .5, 1.4, "Electron energy", dir.c_str());
					Hist->fill2(AUTO, "Electron energy vs Theta Z", e[0]->mom.Theta(), e[0]->energy(), 1.0, "Electron energy vs Theta Z", 150, 0, PI, "Theta Z", 400, .5, 1.4, "Electron energy", dir.c_str());

					Hist->fill2(AUTO, "Electron energy vs Phi XY", e[0]->mom.Phi(), e[0]->energy(), 1.0, "Electron energy vs Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .5, 1.4, "Electron energy", dir.c_str());
					Hist->fill2(AUTO, "Electron energy vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->energy(), 1.0, "Electron energy vs Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .5, 1.4, "Electron energy", dir.c_str());
					Hist->fill2(AUTO, "Electron energy vs Phi ZX", e[0]->mom.PhiZX(), e[0]->energy(), 1.0, "Electron energy vs Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .5, 1.4, "Electron energy", dir.c_str());

					Hist->fill2(AUTO, "Recoil Theta Z vs Electron Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Recoil Theta Z vs Electron Theta Z", 150, 0, PI, "Electron Theta Z", 150, 0, PI, "Recoil Theta Z", dir.c_str());
					Hist->fill1(AUTO, "Recoil Theta Z", r[0]->mom.Theta(), 1.0, "Recoil Theta Z", 150, 0, PI, "theta z", dir.c_str());
					Hist->fill1(AUTO, "Electron Theta Z", e[0]->mom.Theta(), 1.0, "Electron Theta Z", 150, 0, PI, "theta z", dir.c_str());

					Hist->fill2(AUTO, "Recoil cos Theta Z vs Electron cos Theta Z", cos(e[0]->mom.Theta()), cos(r[0]->mom.Theta()), 1.0, "Recoil cos Theta Z vs Electron cos Theta Z", 150, -1, 1, "Electron cos Theta Z", 150, -1, 1, "Recoil cos Theta Z", dir.c_str());
					Hist->fill1(AUTO, "Recoil cos Theta Z", cos(r[0]->mom.Theta()), 1.0, "Recoil cos Theta Z", 150, -1, 1, "cos theta z", dir.c_str());
					Hist->fill1(AUTO, "Electron cos Theta Z", cos(e[0]->mom.Theta()), 1.0, "Electron cos Theta Z", 150, -1, 1, "cos theta z", dir.c_str());




					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";
				}

				Hist->fill1(AUTO, "Electron Energy", e[0]->energy(), 1.0, "Electron Energy", 100, 0, 5, "eV", dir.c_str());
				Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
				Hist->fill1(AUTO, "Electron Energy very fine", e[0]->energy(), 1.0, "Electron Energy", 1000, 0, 5, "eV", dir.c_str());

				Hist->fill1(AUTO, " Electron Momentum", sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)), 1.0, " Electron Momentum", 1000, 0, 1, "p", dir.c_str());


				double eelow = 1.95;
				double eehigh = 2.04;
				string vibstate = "/v0";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}

				eelow = 1.73;
				eehigh = 1.847;
				vibstate = "/v1";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}


				eelow = 1.55;
				eehigh = 1.66;
				vibstate = "/v2";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}


				eelow = 1.38;
				eehigh = 1.47;
				vibstate = "/v3";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}



				eelow = 1.22;
				eehigh = 1.32;
				vibstate = "/v4";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}


				eelow = 1.06;
				eehigh = 1.15;
				vibstate = "/v5";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}



				eelow = .90;
				eehigh = .995;
				vibstate = "/v6";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}




				eelow = .77;
				eehigh = .85;
				vibstate = "/v7";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}




				eelow = .639;
				eehigh = .71;
				vibstate = "/v8";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}



				eelow = .51;
				eehigh = .58;
				vibstate = "/v9";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}



				eelow = .37;
				eehigh = .45;
				vibstate = "/v10";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}



				eelow = .26;
				eehigh = .32;
				vibstate = "/v11";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}



				eelow = .143;
				eehigh = .21;
				vibstate = "/v12";

				if (e[0]->energy() > eelow &&  e[0]->energy() < eehigh)
				{
					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

					dir += vibstate;

					Hist->fill1(AUTO, "Electron Energy Fine", e[0]->energy(), 1.0, "Electron Energy Fine", 500, 0, 5, "eV", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
					Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());
					Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
					Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());

					dir = reaction_dir;
					dir += "/TinyTestH2->H2+e-";
					dir += "/H2+";

				}

				dir += "/All Methods";
				Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
				Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
				Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 501, -1., 20., "rec p (au)", 501, -1, 20., "elec p (au)", dir.c_str());
				Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 501, -1., 20., "rec KE eV", 591, -1, 20., "elec KE eV", dir.c_str());
				Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
				Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
				Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
				Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
				Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
				Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
				Hist->fill2(AUTO, "Ultra fine TOF vs Etime", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (all methods)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
				Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (all methods)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
				Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (all methods)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", dir.c_str());
				Hist->fill1(AUTO, "Number of hits", evt->e.num_hits, 1.0, "Number Electron Hits (all methods)", 10, 0, 11, "", dir.c_str());
				Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
				Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
				Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (all methods)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
				Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (all methods)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
				Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -4, 4, "p au", dir.c_str());
				Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -4., 4, "p au", dir.c_str());
				Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -4., 4, "p au", dir.c_str());
				Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -4., 4, "p au", dir.c_str());
				Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -4., 4, "p au", dir.c_str());
				Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -4., 4, "p au", dir.c_str());
				Hist->fill1(AUTO, "psum x", r[0]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -4., 4, "p au", dir.c_str());
				Hist->fill1(AUTO, "psum y", r[0]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -4., 4, "p au", dir.c_str());
				Hist->fill1(AUTO, "psum z", r[0]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -4., 4, "p au", dir.c_str());
				Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
				Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
				Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
				Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
				Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
				Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());


				dir += "/Tiny MFPAD";
				Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
				Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 2000, 0., 15, "eV", dir.c_str());

				Hist->fill1(AUTO, "MFPAD tiny", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


				Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
				Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());




				dir = reaction_dir;
				dir += "/TinyTestH2->H2+e-";







			}
				}




		if (ID == 11 ) {//Tiny using tag from presort 
					//Since default relative momentum, KER, and MFPAD all hate me and refuse to work
			
			
			if ((r[0]->mom.y < yhigh && r[0]->mom.y > ylow && r[0]->mom.z < zhigh && r[0]->mom.z > zlow) && (r[0]->mom.x > xlow && r[0]->mom.x < xhigh && r[0]->mom.z > zlow && r[0]->mom.z < zhigh) && (sqrt(pow(r[0]->mom.x - pxcent, 2) + pow(r[0]->mom.y - pycent, 2)) < pxyradius)) {//Tiny using tag from presort 

				r[0]->mom.x = -1000;
				r[0]->mom.y = -1000;
				r[0]->mom.z = -1000;
			}//*/


			//Horizontal sheers to flatten Phi YZ plots
			double rskewfactor = .0325;
			r[0]->mom.z = r[0]->mom.z + rskewfactor * r[0]->mom.y;
			double eskewfactor = .01;
			e[0]->mom.z = e[0]->mom.z + eskewfactor * e[0]->mom.y;
			//suggested by Thorsten to try to fix waviness in Phy xy
			double eskewfactorx = .025;
			e[0]->mom.x = e[0]->mom.x + eskewfactorx * e[0]->mom.y;
			//trying this for lulz
			double eskewfactorzx = +.01;
			e[0]->mom.z = e[0]->mom.z + eskewfactorzx * e[0]->mom.x;

			/*//Correct for Electron Momentum Kick
			r[0]->mom.x = r[0]->mom.x + .5 * e[0]->mom.x;
			r[0]->mom.y = r[0]->mom.y + .5 * e[0]->mom.y;
			r[0]->mom.z = r[0]->mom.z + .5 * e[0]->mom.z;
			*/

			quickcal = 0;
			getasypar = 1;
			double binsize = .4;
			double asyparthreshold = cos(90 * PI / 180);
			double tinymom_relx = (2 * r[0]->mom.x + e[0]->mom.x) / 2.0;
			double tinymom_rely = (2 * r[0]->mom.y + e[0]->mom.y) / 2.0;
			double tinymom_relz = (2 * r[0]->mom.z + e[0]->mom.z) / 2.0;
			double tinymom_relmag = sqrt(pow(tinymom_relx, 2) + pow(tinymom_rely, 2) + pow(tinymom_relz, 2));
			double tinyreducded_mass = (r[0]->raw.m * r[1]->raw.m) / (r[0]->raw.m + r[1]->raw.m) * MASSAU;
			double tiny_ker = ((tinymom_relmag * tinymom_relmag) / (2.0 * tinyreducded_mass))*EVAU;


				if ( (tiny_ker < 1.325 && tiny_ker > .95) && ((r[0]->raw.data.tof < 2900 && r[0]->raw.data.tof > 2700) || (r[0]->raw.data.tof < 1925 && r[0]->raw.data.tof > 1725)) )

				{
					 xlow = -1.5;
					 xhigh = 1;
					 ylow = -1;
					 yhigh = 2;
					 zlow = -10;
					 zhigh = -8;
					 pxcent = -.15;
					 pycent = .5;
					 pxyradius = 1.35;

					if ((r[0]->mom.y < yhigh && r[0]->mom.y > ylow && r[0]->mom.z < zhigh && r[0]->mom.z > zlow) && (r[0]->mom.x > xlow && r[0]->mom.x < xhigh && r[0]->mom.z > zlow && r[0]->mom.z < zhigh) && (sqrt(pow(r[0]->mom.x - pxcent, 2) + pow(r[0]->mom.y - pycent, 2)) < pxyradius)) {//Tiny using tag from presort 

						r[0]->mom.x = -1000;
						r[0]->mom.y = -1000;
						r[0]->mom.z = -1000;
					}//*/

				}

				//	if ((tiny_ker < .35) && ((r[0]->raw.data.tof < 2225 && r[0]->raw.data.tof > 2125) || (r[0]->raw.data.tof < 2550 && r[0]->raw.data.tof > 2425)))
				if ((tiny_ker < .37))
				{
					xlow = -1.5;
					xhigh = 1.25;
					ylow = -1;
					yhigh = 2;
					zlow = -4.75;
					zhigh = -2.5;
					pxcent = .14;
					pycent = .66;
					pxyradius = 1.4;

					if ((r[0]->mom.y < yhigh && r[0]->mom.y > ylow && r[0]->mom.z < zhigh && r[0]->mom.z > zlow) && (r[0]->mom.x > xlow && r[0]->mom.x < xhigh && r[0]->mom.z > zlow && r[0]->mom.z < zhigh)) {//Tiny using tag from presort 

						r[0]->mom.x = -1000;
						r[0]->mom.y = -1000;
						r[0]->mom.z = -1000;
					}//*/

					xlow = -1.2;
					xhigh = 1;
					ylow = -.6;
					yhigh = 2;
					zlow = .3;
					zhigh = 2.1;
					pxcent = .14;
					pycent = .66;
					pxyradius = 1.4;

					if ((r[0]->mom.y < yhigh && r[0]->mom.y > ylow && r[0]->mom.z < zhigh && r[0]->mom.z > zlow) && (r[0]->mom.x > xlow && r[0]->mom.x < xhigh && r[0]->mom.z > zlow && r[0]->mom.z < zhigh)) {//Tiny using tag from presort 

						r[0]->mom.x = -1000;
						r[0]->mom.y = -1000;
						r[0]->mom.z = -1000;
					}
				}

			//	e[0]->mom = e[0]->mom*.785 + e[0]->mom.Norm() *0.045;
			//	r[0]->mom = r[0]->mom *.94 + r[0]->mom.Norm() *0.3;// gets -1 slope 

				double ex = e[0]->mom.Mag();
				e[0]->mom = e[0]->mom + e[0]->mom.Norm() * (-0.2131*ex + 0.0444);

				double rx = r[0]->mom.Mag();
				r[0]->mom = r[0]->mom + r[0]->mom.Norm() * (-0.0674*rx + 0.3505);// gets -1 slope 

			tinymom_relx = (2 * r[0]->mom.x + e[0]->mom.x) / 2.0;
			tinymom_rely = (2 * r[0]->mom.y + e[0]->mom.y) / 2.0;
			tinymom_relz = (2 * r[0]->mom.z + e[0]->mom.z) / 2.0;
			tinymom_relmag = sqrt(pow(tinymom_relx, 2) + pow(tinymom_rely, 2) + pow(tinymom_relz, 2));
			tinyreducded_mass = (r[0]->raw.m * r[1]->raw.m) / (r[0]->raw.m + r[1]->raw.m) * MASSAU;
			tiny_ker = ((tinymom_relmag * tinymom_relmag) / (2.0 * tinyreducded_mass))*EVAU;


			CH_vector tinyekick = e[0]->mom;
			tinyekick.x = .5*e[0]->mom.x;
			tinyekick.y = .5*e[0]->mom.y;
			tinyekick.z = .5*e[0]->mom.z;
			CH_vector tinycmrec = r[0]->mom + tinyekick;
			double tiny_mfpad = cos(e[0]->mom.Angle(tinycmrec));//Correct for electron momentum kick 
			//double tiny_mfpad = cos(e[0]->mom.Angle(r[0]->mom));
			//double tiny_mfpad = cos(e[0]->mom.Angle(r[0]->mom + tinyekick));//Correct for electron momentum kick without declaring an extra vector
			double tinyKErec = pow(r[0]->mom.Mag(), 2) / (2 * r[0]->raw.m*MASSAU) *EVAU;
			double tinyKEelec = pow(e[0]->mom.Mag(), 2) / (2 * e[0]->raw.m*MASSAU) *EVAU;
			double tinyKE = tinyKErec + tinyKEelec;
			double etofmin = 0;
			double etofmax = 200;
			double rtofmin = 500;
			double rtofmax = 5000;
			double recpmaggatelow = 0;
			double recpmaggatehigh = 6;
			double elecpmaggatelow = 0;
			double elecpmaggatehigh = .2;
			double elecEcenter = 0;
			double kercenter = 0;
			double ekerradius = 0;

			double thetaZthreshold = cos(45 * PI / 180);


			//if (e[0]->mom.z < 0)
			if ((r[0]->raw.data.tof < 2900 && r[0]->raw.data.tof > 1600)) {

//			if (cos(r[0]->mom.Theta()) < -.7 || cos(r[0]->mom.Theta()) > .7)//everybody gets a theta z cut
			//if ((cos(r[0]->mom.Theta()) < -thetaZthreshold || cos(r[0]->mom.Theta()) > thetaZthreshold) && (cos(e[0]->mom.Theta()) < -thetaZthreshold || cos(e[0]->mom.Theta()) > thetaZthreshold))//everybody gets a theta z cut
			//if (cos(r[0]->mom.Theta()) < -.65 || cos(r[0]->mom.Theta()) > .65)//everybody gets a theta z cut

				{
					dir = reaction_dir;
					dir += "/TinyTestH2->Hp+e-";

					//big window
					{
						dir += "/Big window";
						if (abs(e[0]->energy() - (-1.0*(tiny_ker)+1.025)) < .16)
						{

							Hist->fill2(AUTO, "Electron energy vs KER diagonal", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
						}

						//Hist->fill1(Plot Number, "Plot Title", variable to plot, 1.0, "Display Title", Number of bins, Min value, Max value, "Axis label", dir.c_str());

						Hist->fill1(AUTO, "Electron Energy", e[0]->energy(), 1.0, "Electron Energy", 100, 0, 5, "eV", dir.c_str());

						//Hist->fill2(Plot Number, "Plot Title", x variable, y variable, 1.0, "Display Title", Number of x bins, Minimum x value, Max x value, "x axis label", Number of y bins, Minimum y value, Max y value, "y axis label", dir.c_str());

						Hist->fill2(AUTO, "Electron energy vs KER", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());

						Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
						Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 1500, 0, 2, "KER", 1500, 0, 1.6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER 800", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 800, 0, 6, "KER", 800, 0, 6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER bigbin", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 200, 0, 2, "KER", 160, 0, 1.6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 801, 0., 10., "rec p (au)", 801, 0, 5, "elec p (au)", dir.c_str());
						Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 501, 0., 5, "rec KE eV", 591, 0, 5, "elec KE eV", dir.c_str());
						Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
						Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
						Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
						Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
						Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
						Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine Etime vs TOF", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (Methods < 7)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, 38.20, 71.18, "TOF (ns)" "time (ns)", dir.c_str());
						Hist->fill1(AUTO, "Number of hits", evt->e.num_hits, 1.0, "Number Electron Hits (Methods < 7)", 10, 0, 11, "", dir.c_str());
						Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
						Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
						Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (Methods < 7)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (Methods < 7)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
						Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
						Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
						Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
						Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
						Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
						Hist->fill1(AUTO, "tiny rec 2 mom x", -r[0]->mom.x - e[0]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "tiny rec 2 mom y", -r[0]->mom.y - e[0]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "tiny rec 2 mom z", -r[0]->mom.z - e[0]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());

						Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
						Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
						Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());


						dir = reaction_dir;
						dir += "/TinyTestH2->Hp+e-";
					}

					//H+ ground state
					/*if (r[0]->mom.Mag() > recpmaggatelow && r[0]->mom.Mag() < recpmaggatehigh && e[0]->mom.Mag() > elecpmaggatelow && e[0]->mom.Mag() < elecpmaggatehigh) {


					if (abs(e[0]->energy() - (-.95*(tiny_ker - 0) +.39)) < .13) {

						dir += "/H+";

						Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
						Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 1500, 0, 2, "KER", 1500, 0, 1.6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER bigbin", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 200, 0, 2, "KER", 160, 0, 1.6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 801, 0., 10., "rec p (au)", 801, 0, 5, "elec p (au)", dir.c_str());
						Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 501, 0., 5, "rec KE eV", 591, 0, 5, "elec KE eV", dir.c_str());
						Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
						Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
						Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
						Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
						Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
						Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine Etime vs TOF", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (Methods < 7)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, 38.20, 71.18, "TOF (ns)" "time (ns)", dir.c_str());
						Hist->fill1(AUTO, "Number of hits", evt->e.num_hits, 1.0, "Number Electron Hits (Methods < 7)", 10, 0, 11, "", dir.c_str());
						Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
						Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
						Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (Methods < 7)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (Methods < 7)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
						Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
						Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
						Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
						Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
						Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
						Hist->fill1(AUTO, "tiny rec 2 mom x", -r[0]->mom.x - e[0]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "tiny rec 2 mom y", -r[0]->mom.y - e[0]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "tiny rec 2 mom z", -r[0]->mom.z - e[0]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());

						Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
						Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
						Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());
						dir += "/Tiny MFPAD";



						{if (getasypar == 1) {

							if (binsize == .2) {
								if (e[0]->energy() > .00 && e[0]->energy() < .02) {
									if (tiny_mfpad > asyparthreshold) {
										cph1 = cph1 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh1 = chh1 + 1;
									}

									asyparh1 = (cph1 - chh1) / (cph1 + chh1);
								}


								if (e[0]->energy() > .02 && e[0]->energy() < .04) {
									if (tiny_mfpad > asyparthreshold) {
										cph2 = cph2 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh2 = chh2 + 1;
									}

									asyparh2 = (cph2 - chh2) / (cph2 + chh2);
								}

								if (e[0]->energy() > .04 && e[0]->energy() < .06) {
									if (tiny_mfpad > asyparthreshold) {
										cph3 = cph3 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh3 = chh3 + 1;
									}

									asyparh3 = (cph3 - chh3) / (cph3 + chh3);
								}

								if (e[0]->energy() > .06 && e[0]->energy() < .08) {
									if (tiny_mfpad > asyparthreshold) {
										cph4 = cph4 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh4 = chh4 + 1;
									}

									asyparh4 = (cph4 - chh4) / (cph4 + chh4);
								}

								if (e[0]->energy() > .08 && e[0]->energy() < .10) {
									if (tiny_mfpad > asyparthreshold) {
										cph5 = cph5 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh5 = chh5 + 1;
									}

									asyparh5 = (cph5 - chh5) / (cph5 + chh5);
								}

								if (e[0]->energy() > .10 && e[0]->energy() < .12) {
									if (tiny_mfpad > asyparthreshold) {
										cph6 = cph6 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh6 = chh6 + 1;
									}

									asyparh6 = (cph6 - chh6) / (cph6 + chh6);
								}


								if (e[0]->energy() > .12 && e[0]->energy() < .14) {
									if (tiny_mfpad > asyparthreshold) {
										cph7 = cph7 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh7 = chh7 + 1;
									}

									asyparh7 = (cph7 - chh7) / (cph7 + chh7);
								}

								if (e[0]->energy() > .14 && e[0]->energy() < .16) {
									if (tiny_mfpad > asyparthreshold) {
										cph8 = cph8 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh8 = chh8 + 1;
									}

									asyparh8 = (cph8 - chh8) / (cph8 + chh8);
								}

								if (e[0]->energy() > .16 && e[0]->energy() < .18) {
									if (tiny_mfpad > asyparthreshold) {
										cph9 = cph9 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh9 = chh9 + 1;
									}

									asyparh9 = (cph9 - chh9) / (cph9 + chh9);
								}

								if (e[0]->energy() > .18 && e[0]->energy() < .20) {
									if (tiny_mfpad > asyparthreshold) {
										cph10 = cph10 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh10 = chh10 + 1;
									}

									asyparh10 = (cph10 - chh10) / (cph10 + chh10);
								}
								if (e[0]->energy() > .20 && e[0]->energy() < .22) {
									if (tiny_mfpad > asyparthreshold) {
										cph11 = cph11 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh11 = chh11 + 1;
									}

									asyparh11 = (cph11 - chh11) / (cph11 + chh11);
								}


								if (e[0]->energy() > .22 && e[0]->energy() < .24) {
									if (tiny_mfpad > asyparthreshold) {
										cph12 = cph12 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh12 = chh12 + 1;
									}

									asyparh12 = (cph12 - chh12) / (cph12 + chh12);
								}

								if (e[0]->energy() > .24 && e[0]->energy() < .26) {
									if (tiny_mfpad > asyparthreshold) {
										cph13 = cph13 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh13 = chh13 + 1;
									}

									asyparh13 = (cph13 - chh13) / (cph13 + chh13);
								}

								if (e[0]->energy() > .26 && e[0]->energy() < .28) {
									if (tiny_mfpad > asyparthreshold) {
										cph14 = cph14 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh14 = chh14 + 1;
									}

									asyparh14 = (cph14 - chh14) / (cph14 + chh14);
								}

								if (e[0]->energy() > .28 && e[0]->energy() < .30) {
									if (tiny_mfpad > asyparthreshold) {
										cph15 = cph15 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh15 = chh15 + 1;
									}

									asyparh15 = (cph15 - chh15) / (cph15 + chh15);
								}

								if (e[0]->energy() > .30 && e[0]->energy() < .32) {
									if (tiny_mfpad > asyparthreshold) {
										cph16 = cph16 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh16 = chh16 + 1;
									}

									asyparh16 = (cph16 - chh16) / (cph16 + chh16);
								}


								if (e[0]->energy() > .32 && e[0]->energy() < .34) {
									if (tiny_mfpad > asyparthreshold) {
										cph17 = cph17 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh17 = chh17 + 1;
									}

									asyparh17 = (cph17 - chh17) / (cph17 + chh17);
								}

								if (e[0]->energy() > .34 && e[0]->energy() < .36) {
									if (tiny_mfpad > asyparthreshold) {
										cph18 = cph18 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh18 = chh18 + 1;
									}

									asyparh18 = (cph18 - chh18) / (cph18 + chh18);
								}

								if (e[0]->energy() > .36 && e[0]->energy() < .38) {
									if (tiny_mfpad > asyparthreshold) {
										cph19 = cph19 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh19 = chh19 + 1;
									}

									asyparh19 = (cph19 - chh19) / (cph19 + chh19);
								}

								if (e[0]->energy() > .38 && e[0]->energy() < .40) {
									if (tiny_mfpad > asyparthreshold) {
										cph20 = cph20 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh20 = chh20 + 1;
									}

									asyparh20 = (cph20 - chh20) / (cph20 + chh20);
								}
							}


							if (binsize == .4) {
								if (e[0]->energy() > .00 && e[0]->energy() < .04) {
									if (tiny_mfpad > asyparthreshold) {
										cph1 = cph1 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh1 = chh1 + 1;
									}

									asyparh1 = (cph1 - chh1) / (cph1 + chh1);
								}


								if (e[0]->energy() > .04 && e[0]->energy() < .08) {
									if (tiny_mfpad > asyparthreshold) {
										cph2 = cph2 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh2 = chh2 + 1;
									}

									asyparh2 = (cph2 - chh2) / (cph2 + chh2);
								}

								if (e[0]->energy() > .08 && e[0]->energy() < .12) {
									if (tiny_mfpad > asyparthreshold) {
										cph3 = cph3 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh3 = chh3 + 1;
									}

									asyparh3 = (cph3 - chh3) / (cph3 + chh3);
								}

								if (e[0]->energy() > .12 && e[0]->energy() < .16) {
									if (tiny_mfpad > asyparthreshold) {
										cph4 = cph4 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh4 = chh4 + 1;
									}

									asyparh4 = (cph4 - chh4) / (cph4 + chh4);
								}

								if (e[0]->energy() > .16 && e[0]->energy() < .20) {
									if (tiny_mfpad > asyparthreshold) {
										cph5 = cph5 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh5 = chh5 + 1;
									}

									asyparh5 = (cph5 - chh5) / (cph5 + chh5);
								}

								if (e[0]->energy() > .20 && e[0]->energy() < .24) {
									if (tiny_mfpad > asyparthreshold) {
										cph6 = cph6 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh6 = chh6 + 1;
									}

									asyparh6 = (cph6 - chh6) / (cph6 + chh6);
								}


								if (e[0]->energy() > .24 && e[0]->energy() < .28) {
									if (tiny_mfpad > asyparthreshold) {
										cph7 = cph7 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh7 = chh7 + 1;
									}

									asyparh7 = (cph7 - chh7) / (cph7 + chh7);
								}

								if (e[0]->energy() > .28 && e[0]->energy() < .32) {
									if (tiny_mfpad > asyparthreshold) {
										cph8 = cph8 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh8 = chh8 + 1;
									}

									asyparh8 = (cph8 - chh8) / (cph8 + chh8);
								}

								if (e[0]->energy() > .32 && e[0]->energy() < .36) {
									if (tiny_mfpad > asyparthreshold) {
										cph9 = cph9 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh9 = chh9 + 1;
									}

									asyparh9 = (cph9 - chh9) / (cph9 + chh9);
								}

								if (e[0]->energy() > .36 && e[0]->energy() < .40) {
									if (tiny_mfpad > asyparthreshold) {
										cph10 = cph10 + 1;
									}

									if (tiny_mfpad < -asyparthreshold) {
										chh10 = chh10 + 1;
									}

									asyparh10 = (cph10 - chh10) / (cph10 + chh10);
								}

							}

							// cout << " Asypar" << asypar;
							 //cout << " Cp" << cp;
							 //cout << " Ch" << ch;

							ofstream myfile;
							myfile.open("asypar.txt");
							myfile << "Asypar1 " << asyparh1;
							myfile << " Asypar2 " << asyparh2;
							myfile << " Asypar3 " << asyparh3;
							myfile << " Asypar4 " << asyparh4;
							myfile << " Asypar5 " << asyparh5;
							myfile << " Asypar6 " << asyparh6;
							myfile << " Asypar7 " << asyparh7;
							myfile << " Asypar8 " << asyparh8;
							myfile << " Asypar9 " << asyparh9;
							myfile << " Asypar10 " << asyparh10;
							myfile << " Asypar11 " << asyparh11;
							myfile << " Asypar12 " << asyparh12;
							myfile << " Asypar13 " << asyparh13;
							myfile << " Asypar14 " << asyparh14;
							myfile << " Asypar15 " << asyparh15;
							myfile << " Asypar16 " << asyparh16;
							myfile << " Asypar17 " << asyparh17;
							myfile << " Asypar18 " << asyparh18;
							myfile << " Asypar19 " << asyparh19;
							myfile << " Asypar20 " << asyparh20;




							// cout << " Asypar" << asypar;
							//myfile << " Cp" << cph1;
							//myfile << " Ch" << chh1;
							myfile.close();
						}


						Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
						Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 1000, 0., 15, "eV", dir.c_str());

						Hist->fill1(AUTO, "MFPAD tiny 360", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
						Hist->fill1(AUTO, "MFPAD tiny 180", tiny_mfpad, 1.0, "MFPAD", 180, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
						Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

						if (tiny_ker < 0.1) {
							Hist->fill1(AUTO, "MFPAD tiny 36 <0.1eV KER", tiny_mfpad, 1.0, "MFPAD <0.1eV KER", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
						}

						//int mfpdadnum = AUTO;
						//Hist->fill1(mfpdadnum, "MFPAD tiny 36 (mirrored)", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
						//Hist->fill1(mfpdadnum, "MFPAD tiny 36 (mirrored)", tiny_mfpad, -1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


						Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
						Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());
						}
						dir = reaction_dir;
						dir += "/TinyTestH2->Hp+e-";
					}
					*/

					//if ((tiny_ker < 1.325 && tiny_ker > .95))

					if ((tiny_ker < .35))

					{

						dir += "/Background Check";

						{//Momentum Angle stuff
							dir += "/Angle stuff";

							Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
							Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
							Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());

							Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -10, 10, "px", 400, -10, 10, "py", dir.c_str());
							Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -10, 10, "pz", 400, -10, 10, "py", dir.c_str());
							Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -10, 10, "px", 400, -10, 10, "pz", dir.c_str());




							/*					Hist->fill2(AUTO, "Theta Z vs Phi XY", e[0]->mom.Phi(), e[0]->mom.Theta(), 1.0, "KER vs Phi XY", 500, -4, 4, "Phi XY", 1500, 0, 2, "Theta z", dir.c_str());
												Hist->fill2(AUTO, "Theta X vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.ThetaX(), 1.0, "KER vs Phi YZ", 500, -1, 7, "Phi YZ", 1500, 0, 2, "Theta X", dir.c_str());
												Hist->fill2(AUTO, "Theta Y vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.ThetaY(), 1.0, "KER vs Phi ZX", 500, -1, 7, "Phi ZX", 1500, 0, 2, "Theta y", dir.c_str());

												Hist->fill2(AUTO, "electron px vs Theta X", e[0]->mom.ThetaX(), e[0]->mom.x, 1.0, "electron px vs Theta x", 500, 0, 4, "Theta X", 1500, 0, 2, "electron px", dir.c_str());
												Hist->fill2(AUTO, "electron py vs Theta y", e[0]->mom.ThetaY(), e[0]->mom.y, 1.0, "electron py vs Theta y", 500, 0, 4, "Theta y", 1500, 0, 2, "electron py", dir.c_str());
												Hist->fill2(AUTO, "electron pz vs Theta z", e[0]->mom.Theta(), e[0]->mom.z, 1.0, "electron pz vs Theta z", 500, 0, 4, "Theta z", 1500, 0, 2, "electron pz", dir.c_str());


												Hist->fill2(AUTO, "electron px vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.x, 1.0, "electron px vs Phi YZ", 500, 0, 4, "Phi YZ", 1500, 0, 2, "electron px", dir.c_str());
												Hist->fill2(AUTO, "electron py vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.y, 1.0, "electron py vs Phi ZX", 500, 0, 4, "Phi ZX", 1500, 0, 2, "electron py", dir.c_str());
												Hist->fill2(AUTO, "electron pz vs Phi XY", e[0]->mom.Phi(), e[0]->mom.z, 1.0, "electron pz vs Phi XY", 500, 0, 4, "Phi XY", 1500, 0, 2, "electron pz", dir.c_str());

												*/
							Hist->fill2(AUTO, "KER vs recoil Theta X", r[0]->mom.ThetaX(), tiny_ker, 1.0, "KER vs recoil Theta X", 150, 0, PI, "Theta X", 400, .3, 1.1, "KER", dir.c_str());
							Hist->fill2(AUTO, "KER vs recoil Theta Y", r[0]->mom.ThetaY(), tiny_ker, 1.0, "KER vs recoil Theta Y", 150, 0, PI, "Theta Y", 400, .3, 1.1, "KER", dir.c_str());
							Hist->fill2(AUTO, "KER vs recoil Theta Z", r[0]->mom.Theta(), tiny_ker, 1.0, "KER vs recoil Theta Z", 150, 0, PI, "Theta Z", 400, .3, 1.1, "KER", dir.c_str());

							Hist->fill2(AUTO, "KER vs recoil Phi XY", r[0]->mom.Phi(), tiny_ker, 1.0, "KER vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .3, 1.1, "KER", dir.c_str());
							Hist->fill2(AUTO, "KER vs recoil Phi YZ", r[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .3, 1.1, "KER", dir.c_str());
							Hist->fill2(AUTO, "KER vs recoil Phi ZX", r[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .3, 1.1, "KER", dir.c_str());

							Hist->fill2(AUTO, "Electron energy vs Theta X", e[0]->mom.ThetaX(), e[0]->energy(), 1.0, "Electron energy vs Theta X", 150, 0, PI, "Theta X", 400, .5, 1.4, "Electron energy", dir.c_str());
							Hist->fill2(AUTO, "Electron energy vs Theta Y", e[0]->mom.ThetaY(), e[0]->energy(), 1.0, "Electron energy vs Theta Y", 150, 0, PI, "Theta Y", 400, .5, 1.4, "Electron energy", dir.c_str());
							Hist->fill2(AUTO, "Electron energy vs Theta Z", e[0]->mom.Theta(), e[0]->energy(), 1.0, "Electron energy vs Theta Z", 150, 0, PI, "Theta Z", 400, .5, 1.4, "Electron energy", dir.c_str());

							Hist->fill2(AUTO, "Electron energy vs Phi XY", e[0]->mom.Phi(), e[0]->energy(), 1.0, "Electron energy vs Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .5, 1.4, "Electron energy", dir.c_str());
							Hist->fill2(AUTO, "Electron energy vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->energy(), 1.0, "Electron energy vs Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .5, 1.4, "Electron energy", dir.c_str());
							Hist->fill2(AUTO, "Electron energy vs Phi ZX", e[0]->mom.PhiZX(), e[0]->energy(), 1.0, "Electron energy vs Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .5, 1.4, "Electron energy", dir.c_str());

							Hist->fill2(AUTO, "Recoil Theta Z vs Electron Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Recoil Theta Z vs Electron Theta Z", 150, 0, PI, "Electron Theta Z", 150, 0, PI, "Recoil Theta Z", dir.c_str());
							Hist->fill1(AUTO, "Recoil Theta Z", r[0]->mom.Theta(), 1.0, "Recoil Theta Z", 150, 0, PI, "theta z", dir.c_str());
							Hist->fill1(AUTO, "Electron Theta Z", e[0]->mom.Theta(), 1.0, "Electron Theta Z", 150, 0, PI, "theta z", dir.c_str());

							Hist->fill2(AUTO, "Recoil cos Theta Z vs Electron cos Theta Z", cos(e[0]->mom.Theta()), cos(r[0]->mom.Theta()), 1.0, "Recoil cos Theta Z vs Electron cos Theta Z", 150, -1, 1, "Electron cos Theta Z", 150, -1, 1, "Recoil cos Theta Z", dir.c_str());
							Hist->fill1(AUTO, "Recoil cos Theta Z", cos(r[0]->mom.Theta()), 1.0, "Recoil cos Theta Z", 150, -1, 1, "cos theta z", dir.c_str());
							Hist->fill1(AUTO, "Electron cos Theta Z", cos(e[0]->mom.Theta()), 1.0, "Electron cos Theta Z", 150, -1, 1, "cos theta z", dir.c_str());



							/* Hist->fill2(AUTO, "PXY vs recoil Phi XY", r[0]->mom.Phi(), tinyPRXY, 1.0, "PXY vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, 10, "PXY", dir.c_str());
							 Hist->fill2(AUTO, "PYZ vs recoil Phi YZ", r[0]->mom.PhiYZ(), tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
							 Hist->fill2(AUTO, "PZX vs recoil Phi ZX", r[0]->mom.PhiZX(), tinyPRXZ, 1.0, "PZX vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, 10, "PZX", dir.c_str());

							 Hist->fill2(AUTO, "PXY vs electron Phi XY", e[0]->mom.Phi(), tinyPEXZ, 1.0, "PXY vs electron Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, .4, "PXY", dir.c_str());
							 Hist->fill2(AUTO, "PYZ vs electron Phi YZ", e[0]->mom.PhiYZ(), tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
							 Hist->fill2(AUTO, "PZX vs electron Phi ZX", e[0]->mom.PhiZX(), tinyPEXZ, 1.0, "PZX vs electron Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, .4, "PZX", dir.c_str());


							 Hist->fill2(AUTO, "PYZ vs electron cos Phi YZ", tinyPhiEYZ, tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
							 Hist->fill2(AUTO, "PYZ vs recoil cos Phi YZ", tinyPhiRYZ, tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
							*/
							/*{
								dir += "/TinyAngles";

								Hist->fill2(AUTO, "KER vs TinyTheta X", tinyThetaX, tiny_ker, 1.0, "KER vs Theta X", 500, 0, 2 * PI, "Theta X", 1500, 0, 2, "KER", dir.c_str());
								Hist->fill2(AUTO, "KER vs TinyTheta Y", tinyThetaY, tiny_ker, 1.0, "KER vs Theta Y", 500, 0, 2 * PI, "Theta Y", 1500, 0, 2, "KER", dir.c_str());
								Hist->fill2(AUTO, "KER vs TinyTheta Z", tinyThetaZ, tiny_ker, 1.0, "KER vs Theta Z", 500, 0, 2 * PI, "Theta Z", 1500, 0, 2, "KER", dir.c_str());

								Hist->fill2(AUTO, "KER vs Cos TinyTheta X", cos(tinyThetaX), tiny_ker, 1.0, "KER vs Cos Theta X", 500, -1, 1, "Cos Theta X", 1500, 0, 2, "KER", dir.c_str());
								Hist->fill2(AUTO, "KER vs Cos TinyTheta Y", cos(tinyThetaY), tiny_ker, 1.0, "KER vs Cos Theta Y", 500, -1, 1, "Cos Theta Y", 1500, 0, 2, "KER", dir.c_str());
								Hist->fill2(AUTO, "KER vs Cos TinyTheta Z", cos(tinyThetaZ), tiny_ker, 1.0, "KER vs Cos Theta Z", 500, -1, 1, "Cos Theta Z", 1500, 0, 2, "KER", dir.c_str());


								Hist->fill2(AUTO, "KER vs Phi XY", e[0]->mom.Phi(), tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
								Hist->fill2(AUTO, "KER vs Phi YZ", e[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs Phi YZ", 500, 0, 2 * PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
								Hist->fill2(AUTO, "KER vs Phi ZX", e[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs Phi ZX", 500, 0, 2 * PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());

								Hist->fill2(AUTO, "KER vs TinyPhi XY", tinyPhiXY, tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
								Hist->fill2(AUTO, "KER vs TinyPhi YZ", tinyPhiYZ, tiny_ker, 1.0, "KER vs Phi YZ", 500, -PI, PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
								Hist->fill2(AUTO, "KER vs TinyPhi ZX", tinyPhiZX, tiny_ker, 1.0, "KER vs Phi ZX", 500, -PI, PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());
							}
							*/




							dir = reaction_dir;
							dir += "/TinyTestH2->Hp+e-";



						}
						dir += "/Background Check";

						Hist->fill2(AUTO, "event number vs elec tof", e[0]->raw.data.tof, eventnumber, 1.0, "event number vs elec tof", 80, 90, 130, "ns", 501, 1, 234600000, "event number", dir.c_str());
						Hist->fill2(AUTO, "event number vs rec tof", r[0]->raw.data.tof, eventnumber, 1.0, "event number vs rec tof", 1800, 1600, 2500, "ns", 501, 1., 234600000, "event number", dir.c_str());
						Hist->fill2(AUTO, "event number vs EE", e[0]->energy(), eventnumber, 1.0, "event number vs EE", 375, .55, 1.35, "Electron energy", 501, 1, 234600000, "event number", dir.c_str());
						Hist->fill2(AUTO, "event number vs KER", tiny_ker, eventnumber, 1.0, "event number vs KER", 375, 0.35, 1.1, "KER", 501, 1., 234600000, "event number", dir.c_str());
						Hist->fill2(AUTO, "event number vs EE Bigbin", e[0]->energy(), eventnumber, 1.0, "event number vs EE", 200, .55, 1.35, "Electron energy", 501, 1, 234600000, "event number", dir.c_str());
						Hist->fill2(AUTO, "event number vs KER Bigbin", tiny_ker, eventnumber, 1.0, "event number vs KER", 200, 0.35, 1.1, "KER", 501, 1., 234600000, "event number", dir.c_str());



						Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
						Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 1500, 0, 2, "KER", 1500, 0, 1.6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "Electron energy vs KER bigbin", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 200, 0, 2, "KER", 160, 0, 1.6, "Electron energy", dir.c_str());
						Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 801, 0., 10., "rec p (au)", 801, 0, 5, "elec p (au)", dir.c_str());
						Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 501, 0., 5, "rec KE eV", 591, 0, 5, "elec KE eV", dir.c_str());
						Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
						Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
						Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
						Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
						Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
						Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine Etime vs TOF", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (Methods < 7)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, 38.20, 71.18, "TOF (ns)" "time (ns)", dir.c_str());
						Hist->fill1(AUTO, "Number of electron hits", evt->e.num_hits, 1.0, "Number Electron Hits", 10, 0, 11, "", dir.c_str());
						Hist->fill1(AUTO, "Number of recoil hits", evt->r.num_hits, 1.0, "Number Recoil Hits", 10, 0, 11, "", dir.c_str());
						Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
						Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
						Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (Methods < 7)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
						Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (Methods < 7)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
						Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -2, 2, "p au", dir.c_str());
						Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
						Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
						Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
						Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
						Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
						Hist->fill1(AUTO, "tiny rec 2 mom x", -r[0]->mom.x - e[0]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "tiny rec 2 mom y", -r[0]->mom.y - e[0]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "tiny rec 2 mom z", -r[0]->mom.z - e[0]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
						Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());

						Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
						Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
						Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());

						dir = reaction_dir;
						dir += "/TinyTestH2->Hp+e-";
					}

					//Vibrational states
					recpmaggatelow = 5;
					recpmaggatehigh = 8.4;
					elecpmaggatelow = .18;
					elecpmaggatehigh = .32;

					if (abs(e[0]->energy() - (-1.0*(tiny_ker)+1.025)) < .16 && tiny_ker > 0.06 && tiny_ker < 1.0) {
						Hist->fill1(AUTO, "Vibrational Peaks KER", tiny_ker, 1.0, "Vibrational Peaks", 1500, 0, 1.05, "KER (eV)", dir.c_str());
						Hist->fill1(AUTO, "Vibrational Peaks E", e[0]->energy(), 1.0, "Vibrational Peaks", 1500, 0, 1.165, "Electron Energy (eV)", dir.c_str());


						dir += "/vibrational states";

						Hist->fill1(AUTO, "Vibrational Peaks2", tiny_ker, 1.0, "Vibrational Peaks", 1500, 0, 1.05, "eV", dir.c_str());
						Hist->fill1(AUTO, "Vibrational Peaks KER", tiny_ker, 1.0, "Vibrational Peaks", 1500, 0, 1.05, "KER (eV)", dir.c_str());
						Hist->fill1(AUTO, "Vibrational Peaks E", e[0]->energy(), 1.0, "Vibrational Peaks", 1500, 0, 1.165, "Electron Energy (eV)", dir.c_str());
						Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 101, -1., 1., "MFPAD", 101, 0, PI, "theta z", dir.c_str());
						Hist->fill2(AUTO, "MFPAD vs Electron Theta Z", tiny_mfpad, e[0]->mom.Theta(), 1.0, "MFPAD vs Electron Theta Z", 101, -1., 1., "MFPAD", 101, 0, PI, "theta z", dir.c_str());
						Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 101, -1., 1., "MFPAD", 101, -1, 1, "cos theta z", dir.c_str());
						Hist->fill2(AUTO, "MFPAD vs Electron Cos Theta Z", tiny_mfpad, cos(e[0]->mom.Theta()), 1.0, "MFPAD vs Electron Cos Theta", 101, -1., 1., "MFPAD", 101, -1, 1, "cos theta z", dir.c_str());

						Hist->fill2(AUTO, "MFPAD vs Recoil Phi ZX", tiny_mfpad, r[0]->mom.PhiZX(), 1.0, "MFPAD vs Recoil Phi ZX", 101, -1., 1., "MFPAD", 101, 0, 2 * PI, "theta z", dir.c_str());
						Hist->fill2(AUTO, "MFPAD vs Recoil Cos Phi ZX", tiny_mfpad, cos(r[0]->mom.PhiZX()), 1.0, "MFPAD vs Recoil Cos Phi ZX", 101, -1., 1., "MFPAD", 101, -1, 1, "cos theta z", dir.c_str());
						Hist->fill2(AUTO, "Electron Theta z vs Recoil Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Electron Theta z vs Recoil Theta Z", 101, 0., PI, "MFPAD", 101, 0, PI, "theta z", dir.c_str());
						Hist->fill2(AUTO, "Electron Phi ZX vs Recoil Phi ZX", e[0]->mom.PhiZX(), r[0]->mom.PhiZX(), 1.0, "Electron Phi ZX vs Recoil Phi ZX", 101, 0, 2 * PI, "MFPAD", 101, 0, 2 * PI, "theta z", dir.c_str());


						Hist->fill2(AUTO, "Electron energy vs KER 2 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());


						dir = reaction_dir;
						dir += "/TinyTestH2->Hp+e-";

					}


					//if (r[0]->mom.Mag() > recpmaggatelow && r[0]->mom.Mag() < recpmaggatehigh && e[0]->mom.Mag() > elecpmaggatelow && e[0]->mom.Mag() < elecpmaggatehigh) {
					//if ( abs( e[0]->energy() - (-1.0*(tiny_ker)+1.025)) < .16 && tiny_ker > .4 && tiny_ker < 1.0 && e[0]->energy()> .025 && e[0]->energy()<.625 ) {
					if (abs(e[0]->energy() - (-1.0*(tiny_ker)+1.025)) < .16 && tiny_ker > 0.06 && tiny_ker < 1.0)
						//	 if (abs(e[0]->energy() - (-1.0*(tiny_ker)+1.025)) < .16 )
						 {

						 dir += "/vibrational states";
					 {//Momentum Angle stuff
						 dir += "/Angle stuff";

						 Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
						 Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
						 Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());

						 Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
						 Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
						 Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());




						 /*					Hist->fill2(AUTO, "Theta Z vs Phi XY", e[0]->mom.Phi(), e[0]->mom.Theta(), 1.0, "KER vs Phi XY", 500, -4, 4, "Phi XY", 1500, 0, 2, "Theta z", dir.c_str());
											 Hist->fill2(AUTO, "Theta X vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.ThetaX(), 1.0, "KER vs Phi YZ", 500, -1, 7, "Phi YZ", 1500, 0, 2, "Theta X", dir.c_str());
											 Hist->fill2(AUTO, "Theta Y vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.ThetaY(), 1.0, "KER vs Phi ZX", 500, -1, 7, "Phi ZX", 1500, 0, 2, "Theta y", dir.c_str());

											 Hist->fill2(AUTO, "electron px vs Theta X", e[0]->mom.ThetaX(), e[0]->mom.x, 1.0, "electron px vs Theta x", 500, 0, 4, "Theta X", 1500, 0, 2, "electron px", dir.c_str());
											 Hist->fill2(AUTO, "electron py vs Theta y", e[0]->mom.ThetaY(), e[0]->mom.y, 1.0, "electron py vs Theta y", 500, 0, 4, "Theta y", 1500, 0, 2, "electron py", dir.c_str());
											 Hist->fill2(AUTO, "electron pz vs Theta z", e[0]->mom.Theta(), e[0]->mom.z, 1.0, "electron pz vs Theta z", 500, 0, 4, "Theta z", 1500, 0, 2, "electron pz", dir.c_str());


											 Hist->fill2(AUTO, "electron px vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.x, 1.0, "electron px vs Phi YZ", 500, 0, 4, "Phi YZ", 1500, 0, 2, "electron px", dir.c_str());
											 Hist->fill2(AUTO, "electron py vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.y, 1.0, "electron py vs Phi ZX", 500, 0, 4, "Phi ZX", 1500, 0, 2, "electron py", dir.c_str());
											 Hist->fill2(AUTO, "electron pz vs Phi XY", e[0]->mom.Phi(), e[0]->mom.z, 1.0, "electron pz vs Phi XY", 500, 0, 4, "Phi XY", 1500, 0, 2, "electron pz", dir.c_str());

											 */
						 Hist->fill2(AUTO, "KER vs recoil Theta X", r[0]->mom.ThetaX(), tiny_ker, 1.0, "KER vs recoil Theta X", 150, 0, PI, "Theta X", 400, .35, 1.1, "KER", dir.c_str());
						 Hist->fill2(AUTO, "KER vs recoil Theta Y", r[0]->mom.ThetaY(), tiny_ker, 1.0, "KER vs recoil Theta Y", 150, 0, PI, "Theta Y", 400, .35, 1.1, "KER", dir.c_str());
						 Hist->fill2(AUTO, "KER vs recoil Theta Z", r[0]->mom.Theta(), tiny_ker, 1.0, "KER vs recoil Theta Z", 150, 0, PI, "Theta Z", 400, .35, 1.1, "KER", dir.c_str());

						 Hist->fill2(AUTO, "KER vs recoil Phi XY", r[0]->mom.Phi(), tiny_ker, 1.0, "KER vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .35, 1.1, "KER", dir.c_str());
						 Hist->fill2(AUTO, "KER vs recoil Phi YZ", r[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .35, 1.1, "KER", dir.c_str());
						 Hist->fill2(AUTO, "KER vs recoil Phi ZX", r[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .35, 1.1, "KER", dir.c_str());

						 Hist->fill2(AUTO, "Electron energy vs Theta X", e[0]->mom.ThetaX(), e[0]->energy(), 1.0, "Electron energy vs Theta X", 150, 0, PI, "Theta X", 400, 0, .65, "Electron energy", dir.c_str());
						 Hist->fill2(AUTO, "Electron energy vs Theta Y", e[0]->mom.ThetaY(), e[0]->energy(), 1.0, "Electron energy vs Theta Y", 150, 0, PI, "Theta Y", 400, 0, .65, "Electron energy", dir.c_str());
						 Hist->fill2(AUTO, "Electron energy vs Theta Z", e[0]->mom.Theta(), e[0]->energy(), 1.0, "Electron energy vs Theta Z", 150, 0, PI, "Theta Z", 400, 0, .65, "Electron energy", dir.c_str());

						 Hist->fill2(AUTO, "Electron energy vs Phi XY", e[0]->mom.Phi(), e[0]->energy(), 1.0, "Electron energy vs Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, .65, "Electron energy", dir.c_str());
						 Hist->fill2(AUTO, "Electron energy vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->energy(), 1.0, "Electron energy vs Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .65, "Electron energy", dir.c_str());
						 Hist->fill2(AUTO, "Electron energy vs Phi ZX", e[0]->mom.PhiZX(), e[0]->energy(), 1.0, "Electron energy vs Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, .65, "Electron energy", dir.c_str());




						/* Hist->fill2(AUTO, "PXY vs recoil Phi XY", r[0]->mom.Phi(), tinyPRXY, 1.0, "PXY vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, 10, "PXY", dir.c_str());
						 Hist->fill2(AUTO, "PYZ vs recoil Phi YZ", r[0]->mom.PhiYZ(), tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
						 Hist->fill2(AUTO, "PZX vs recoil Phi ZX", r[0]->mom.PhiZX(), tinyPRXZ, 1.0, "PZX vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, 10, "PZX", dir.c_str());

						 Hist->fill2(AUTO, "PXY vs electron Phi XY", e[0]->mom.Phi(), tinyPEXZ, 1.0, "PXY vs electron Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, .4, "PXY", dir.c_str());
						 Hist->fill2(AUTO, "PYZ vs electron Phi YZ", e[0]->mom.PhiYZ(), tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
						 Hist->fill2(AUTO, "PZX vs electron Phi ZX", e[0]->mom.PhiZX(), tinyPEXZ, 1.0, "PZX vs electron Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, .4, "PZX", dir.c_str());

						 
						 Hist->fill2(AUTO, "PYZ vs electron cos Phi YZ", tinyPhiEYZ, tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
						 Hist->fill2(AUTO, "PYZ vs recoil cos Phi YZ", tinyPhiRYZ, tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
						*/
						 /*{
							 dir += "/TinyAngles";

							 Hist->fill2(AUTO, "KER vs TinyTheta X", tinyThetaX, tiny_ker, 1.0, "KER vs Theta X", 500, 0, 2 * PI, "Theta X", 1500, 0, 2, "KER", dir.c_str());
							 Hist->fill2(AUTO, "KER vs TinyTheta Y", tinyThetaY, tiny_ker, 1.0, "KER vs Theta Y", 500, 0, 2 * PI, "Theta Y", 1500, 0, 2, "KER", dir.c_str());
							 Hist->fill2(AUTO, "KER vs TinyTheta Z", tinyThetaZ, tiny_ker, 1.0, "KER vs Theta Z", 500, 0, 2 * PI, "Theta Z", 1500, 0, 2, "KER", dir.c_str());

							 Hist->fill2(AUTO, "KER vs Cos TinyTheta X", cos(tinyThetaX), tiny_ker, 1.0, "KER vs Cos Theta X", 500, -1, 1, "Cos Theta X", 1500, 0, 2, "KER", dir.c_str());
							 Hist->fill2(AUTO, "KER vs Cos TinyTheta Y", cos(tinyThetaY), tiny_ker, 1.0, "KER vs Cos Theta Y", 500, -1, 1, "Cos Theta Y", 1500, 0, 2, "KER", dir.c_str());
							 Hist->fill2(AUTO, "KER vs Cos TinyTheta Z", cos(tinyThetaZ), tiny_ker, 1.0, "KER vs Cos Theta Z", 500, -1, 1, "Cos Theta Z", 1500, 0, 2, "KER", dir.c_str());


							 Hist->fill2(AUTO, "KER vs Phi XY", e[0]->mom.Phi(), tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
							 Hist->fill2(AUTO, "KER vs Phi YZ", e[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs Phi YZ", 500, 0, 2 * PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
							 Hist->fill2(AUTO, "KER vs Phi ZX", e[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs Phi ZX", 500, 0, 2 * PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());

							 Hist->fill2(AUTO, "KER vs TinyPhi XY", tinyPhiXY, tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
							 Hist->fill2(AUTO, "KER vs TinyPhi YZ", tinyPhiYZ, tiny_ker, 1.0, "KER vs Phi YZ", 500, -PI, PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
							 Hist->fill2(AUTO, "KER vs TinyPhi ZX", tinyPhiZX, tiny_ker, 1.0, "KER vs Phi ZX", 500, -PI, PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());
						 }
						 */




						 dir = reaction_dir;
						 dir += "/TinyTestH2->Hp+e-";

					 }
					 dir += "/vibrational states";



					 Hist->fill1(AUTO, "Vibrational Peaks KER", tiny_ker, 1.0, "Vibrational Peaks", 1500, .38, 1.05, "KER (eV)", dir.c_str());
					 Hist->fill1(AUTO, "Vibrational Peaks E", e[0]->energy(), 1.0, "Vibrational Peaks", 1500, 0, 1.1, "Electron Energy (eV)", dir.c_str());

					 Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
					 Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					 Hist->fill2(AUTO, "Electron energy vs KER", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 1500, 0, 2, "KER", 1500, 0, 1.6, "Electron energy", dir.c_str());
					 Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
					 Hist->fill2(AUTO, "Electron energy vs KER bigbin", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 200, 0, 2, "KER", 160, 0, 1.6, "Electron energy", dir.c_str());
					 Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 801, 0., 10., "rec p (au)", 801, 0, 5, "elec p (au)", dir.c_str());
					 Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 501, 0., 5, "rec KE eV", 591, 0, 5, "elec KE eV", dir.c_str());
					 Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
					 Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
					 Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
					 Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
					 Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					 Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					 Hist->fill2(AUTO, "Ultra fine Etime vs TOF", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
					 Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
					 Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (Methods < 7)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, 38.20, 71.18, "TOF (ns)" "time (ns)", dir.c_str());
					 Hist->fill1(AUTO, "Number of electron hits", evt->e.num_hits, 1.0, "Number Electron Hits", 10, 0, 11, "", dir.c_str());
					 Hist->fill1(AUTO, "Number of recoil hits", evt->r.num_hits, 1.0, "Number Recoil Hits", 10, 0, 11, "", dir.c_str());

					 Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
					 Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					 Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (Methods < 7)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
					 Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (Methods < 7)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
					 Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -8, 8, "p au", dir.c_str());
					 Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -8, 8, "p au", dir.c_str());
					 Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -8, 8, "p au", dir.c_str());
					 Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -2, 2, "p au", dir.c_str());
					 Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -2, 2, "p au", dir.c_str());
					 Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -2, 2, "p au", dir.c_str());
					 Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -2, 2, "p au", dir.c_str());
					 Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -2, 2, "p au", dir.c_str());
					 Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -2, 2, "p au", dir.c_str());
					 Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
					 Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
					 Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
					 Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
					 Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
					 Hist->fill1(AUTO, "tiny rec 2 mom x", -r[0]->mom.x - e[0]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
					 Hist->fill1(AUTO, "tiny rec 2 mom y", -r[0]->mom.y - e[0]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
					 Hist->fill1(AUTO, "tiny rec 2 mom z", -r[0]->mom.z - e[0]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());
					 Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
					 Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
					 Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());

						 Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
						 Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
						 Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());

						dir = reaction_dir;
						dir += "/TinyTestH2->Hp+e-";
					}
					

					 if (quickcal == 0) {



						 //v=6
						 elecEcenter = .965;
						 kercenter = .033;
						 ekerradius = .04;
						 // elecEcenter = .722;
						 // if (sqrt(pow(r[0]->mom.y - 1.4, 2) + pow(r[0]->mom.x - .2, 2)) > 1)

						 {
							 if (sqrt(pow(tiny_ker - kercenter, 2) + pow(e[0]->energy() - elecEcenter, 2)) < ekerradius) {
								 dir = reaction_dir;
								 dir += "/TinyTestH2->Hp+e-";
								 dir += "/v=6";

								 Hist->fill2(AUTO, "Recoil Theta Z vs MFPAD", tiny_mfpad, r[0]->mom.Theta(), 1.0, "Recoil Theta Z vs MFPAD", 160, -1., 1., "MFPAD", 160, 0, PI, "Theta Z", dir.c_str());
								 Hist->fill1(AUTO, "Recoil Theta Z", r[0]->mom.Theta(), 1.0, "Recoil Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
								 Hist->fill1(AUTO, "Electron Theta Z", e[0]->mom.Theta(), 1.0, "Electron Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
								 Hist->fill1(AUTO, "Electron Cos(Theta Z)", cos(e[0]->mom.Theta()), 1.0, "Electron Cos(Theta Z)", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

								 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
								 Hist->fill2(AUTO, "MFPAD vs Electron Theta Z", tiny_mfpad, e[0]->mom.Theta(), 1.0, "MFPAD vs Electron Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
								 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
								 Hist->fill2(AUTO, "MFPAD vs Electron Cos Theta Z", tiny_mfpad, cos(e[0]->mom.Theta()), 1.0, "MFPAD vs Electron Cos Theta", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
								 Hist->fill1(AUTO, "Vibrational Peaks E", e[0]->energy(), 1.0, "Vibrational Peaks", 1500, 0, 1.165, "Electron Energy (eV)", dir.c_str());
								 Hist->fill1(AUTO, "E Momentum magnitude", sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)), 1.0, "Electron Momentum magnitude", 100, 0, 1, "Momentum", dir.c_str());
								 Hist->fill1(AUTO, "R Momentum magnitude", sqrt(pow(r[0]->mom.x, 2) + pow(r[0]->mom.y, 2) + pow(r[0]->mom.z, 2)), 1.0, "Recoil Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
								 Hist->fill1(AUTO, "CM R Momentum magnitude", sqrt(pow(tinycmrec.x, 2) + pow(tinycmrec.y, 2) + pow(tinycmrec.z, 2)), 1.0, "Recoil CM Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
								 Hist->fill1(AUTO, "Cos CM Recoil theta z", cos(tinycmrec.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
								 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

								 Hist->fill2(AUTO, "MFPAD vs Recoil Phi ZX", tiny_mfpad, r[0]->mom.PhiZX(), 1.0, "MFPAD vs Recoil Phi ZX", 160, -1., 1., "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
								 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Phi ZX", tiny_mfpad, cos(r[0]->mom.PhiZX()), 1.0, "MFPAD vs Recoil Cos Phi ZX", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
								 Hist->fill2(AUTO, "Electron Theta z vs Recoil Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Electron Theta z vs Recoil Theta Z", 160, 0., PI, "MFPAD", 160, 0, PI, "theta z", dir.c_str());
								 Hist->fill2(AUTO, "Electron Phi ZX vs Recoil Phi ZX", e[0]->mom.PhiZX(), r[0]->mom.PhiZX(), 1.0, "Electron Phi ZX vs Recoil Phi ZX", 160, 0, 2 * PI, "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
								 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
								 Hist->fill1(AUTO, "Cos Electron theta z", cos(e[0]->mom.Theta()), 1.0, "Cos Electron theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
								 Hist->fill1(AUTO, "Cos Recoil theta z", cos(r[0]->mom.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
								// if (getasypar == 50) 
								 // if (getasypar == 50) 

								 dir = reaction_dir;
								 dir += "/TinyTestH2->Hp+e-";
								 if (getasypar == 1) {
									 if (tiny_mfpad > asyparthreshold) {
										 cp6 = cp6 + 1;
									 }

									 if (tiny_mfpad < -asyparthreshold) {
										 ch6 = ch6 + 1;
									 }
								 }


							 }

						 }




						 elecEcenter = .865;
						 kercenter = .131;
						 ekerradius = .07;

						 if (sqrt(pow(tiny_ker - kercenter, 2) + pow(e[0]->energy() - elecEcenter, 2)) < ekerradius) {
							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";

							 dir += "/v=7";
							 Hist->fill2(AUTO, "Recoil Theta Z vs MFPAD", tiny_mfpad, r[0]->mom.Theta(), 1.0, "Recoil Theta Z vs MFPAD", 160, -1., 1., "MFPAD", 160, 0, PI, "Theta Z", dir.c_str());
							 Hist->fill1(AUTO, "Recoil Theta Z", r[0]->mom.Theta(), 1.0, "Recoil Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Theta Z", e[0]->mom.Theta(), 1.0, "Electron Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Cos(Theta Z)", cos(e[0]->mom.Theta()), 1.0, "Electron Cos(Theta Z)", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Theta Z", tiny_mfpad, e[0]->mom.Theta(), 1.0, "MFPAD vs Electron Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Cos Theta Z", tiny_mfpad, cos(e[0]->mom.Theta()), 1.0, "MFPAD vs Electron Cos Theta", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill1(AUTO, "E Momentum magnitude", sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)), 1.0, "Electron Momentum magnitude", 100, 0, 1, "Momentum", dir.c_str());

							 Hist->fill1(AUTO, "R Momentum magnitude", sqrt(pow(r[0]->mom.x, 2) + pow(r[0]->mom.y, 2) + pow(r[0]->mom.z, 2)), 1.0, "Recoil Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "CM R Momentum magnitude", sqrt(pow(tinycmrec.x, 2) + pow(tinycmrec.y, 2) + pow(tinycmrec.z, 2)), 1.0, "Recoil CM Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "Cos CM Recoil theta z", cos(tinycmrec.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 Hist->fill2(AUTO, "MFPAD vs Recoil Phi ZX", tiny_mfpad, r[0]->mom.PhiZX(), 1.0, "MFPAD vs Recoil Phi ZX", 160, -1., 1., "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Phi ZX", tiny_mfpad, cos(r[0]->mom.PhiZX()), 1.0, "MFPAD vs Recoil Cos Phi ZX", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Theta z vs Recoil Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Electron Theta z vs Recoil Theta Z", 160, 0., PI, "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Phi ZX vs Recoil Phi ZX", e[0]->mom.PhiZX(), r[0]->mom.PhiZX(), 1.0, "Electron Phi ZX vs Recoil Phi ZX", 160, 0, 2 * PI, "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Electron theta z", cos(e[0]->mom.Theta()), 1.0, "Cos Electron theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Recoil theta z", cos(r[0]->mom.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh



							 Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";

							 if (getasypar == 1) {
								 if (tiny_mfpad > asyparthreshold) {
									 cp7 = cp7 + 1;
								 }

								 if (tiny_mfpad < -asyparthreshold) {
									 ch7 = ch7 + 1;
								 }
							 }
						 }

						 elecEcenter = .722;
						 kercenter = .30;
						 ekerradius = .07;

						 if (sqrt(pow(tiny_ker - kercenter, 2) + pow(e[0]->energy() - elecEcenter, 2)) < ekerradius) {
							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";
							 dir += "/v=8";
							 Hist->fill2(AUTO, "Recoil Theta Z vs MFPAD", tiny_mfpad, r[0]->mom.Theta(), 1.0, "Recoil Theta Z vs MFPAD", 160, -1., 1., "MFPAD", 160, 0, PI, "Theta Z", dir.c_str());
							 Hist->fill1(AUTO, "Recoil Theta Z", r[0]->mom.Theta(), 1.0, "Recoil Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Theta Z", e[0]->mom.Theta(), 1.0, "Electron Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Cos(Theta Z)", cos(e[0]->mom.Theta()), 1.0, "Electron Cos(Theta Z)", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 
							 Hist->fill2(AUTO, "MFPAD vs Electron Theta Z", tiny_mfpad, e[0]->mom.Theta(), 1.0, "MFPAD vs Electron Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Cos Theta Z", tiny_mfpad, cos(e[0]->mom.Theta()), 1.0, "MFPAD vs Electron Cos Theta", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill1(AUTO, "E Momentum magnitude", sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)), 1.0, "Electron Momentum magnitude", 100, 0, 1, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "R Momentum magnitude", sqrt(pow(r[0]->mom.x, 2) + pow(r[0]->mom.y, 2) + pow(r[0]->mom.z, 2)), 1.0, "Recoil Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "CM R Momentum magnitude", sqrt(pow(tinycmrec.x, 2) + pow(tinycmrec.y, 2) + pow(tinycmrec.z, 2)), 1.0, "Recoil CM Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "Cos CM Recoil theta z", cos(tinycmrec.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 Hist->fill2(AUTO, "MFPAD vs Recoil Phi ZX", tiny_mfpad, r[0]->mom.PhiZX(), 1.0, "MFPAD vs Recoil Phi ZX", 160, -1., 1., "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Phi ZX", tiny_mfpad, cos(r[0]->mom.PhiZX()), 1.0, "MFPAD vs Recoil Cos Phi ZX", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Theta z vs Recoil Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Electron Theta z vs Recoil Theta Z", 160, 0., PI, "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Phi ZX vs Recoil Phi ZX", e[0]->mom.PhiZX(), r[0]->mom.PhiZX(), 1.0, "Electron Phi ZX vs Recoil Phi ZX", 160, 0, 2 * PI, "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Electron theta z", cos(e[0]->mom.Theta()), 1.0, "Cos Electron theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Recoil theta z", cos(r[0]->mom.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh



							 Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";
							 if (getasypar == 1) {
								 if (tiny_mfpad > asyparthreshold) {
									 cp8 = cp8 + 1;
								 }

								 if (tiny_mfpad < -asyparthreshold) {
									 ch8 = ch8 + 1;
								 }

							 }
							 
						 }



						 //v=9
						 recpmaggatelow = 5.4;
						 recpmaggatehigh = 6.2;
						 elecpmaggatelow = .286;
						 elecpmaggatehigh = .3;
						 elecEcenter = .561;

						 kercenter = .476;
						 ekerradius = .07;

						 //if (r[0]->mom.Mag() > recpmaggatelow && r[0]->mom.Mag() < recpmaggatehigh && e[0]->mom.Mag() > elecpmaggatelow && e[0]->mom.Mag() < elecpmaggatehigh) {
						 if (sqrt(pow(tiny_ker - kercenter, 2) + pow(e[0]->energy() - elecEcenter, 2)) < ekerradius) {
							 dir += "/v=9";
							 Hist->fill2(AUTO, "Recoil Theta Z vs MFPAD", tiny_mfpad, r[0]->mom.Theta(), 1.0, "Recoil Theta Z vs MFPAD", 160, -1., 1., "MFPAD", 160, 0, PI, "Theta Z", dir.c_str());
							 Hist->fill1(AUTO, "Recoil Theta Z", r[0]->mom.Theta(), 1.0, "Recoil Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Theta Z", e[0]->mom.Theta(), 1.0, "Electron Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Cos(Theta Z)", cos(e[0]->mom.Theta()), 1.0, "Electron Cos(Theta Z)", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


							 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Theta Z", tiny_mfpad, e[0]->mom.Theta(), 1.0, "MFPAD vs Electron Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Cos Theta Z", tiny_mfpad, cos(e[0]->mom.Theta()), 1.0, "MFPAD vs Electron Cos Theta", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill1(AUTO, "E Momentum magnitude", sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)), 1.0, "Electron Momentum magnitude", 100, 0, 1, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "R Momentum magnitude", sqrt(pow(r[0]->mom.x, 2) + pow(r[0]->mom.y, 2) + pow(r[0]->mom.z, 2)), 1.0, "Recoil Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "CM R Momentum magnitude", sqrt(pow(tinycmrec.x, 2) + pow(tinycmrec.y, 2) + pow(tinycmrec.z, 2)), 1.0, "Recoil CM Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "Cos CM Recoil theta z", cos(tinycmrec.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 Hist->fill2(AUTO, "MFPAD vs Recoil Phi ZX", tiny_mfpad, r[0]->mom.PhiZX(), 1.0, "MFPAD vs Recoil Phi ZX", 160, -1., 1., "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Phi ZX", tiny_mfpad, cos(r[0]->mom.PhiZX()), 1.0, "MFPAD vs Recoil Cos Phi ZX", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Theta z vs Recoil Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Electron Theta z vs Recoil Theta Z", 160, 0., PI, "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Phi ZX vs Recoil Phi ZX", e[0]->mom.PhiZX(), r[0]->mom.PhiZX(), 1.0, "Electron Phi ZX vs Recoil Phi ZX", 160, 0, 2 * PI, "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Electron theta z", cos(e[0]->mom.Theta()), 1.0, "Cos Electron theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Recoil theta z", cos(r[0]->mom.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh



							 {//Momentum Angle stuff
								 dir += "/Angle stuff";

								 Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
								 Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
								 Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());

								 Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
								 Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
								 Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());




								 /*					Hist->fill2(AUTO, "Theta Z vs Phi XY", e[0]->mom.Phi(), e[0]->mom.Theta(), 1.0, "KER vs Phi XY", 500, -4, 4, "Phi XY", 1500, 0, 2, "Theta z", dir.c_str());
													 Hist->fill2(AUTO, "Theta X vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.ThetaX(), 1.0, "KER vs Phi YZ", 500, -1, 7, "Phi YZ", 1500, 0, 2, "Theta X", dir.c_str());
													 Hist->fill2(AUTO, "Theta Y vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.ThetaY(), 1.0, "KER vs Phi ZX", 500, -1, 7, "Phi ZX", 1500, 0, 2, "Theta y", dir.c_str());

													 Hist->fill2(AUTO, "electron px vs Theta X", e[0]->mom.ThetaX(), e[0]->mom.x, 1.0, "electron px vs Theta x", 500, 0, 4, "Theta X", 1500, 0, 2, "electron px", dir.c_str());
													 Hist->fill2(AUTO, "electron py vs Theta y", e[0]->mom.ThetaY(), e[0]->mom.y, 1.0, "electron py vs Theta y", 500, 0, 4, "Theta y", 1500, 0, 2, "electron py", dir.c_str());
													 Hist->fill2(AUTO, "electron pz vs Theta z", e[0]->mom.Theta(), e[0]->mom.z, 1.0, "electron pz vs Theta z", 500, 0, 4, "Theta z", 1500, 0, 2, "electron pz", dir.c_str());


													 Hist->fill2(AUTO, "electron px vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.x, 1.0, "electron px vs Phi YZ", 500, 0, 4, "Phi YZ", 1500, 0, 2, "electron px", dir.c_str());
													 Hist->fill2(AUTO, "electron py vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.y, 1.0, "electron py vs Phi ZX", 500, 0, 4, "Phi ZX", 1500, 0, 2, "electron py", dir.c_str());
													 Hist->fill2(AUTO, "electron pz vs Phi XY", e[0]->mom.Phi(), e[0]->mom.z, 1.0, "electron pz vs Phi XY", 500, 0, 4, "Phi XY", 1500, 0, 2, "electron pz", dir.c_str());

													 */
								 Hist->fill2(AUTO, "KER vs recoil Theta X", r[0]->mom.ThetaX(), tiny_ker, 1.0, "KER vs recoil Theta X", 150, 0, PI, "Theta X", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Theta Y", r[0]->mom.ThetaY(), tiny_ker, 1.0, "KER vs recoil Theta Y", 150, 0, PI, "Theta Y", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Theta Z", r[0]->mom.Theta(), tiny_ker, 1.0, "KER vs recoil Theta Z", 150, 0, PI, "Theta Z", 400, .3, 1.1, "KER", dir.c_str());

								 Hist->fill2(AUTO, "KER vs recoil Phi XY", r[0]->mom.Phi(), tiny_ker, 1.0, "KER vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Phi YZ", r[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Phi ZX", r[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .3, 1.1, "KER", dir.c_str());

								 Hist->fill2(AUTO, "Electron energy vs Theta X", e[0]->mom.ThetaX(), e[0]->energy(), 1.0, "Electron energy vs Theta X", 150, 0, PI, "Theta X", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Theta Y", e[0]->mom.ThetaY(), e[0]->energy(), 1.0, "Electron energy vs Theta Y", 150, 0, PI, "Theta Y", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Theta Z", e[0]->mom.Theta(), e[0]->energy(), 1.0, "Electron energy vs Theta Z", 150, 0, PI, "Theta Z", 400, .5, 1.4, "Electron energy", dir.c_str());

								 Hist->fill2(AUTO, "Electron energy vs Phi XY", e[0]->mom.Phi(), e[0]->energy(), 1.0, "Electron energy vs Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->energy(), 1.0, "Electron energy vs Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Phi ZX", e[0]->mom.PhiZX(), e[0]->energy(), 1.0, "Electron energy vs Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .5, 1.4, "Electron energy", dir.c_str());




								 /* Hist->fill2(AUTO, "PXY vs recoil Phi XY", r[0]->mom.Phi(), tinyPRXY, 1.0, "PXY vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, 10, "PXY", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs recoil Phi YZ", r[0]->mom.PhiYZ(), tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PZX vs recoil Phi ZX", r[0]->mom.PhiZX(), tinyPRXZ, 1.0, "PZX vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, 10, "PZX", dir.c_str());

								  Hist->fill2(AUTO, "PXY vs electron Phi XY", e[0]->mom.Phi(), tinyPEXZ, 1.0, "PXY vs electron Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, .4, "PXY", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs electron Phi YZ", e[0]->mom.PhiYZ(), tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PZX vs electron Phi ZX", e[0]->mom.PhiZX(), tinyPEXZ, 1.0, "PZX vs electron Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, .4, "PZX", dir.c_str());


								  Hist->fill2(AUTO, "PYZ vs electron cos Phi YZ", tinyPhiEYZ, tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs recoil cos Phi YZ", tinyPhiRYZ, tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
								 */
								 /*{
									 dir += "/TinyAngles";

									 Hist->fill2(AUTO, "KER vs TinyTheta X", tinyThetaX, tiny_ker, 1.0, "KER vs Theta X", 500, 0, 2 * PI, "Theta X", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyTheta Y", tinyThetaY, tiny_ker, 1.0, "KER vs Theta Y", 500, 0, 2 * PI, "Theta Y", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyTheta Z", tinyThetaZ, tiny_ker, 1.0, "KER vs Theta Z", 500, 0, 2 * PI, "Theta Z", 1500, 0, 2, "KER", dir.c_str());

									 Hist->fill2(AUTO, "KER vs Cos TinyTheta X", cos(tinyThetaX), tiny_ker, 1.0, "KER vs Cos Theta X", 500, -1, 1, "Cos Theta X", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Cos TinyTheta Y", cos(tinyThetaY), tiny_ker, 1.0, "KER vs Cos Theta Y", 500, -1, 1, "Cos Theta Y", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Cos TinyTheta Z", cos(tinyThetaZ), tiny_ker, 1.0, "KER vs Cos Theta Z", 500, -1, 1, "Cos Theta Z", 1500, 0, 2, "KER", dir.c_str());


									 Hist->fill2(AUTO, "KER vs Phi XY", e[0]->mom.Phi(), tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Phi YZ", e[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs Phi YZ", 500, 0, 2 * PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Phi ZX", e[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs Phi ZX", 500, 0, 2 * PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());

									 Hist->fill2(AUTO, "KER vs TinyPhi XY", tinyPhiXY, tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyPhi YZ", tinyPhiYZ, tiny_ker, 1.0, "KER vs Phi YZ", 500, -PI, PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyPhi ZX", tinyPhiZX, tiny_ker, 1.0, "KER vs Phi ZX", 500, -PI, PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());
								 }
								 */




								 dir = reaction_dir;
								 dir += "/TinyTestH2->Hp+e-";

							 }
							 dir += "/v=9";

							 Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
							 Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 1500, 0, 2, "KER", 1500, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER bigbin", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 200, 0, 2, "KER", 160, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 801, 0., 10., "rec p (au)", 801, 0, 5, "elec p (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 501, 0., 5, "rec KE eV", 591, 0, 5, "elec KE eV", dir.c_str());
							 Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
							 Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
							 Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
							 Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine Etime vs TOF", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (Methods < 7)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, 38.20, 71.18, "TOF (ns)" "time (ns)", dir.c_str());
							 Hist->fill1(AUTO, "Number of electron hits", evt->e.num_hits, 1.0, "Number Electron Hits", 10, 0, 11, "", dir.c_str());
							 Hist->fill1(AUTO, "Number of recoil hits", evt->r.num_hits, 1.0, "Number Recoil Hits", 10, 0, 11, "", dir.c_str());
							 Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
							 Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
							 Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (Methods < 7)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (Methods < 7)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
							 Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
							 Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom x", -r[0]->mom.x - e[0]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom y", -r[0]->mom.y - e[0]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom z", -r[0]->mom.z - e[0]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());

							 Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
							 Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
							 Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());

							 dir += "/Tiny MFPAD";
							 {if (getasypar == 1) {
								 if (tiny_mfpad > asyparthreshold) {
									 cp9 = cp9 + 1;
								 }

								 if (tiny_mfpad < -asyparthreshold) {
									 ch9 = ch9 + 1;
								 }

								 asypar9 = (cp9 - ch9) / (cp9 + ch9);

								 // cout << " Asypar" << asypar;
								  //cout << " Cp" << cp;
								  //cout << " Ch" << ch;

							 }
							 Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
							 Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 1000, 0., 15, "eV", dir.c_str());

							 Hist->fill1(AUTO, "MFPAD tiny 360", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "MFPAD tiny 180", tiny_mfpad, 1.0, "MFPAD", 180, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


							 Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());
							 }

							 if (cos(r[0]->mom.Theta()) < -.7 || cos(r[0]->mom.Theta()) > .7)
							 {
								 dir += "/Tiny MFPAD Theta Z cut";


								 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
								 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 51, -1., 1., "MFPAD", 51, 0, PI, "theta z", dir.c_str());
								 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 if (tiny_mfpad < 0) {
									 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z (Ch)", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 }
								 if (tiny_mfpad > 0) {
									 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z (Cp)", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 }

							 }

							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";
							 dir += "/Tiny MFPAD";


							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";

						 }


						 //v=10
						 recpmaggatelow = 6.025;
						 recpmaggatehigh = 7;
						 elecpmaggatelow = .26;
						 elecpmaggatehigh = .28;
						 elecEcenter = .429;

						 kercenter = .616;
						 ekerradius = .08;

						 if (sqrt(pow(tiny_ker - kercenter, 2) + pow(e[0]->energy() - elecEcenter, 2)) < ekerradius) {
							 dir += "/v=10";
							 Hist->fill2(AUTO, "Recoil Theta Z vs MFPAD", tiny_mfpad, r[0]->mom.Theta(), 1.0, "Recoil Theta Z vs MFPAD", 160, -1., 1., "MFPAD", 160, 0, PI, "Theta Z", dir.c_str());
							 Hist->fill1(AUTO, "Recoil Theta Z", r[0]->mom.Theta(), 1.0, "Recoil Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Theta Z", e[0]->mom.Theta(), 1.0, "Electron Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Cos(Theta Z)", cos(e[0]->mom.Theta()), 1.0, "Electron Cos(Theta Z)", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Theta Z", tiny_mfpad, e[0]->mom.Theta(), 1.0, "MFPAD vs Electron Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Cos Theta Z", tiny_mfpad, cos(e[0]->mom.Theta()), 1.0, "MFPAD vs Electron Cos Theta", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill1(AUTO, "E Momentum magnitude", sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)), 1.0, "Electron Momentum magnitude", 100, 0, 1, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "R Momentum magnitude", sqrt(pow(r[0]->mom.x, 2) + pow(r[0]->mom.y, 2) + pow(r[0]->mom.z, 2)), 1.0, "Recoil Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "CM R Momentum magnitude", sqrt(pow(tinycmrec.x, 2) + pow(tinycmrec.y, 2) + pow(tinycmrec.z, 2)), 1.0, "Recoil CM Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "Cos CM Recoil theta z", cos(tinycmrec.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 Hist->fill2(AUTO, "MFPAD vs Recoil Phi ZX", tiny_mfpad, r[0]->mom.PhiZX(), 1.0, "MFPAD vs Recoil Phi ZX", 160, -1., 1., "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Phi ZX", tiny_mfpad, cos(r[0]->mom.PhiZX()), 1.0, "MFPAD vs Recoil Cos Phi ZX", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Theta z vs Recoil Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Electron Theta z vs Recoil Theta Z", 160, 0., PI, "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Phi ZX vs Recoil Phi ZX", e[0]->mom.PhiZX(), r[0]->mom.PhiZX(), 1.0, "Electron Phi ZX vs Recoil Phi ZX", 160, 0, 2 * PI, "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Electron theta z", cos(e[0]->mom.Theta()), 1.0, "Cos Electron theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Recoil theta z", cos(r[0]->mom.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh



							 {//Momentum Angle stuff
								 dir += "/Angle stuff";

								 Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
								 Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
								 Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());

								 Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
								 Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
								 Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());




								 /*					Hist->fill2(AUTO, "Theta Z vs Phi XY", e[0]->mom.Phi(), e[0]->mom.Theta(), 1.0, "KER vs Phi XY", 500, -4, 4, "Phi XY", 1500, 0, 2, "Theta z", dir.c_str());
													 Hist->fill2(AUTO, "Theta X vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.ThetaX(), 1.0, "KER vs Phi YZ", 500, -1, 7, "Phi YZ", 1500, 0, 2, "Theta X", dir.c_str());
													 Hist->fill2(AUTO, "Theta Y vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.ThetaY(), 1.0, "KER vs Phi ZX", 500, -1, 7, "Phi ZX", 1500, 0, 2, "Theta y", dir.c_str());

													 Hist->fill2(AUTO, "electron px vs Theta X", e[0]->mom.ThetaX(), e[0]->mom.x, 1.0, "electron px vs Theta x", 500, 0, 4, "Theta X", 1500, 0, 2, "electron px", dir.c_str());
													 Hist->fill2(AUTO, "electron py vs Theta y", e[0]->mom.ThetaY(), e[0]->mom.y, 1.0, "electron py vs Theta y", 500, 0, 4, "Theta y", 1500, 0, 2, "electron py", dir.c_str());
													 Hist->fill2(AUTO, "electron pz vs Theta z", e[0]->mom.Theta(), e[0]->mom.z, 1.0, "electron pz vs Theta z", 500, 0, 4, "Theta z", 1500, 0, 2, "electron pz", dir.c_str());


													 Hist->fill2(AUTO, "electron px vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.x, 1.0, "electron px vs Phi YZ", 500, 0, 4, "Phi YZ", 1500, 0, 2, "electron px", dir.c_str());
													 Hist->fill2(AUTO, "electron py vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.y, 1.0, "electron py vs Phi ZX", 500, 0, 4, "Phi ZX", 1500, 0, 2, "electron py", dir.c_str());
													 Hist->fill2(AUTO, "electron pz vs Phi XY", e[0]->mom.Phi(), e[0]->mom.z, 1.0, "electron pz vs Phi XY", 500, 0, 4, "Phi XY", 1500, 0, 2, "electron pz", dir.c_str());

													 */
								 Hist->fill2(AUTO, "KER vs recoil Theta X", r[0]->mom.ThetaX(), tiny_ker, 1.0, "KER vs recoil Theta X", 150, 0, PI, "Theta X", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Theta Y", r[0]->mom.ThetaY(), tiny_ker, 1.0, "KER vs recoil Theta Y", 150, 0, PI, "Theta Y", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Theta Z", r[0]->mom.Theta(), tiny_ker, 1.0, "KER vs recoil Theta Z", 150, 0, PI, "Theta Z", 400, .3, 1.1, "KER", dir.c_str());

								 Hist->fill2(AUTO, "KER vs recoil Phi XY", r[0]->mom.Phi(), tiny_ker, 1.0, "KER vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Phi YZ", r[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Phi ZX", r[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .3, 1.1, "KER", dir.c_str());

								 Hist->fill2(AUTO, "Electron energy vs Theta X", e[0]->mom.ThetaX(), e[0]->energy(), 1.0, "Electron energy vs Theta X", 150, 0, PI, "Theta X", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Theta Y", e[0]->mom.ThetaY(), e[0]->energy(), 1.0, "Electron energy vs Theta Y", 150, 0, PI, "Theta Y", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Theta Z", e[0]->mom.Theta(), e[0]->energy(), 1.0, "Electron energy vs Theta Z", 150, 0, PI, "Theta Z", 400, .5, 1.4, "Electron energy", dir.c_str());

								 Hist->fill2(AUTO, "Electron energy vs Phi XY", e[0]->mom.Phi(), e[0]->energy(), 1.0, "Electron energy vs Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->energy(), 1.0, "Electron energy vs Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Phi ZX", e[0]->mom.PhiZX(), e[0]->energy(), 1.0, "Electron energy vs Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .5, 1.4, "Electron energy", dir.c_str());




								 /* Hist->fill2(AUTO, "PXY vs recoil Phi XY", r[0]->mom.Phi(), tinyPRXY, 1.0, "PXY vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, 10, "PXY", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs recoil Phi YZ", r[0]->mom.PhiYZ(), tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PZX vs recoil Phi ZX", r[0]->mom.PhiZX(), tinyPRXZ, 1.0, "PZX vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, 10, "PZX", dir.c_str());

								  Hist->fill2(AUTO, "PXY vs electron Phi XY", e[0]->mom.Phi(), tinyPEXZ, 1.0, "PXY vs electron Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, .4, "PXY", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs electron Phi YZ", e[0]->mom.PhiYZ(), tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PZX vs electron Phi ZX", e[0]->mom.PhiZX(), tinyPEXZ, 1.0, "PZX vs electron Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, .4, "PZX", dir.c_str());


								  Hist->fill2(AUTO, "PYZ vs electron cos Phi YZ", tinyPhiEYZ, tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs recoil cos Phi YZ", tinyPhiRYZ, tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
								 */
								 /*{
									 dir += "/TinyAngles";

									 Hist->fill2(AUTO, "KER vs TinyTheta X", tinyThetaX, tiny_ker, 1.0, "KER vs Theta X", 500, 0, 2 * PI, "Theta X", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyTheta Y", tinyThetaY, tiny_ker, 1.0, "KER vs Theta Y", 500, 0, 2 * PI, "Theta Y", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyTheta Z", tinyThetaZ, tiny_ker, 1.0, "KER vs Theta Z", 500, 0, 2 * PI, "Theta Z", 1500, 0, 2, "KER", dir.c_str());

									 Hist->fill2(AUTO, "KER vs Cos TinyTheta X", cos(tinyThetaX), tiny_ker, 1.0, "KER vs Cos Theta X", 500, -1, 1, "Cos Theta X", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Cos TinyTheta Y", cos(tinyThetaY), tiny_ker, 1.0, "KER vs Cos Theta Y", 500, -1, 1, "Cos Theta Y", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Cos TinyTheta Z", cos(tinyThetaZ), tiny_ker, 1.0, "KER vs Cos Theta Z", 500, -1, 1, "Cos Theta Z", 1500, 0, 2, "KER", dir.c_str());


									 Hist->fill2(AUTO, "KER vs Phi XY", e[0]->mom.Phi(), tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Phi YZ", e[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs Phi YZ", 500, 0, 2 * PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Phi ZX", e[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs Phi ZX", 500, 0, 2 * PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());

									 Hist->fill2(AUTO, "KER vs TinyPhi XY", tinyPhiXY, tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyPhi YZ", tinyPhiYZ, tiny_ker, 1.0, "KER vs Phi YZ", 500, -PI, PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyPhi ZX", tinyPhiZX, tiny_ker, 1.0, "KER vs Phi ZX", 500, -PI, PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());
								 }
								 */




								 dir = reaction_dir;
								 dir += "/TinyTestH2->Hp+e-";

							 }
							 dir += "/v=10";

							 Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
							 Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 1500, 0, 2, "KER", 1500, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER bigbin", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 200, 0, 2, "KER", 160, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 801, 0., 10., "rec p (au)", 801, 0, 5, "elec p (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 501, 0., 5, "rec KE eV", 591, 0, 5, "elec KE eV", dir.c_str());
							 Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
							 Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
							 Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
							 Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine Etime vs TOF", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (Methods < 7)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, 38.20, 71.18, "TOF (ns)" "time (ns)", dir.c_str());
							 Hist->fill1(AUTO, "Number of electron hits", evt->e.num_hits, 1.0, "Number Electron Hits", 10, 0, 11, "", dir.c_str());
							 Hist->fill1(AUTO, "Number of recoil hits", evt->r.num_hits, 1.0, "Number Recoil Hits", 10, 0, 11, "", dir.c_str());
							 Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
							 Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
							 Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (Methods < 7)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (Methods < 7)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
							 Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
							 Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom x", -r[0]->mom.x - e[0]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom y", -r[0]->mom.y - e[0]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom z", -r[0]->mom.z - e[0]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());

							 Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
							 Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
							 Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());

							 dir += "/Tiny MFPAD";
							 {if (getasypar == 1) {
								 if (tiny_mfpad > asyparthreshold) {
									 cp10 = cp10 + 1;
								 }

								 if (tiny_mfpad < -asyparthreshold) {
									 ch10 = ch10 + 1;
								 }

								 asypar10 = (cp10 - ch10) / (cp10 + ch10);

								 // cout << " Asypar" << asypar;
								  //cout << " Cp" << cp;
								  //cout << " Ch" << ch;
							 }
							 Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
							 Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 1000, 0., 15, "eV", dir.c_str());

							 Hist->fill1(AUTO, "MFPAD tiny 360", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "MFPAD tiny 180", tiny_mfpad, 1.0, "MFPAD", 180, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


							 Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());
							 }

							 if (cos(r[0]->mom.Theta()) < -.7 || cos(r[0]->mom.Theta()) > .7)
							 {
								 dir += "/Tiny MFPAD Theta Z cut";


								 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
								 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 51, -1., 1., "MFPAD", 51, 0, PI, "theta z", dir.c_str());
								 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 if (tiny_mfpad < 0) {
									 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z (Ch)", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 }
								 if (tiny_mfpad > 0) {
									 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z (Cp)", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 }

							 }

							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";
							 dir += "/Tiny MFPAD";


							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";
						 }

						 //v=11
						 recpmaggatelow = 6.34;
						 recpmaggatehigh = 7.75;
						 elecpmaggatelow = .245;
						 elecpmaggatehigh = .26;
						 elecEcenter = .30;

						 kercenter = .737;
						 ekerradius = .08;

						 if (sqrt(pow(tiny_ker - kercenter, 2) + pow(e[0]->energy() - elecEcenter, 2)) < ekerradius) {
							 dir += "/v=11";
							 Hist->fill2(AUTO, "Recoil Theta Z vs MFPAD", tiny_mfpad, r[0]->mom.Theta(), 1.0, "Recoil Theta Z vs MFPAD", 160, -1., 1., "MFPAD", 160, 0, PI, "Theta Z", dir.c_str());
							 Hist->fill1(AUTO, "Recoil Theta Z", r[0]->mom.Theta(), 1.0, "Recoil Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Theta Z", e[0]->mom.Theta(), 1.0, "Electron Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Cos(Theta Z)", cos(e[0]->mom.Theta()), 1.0, "Electron Cos(Theta Z)", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


							 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Theta Z", tiny_mfpad, e[0]->mom.Theta(), 1.0, "MFPAD vs Electron Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Cos Theta Z", tiny_mfpad, cos(e[0]->mom.Theta()), 1.0, "MFPAD vs Electron Cos Theta", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill1(AUTO, "E Momentum magnitude", sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)), 1.0, "Electron Momentum magnitude", 100, 0, 1, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "R Momentum magnitude", sqrt(pow(r[0]->mom.x, 2) + pow(r[0]->mom.y, 2) + pow(r[0]->mom.z, 2)), 1.0, "Recoil Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "CM R Momentum magnitude", sqrt(pow(tinycmrec.x, 2) + pow(tinycmrec.y, 2) + pow(tinycmrec.z, 2)), 1.0, "Recoil CM Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "Cos CM Recoil theta z", cos(tinycmrec.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 Hist->fill2(AUTO, "MFPAD vs Recoil Phi ZX", tiny_mfpad, r[0]->mom.PhiZX(), 1.0, "MFPAD vs Recoil Phi ZX", 160, -1., 1., "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Phi ZX", tiny_mfpad, cos(r[0]->mom.PhiZX()), 1.0, "MFPAD vs Recoil Cos Phi ZX", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Theta z vs Recoil Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Electron Theta z vs Recoil Theta Z", 160, 0., PI, "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Phi ZX vs Recoil Phi ZX", e[0]->mom.PhiZX(), r[0]->mom.PhiZX(), 1.0, "Electron Phi ZX vs Recoil Phi ZX", 160, 0, 2 * PI, "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Electron theta z", cos(e[0]->mom.Theta()), 1.0, "Cos Electron theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Recoil theta z", cos(r[0]->mom.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh



							 {//Momentum Angle stuff
								 dir += "/Angle stuff";

								 Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
								 Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
								 Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());

								 Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
								 Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
								 Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());




								 /*					Hist->fill2(AUTO, "Theta Z vs Phi XY", e[0]->mom.Phi(), e[0]->mom.Theta(), 1.0, "KER vs Phi XY", 500, -4, 4, "Phi XY", 1500, 0, 2, "Theta z", dir.c_str());
													 Hist->fill2(AUTO, "Theta X vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.ThetaX(), 1.0, "KER vs Phi YZ", 500, -1, 7, "Phi YZ", 1500, 0, 2, "Theta X", dir.c_str());
													 Hist->fill2(AUTO, "Theta Y vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.ThetaY(), 1.0, "KER vs Phi ZX", 500, -1, 7, "Phi ZX", 1500, 0, 2, "Theta y", dir.c_str());

													 Hist->fill2(AUTO, "electron px vs Theta X", e[0]->mom.ThetaX(), e[0]->mom.x, 1.0, "electron px vs Theta x", 500, 0, 4, "Theta X", 1500, 0, 2, "electron px", dir.c_str());
													 Hist->fill2(AUTO, "electron py vs Theta y", e[0]->mom.ThetaY(), e[0]->mom.y, 1.0, "electron py vs Theta y", 500, 0, 4, "Theta y", 1500, 0, 2, "electron py", dir.c_str());
													 Hist->fill2(AUTO, "electron pz vs Theta z", e[0]->mom.Theta(), e[0]->mom.z, 1.0, "electron pz vs Theta z", 500, 0, 4, "Theta z", 1500, 0, 2, "electron pz", dir.c_str());


													 Hist->fill2(AUTO, "electron px vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.x, 1.0, "electron px vs Phi YZ", 500, 0, 4, "Phi YZ", 1500, 0, 2, "electron px", dir.c_str());
													 Hist->fill2(AUTO, "electron py vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.y, 1.0, "electron py vs Phi ZX", 500, 0, 4, "Phi ZX", 1500, 0, 2, "electron py", dir.c_str());
													 Hist->fill2(AUTO, "electron pz vs Phi XY", e[0]->mom.Phi(), e[0]->mom.z, 1.0, "electron pz vs Phi XY", 500, 0, 4, "Phi XY", 1500, 0, 2, "electron pz", dir.c_str());

													 */
								 Hist->fill2(AUTO, "KER vs recoil Theta X", r[0]->mom.ThetaX(), tiny_ker, 1.0, "KER vs recoil Theta X", 150, 0, PI, "Theta X", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Theta Y", r[0]->mom.ThetaY(), tiny_ker, 1.0, "KER vs recoil Theta Y", 150, 0, PI, "Theta Y", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Theta Z", r[0]->mom.Theta(), tiny_ker, 1.0, "KER vs recoil Theta Z", 150, 0, PI, "Theta Z", 400, .3, 1.1, "KER", dir.c_str());

								 Hist->fill2(AUTO, "KER vs recoil Phi XY", r[0]->mom.Phi(), tiny_ker, 1.0, "KER vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Phi YZ", r[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Phi ZX", r[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .3, 1.1, "KER", dir.c_str());

								 Hist->fill2(AUTO, "Electron energy vs Theta X", e[0]->mom.ThetaX(), e[0]->energy(), 1.0, "Electron energy vs Theta X", 150, 0, PI, "Theta X", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Theta Y", e[0]->mom.ThetaY(), e[0]->energy(), 1.0, "Electron energy vs Theta Y", 150, 0, PI, "Theta Y", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Theta Z", e[0]->mom.Theta(), e[0]->energy(), 1.0, "Electron energy vs Theta Z", 150, 0, PI, "Theta Z", 400, .5, 1.4, "Electron energy", dir.c_str());

								 Hist->fill2(AUTO, "Electron energy vs Phi XY", e[0]->mom.Phi(), e[0]->energy(), 1.0, "Electron energy vs Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->energy(), 1.0, "Electron energy vs Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Phi ZX", e[0]->mom.PhiZX(), e[0]->energy(), 1.0, "Electron energy vs Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .5, 1.4, "Electron energy", dir.c_str());




								 /* Hist->fill2(AUTO, "PXY vs recoil Phi XY", r[0]->mom.Phi(), tinyPRXY, 1.0, "PXY vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, 10, "PXY", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs recoil Phi YZ", r[0]->mom.PhiYZ(), tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PZX vs recoil Phi ZX", r[0]->mom.PhiZX(), tinyPRXZ, 1.0, "PZX vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, 10, "PZX", dir.c_str());

								  Hist->fill2(AUTO, "PXY vs electron Phi XY", e[0]->mom.Phi(), tinyPEXZ, 1.0, "PXY vs electron Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, .4, "PXY", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs electron Phi YZ", e[0]->mom.PhiYZ(), tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PZX vs electron Phi ZX", e[0]->mom.PhiZX(), tinyPEXZ, 1.0, "PZX vs electron Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, .4, "PZX", dir.c_str());


								  Hist->fill2(AUTO, "PYZ vs electron cos Phi YZ", tinyPhiEYZ, tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs recoil cos Phi YZ", tinyPhiRYZ, tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
								 */
								 /*{
									 dir += "/TinyAngles";

									 Hist->fill2(AUTO, "KER vs TinyTheta X", tinyThetaX, tiny_ker, 1.0, "KER vs Theta X", 500, 0, 2 * PI, "Theta X", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyTheta Y", tinyThetaY, tiny_ker, 1.0, "KER vs Theta Y", 500, 0, 2 * PI, "Theta Y", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyTheta Z", tinyThetaZ, tiny_ker, 1.0, "KER vs Theta Z", 500, 0, 2 * PI, "Theta Z", 1500, 0, 2, "KER", dir.c_str());

									 Hist->fill2(AUTO, "KER vs Cos TinyTheta X", cos(tinyThetaX), tiny_ker, 1.0, "KER vs Cos Theta X", 500, -1, 1, "Cos Theta X", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Cos TinyTheta Y", cos(tinyThetaY), tiny_ker, 1.0, "KER vs Cos Theta Y", 500, -1, 1, "Cos Theta Y", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Cos TinyTheta Z", cos(tinyThetaZ), tiny_ker, 1.0, "KER vs Cos Theta Z", 500, -1, 1, "Cos Theta Z", 1500, 0, 2, "KER", dir.c_str());


									 Hist->fill2(AUTO, "KER vs Phi XY", e[0]->mom.Phi(), tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Phi YZ", e[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs Phi YZ", 500, 0, 2 * PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Phi ZX", e[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs Phi ZX", 500, 0, 2 * PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());

									 Hist->fill2(AUTO, "KER vs TinyPhi XY", tinyPhiXY, tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyPhi YZ", tinyPhiYZ, tiny_ker, 1.0, "KER vs Phi YZ", 500, -PI, PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyPhi ZX", tinyPhiZX, tiny_ker, 1.0, "KER vs Phi ZX", 500, -PI, PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());
								 }
								 */




								 dir = reaction_dir;
								 dir += "/TinyTestH2->Hp+e-";

							 }
							 dir += "/v=11";

							 Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
							 Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 1500, 0, 2, "KER", 1500, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER bigbin", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 200, 0, 2, "KER", 160, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 801, 0., 10., "rec p (au)", 801, 0, 5, "elec p (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 501, 0., 5, "rec KE eV", 591, 0, 5, "elec KE eV", dir.c_str());
							 Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
							 Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
							 Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
							 Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine Etime vs TOF", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (Methods < 7)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, 38.20, 71.18, "TOF (ns)" "time (ns)", dir.c_str());
							 Hist->fill1(AUTO, "Number of electron hits", evt->e.num_hits, 1.0, "Number Electron Hits", 10, 0, 11, "", dir.c_str());
							 Hist->fill1(AUTO, "Number of recoil hits", evt->r.num_hits, 1.0, "Number Recoil Hits", 10, 0, 11, "", dir.c_str());
							 Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
							 Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
							 Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (Methods < 7)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (Methods < 7)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
							 Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
							 Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom x", -r[0]->mom.x - e[0]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom y", -r[0]->mom.y - e[0]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom z", -r[0]->mom.z - e[0]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());

							 Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
							 Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
							 Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());

							 dir += "/Tiny MFPAD";

							 if (cos(r[0]->mom.Theta()) < -.7 || cos(r[0]->mom.Theta()) > .7)
							 {
								 dir += "/Tiny MFPAD Theta Z cut";


								 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
								 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 51, -1., 1., "MFPAD", 51, 0, PI, "theta z", dir.c_str());
								 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 if (tiny_mfpad < 0) {
									 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z (Ch)", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 }
								 if (tiny_mfpad > 0) {
									 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z (Cp)", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 }

							 }

							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";
							 dir += "/v=11";

							 dir += "/Tiny MFPAD";

							 {if (getasypar == 1) {
								 if (tiny_mfpad > asyparthreshold) {
									 cp11 = cp11 + 1;
								 }

								 if (tiny_mfpad < -asyparthreshold) {
									 ch11 = ch11 + 1;
								 }

								 asypar11 = (cp11 - ch11) / (cp11 + ch11);

								 // cout << " Asypar" << asypar;
								  //cout << " Cp" << cp;
								  //cout << " Ch" << ch;
							 }
							 Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
							 Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 1000, 0., 15, "eV", dir.c_str());

							 Hist->fill1(AUTO, "MFPAD tiny 360", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "MFPAD tiny 180", tiny_mfpad, 1.0, "MFPAD", 180, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


							 Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());
							 }
							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";
						 }

						 //v=12
						 recpmaggatelow = 7.2;
						 recpmaggatehigh = 8.05;
						 elecpmaggatelow = .226;
						 elecpmaggatehigh = .245;
						 elecEcenter = .180;

						 kercenter = .847;
						 ekerradius = .07;
						 if (sqrt(pow(tiny_ker - kercenter, 2) + pow(e[0]->energy() - elecEcenter, 2)) < ekerradius) {
							 dir += "/v=12";

							 Hist->fill2(AUTO, "Recoil Theta Z vs MFPAD", tiny_mfpad, r[0]->mom.Theta(), 1.0, "Recoil Theta Z vs MFPAD", 160, -1., 1., "MFPAD", 160, 0, PI, "Theta Z", dir.c_str());
							 Hist->fill1(AUTO, "Recoil Theta Z", r[0]->mom.Theta(), 1.0, "Recoil Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Theta Z", e[0]->mom.Theta(), 1.0, "Electron Theta Z", 36, 0, PI, "Theta Z", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Electron Cos(Theta Z)", cos(e[0]->mom.Theta()), 1.0, "Electron Cos(Theta Z)", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Theta Z", tiny_mfpad, e[0]->mom.Theta(), 1.0, "MFPAD vs Electron Theta Z", 160, -1., 1., "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Electron Cos Theta Z", tiny_mfpad, cos(e[0]->mom.Theta()), 1.0, "MFPAD vs Electron Cos Theta", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill1(AUTO, "E Momentum magnitude", sqrt(pow(e[0]->mom.x, 2) + pow(e[0]->mom.y, 2) + pow(e[0]->mom.z, 2)), 1.0, "Electron Momentum magnitude", 100, 0, 1, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "R Momentum magnitude", sqrt(pow(r[0]->mom.x, 2) + pow(r[0]->mom.y, 2) + pow(r[0]->mom.z, 2)), 1.0, "Recoil Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "CM R Momentum magnitude", sqrt(pow(tinycmrec.x, 2) + pow(tinycmrec.y, 2) + pow(tinycmrec.z, 2)), 1.0, "Recoil CM Momentum magnitude", 100, 0, 10, "Momentum", dir.c_str());
							 Hist->fill1(AUTO, "Cos CM Recoil theta z", cos(tinycmrec.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh

							 Hist->fill2(AUTO, "MFPAD vs Recoil Phi ZX", tiny_mfpad, r[0]->mom.PhiZX(), 1.0, "MFPAD vs Recoil Phi ZX", 160, -1., 1., "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Phi ZX", tiny_mfpad, cos(r[0]->mom.PhiZX()), 1.0, "MFPAD vs Recoil Cos Phi ZX", 160, -1., 1., "MFPAD", 160, -1, 1, "cos theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Theta z vs Recoil Theta Z", e[0]->mom.Theta(), r[0]->mom.Theta(), 1.0, "Electron Theta z vs Recoil Theta Z", 160, 0., PI, "MFPAD", 160, 0, PI, "theta z", dir.c_str());
							 Hist->fill2(AUTO, "Electron Phi ZX vs Recoil Phi ZX", e[0]->mom.PhiZX(), r[0]->mom.PhiZX(), 1.0, "Electron Phi ZX vs Recoil Phi ZX", 160, 0, 2 * PI, "MFPAD", 160, 0, 2 * PI, "theta z", dir.c_str());
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Electron theta z", cos(e[0]->mom.Theta()), 1.0, "Cos Electron theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "Cos Recoil theta z", cos(r[0]->mom.Theta()), 1.0, "Cos Recoil theta z", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh



							 {//Momentum Angle stuff
								 dir += "/Angle stuff";

								 Hist->fill2(AUTO, "elec px vs py", e[0]->mom.x, e[0]->mom.y, 1.0, "elec px vs py", 400, -.35, .35, "px", 400, -.35, .35, "py", dir.c_str());
								 Hist->fill2(AUTO, "elec pz vs py", e[0]->mom.z, e[0]->mom.y, 1.0, "elec pz vs py", 400, -.35, .35, "pz", 400, -.35, .35, "py", dir.c_str());
								 Hist->fill2(AUTO, "elec px vs pz", e[0]->mom.x, e[0]->mom.z, 1.0, "elec px vs pz", 400, -.35, .35, "px", 400, -.35, .35, "pz", dir.c_str());

								 Hist->fill2(AUTO, "rec px vs py", r[0]->mom.x, r[0]->mom.y, 1.0, "Rec px vs py", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "py", dir.c_str());
								 Hist->fill2(AUTO, "rec pz vs py", r[0]->mom.z, r[0]->mom.y, 1.0, "Rec pz vs py", 400, -8.75, 8.75, "pz", 400, -8.75, 8.75, "py", dir.c_str());
								 Hist->fill2(AUTO, "rec px vs pz", r[0]->mom.x, r[0]->mom.z, 1.0, "Rec px vs pz", 400, -8.75, 8.75, "px", 400, -8.75, 8.75, "pz", dir.c_str());




								 /*					Hist->fill2(AUTO, "Theta Z vs Phi XY", e[0]->mom.Phi(), e[0]->mom.Theta(), 1.0, "KER vs Phi XY", 500, -4, 4, "Phi XY", 1500, 0, 2, "Theta z", dir.c_str());
													 Hist->fill2(AUTO, "Theta X vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.ThetaX(), 1.0, "KER vs Phi YZ", 500, -1, 7, "Phi YZ", 1500, 0, 2, "Theta X", dir.c_str());
													 Hist->fill2(AUTO, "Theta Y vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.ThetaY(), 1.0, "KER vs Phi ZX", 500, -1, 7, "Phi ZX", 1500, 0, 2, "Theta y", dir.c_str());

													 Hist->fill2(AUTO, "electron px vs Theta X", e[0]->mom.ThetaX(), e[0]->mom.x, 1.0, "electron px vs Theta x", 500, 0, 4, "Theta X", 1500, 0, 2, "electron px", dir.c_str());
													 Hist->fill2(AUTO, "electron py vs Theta y", e[0]->mom.ThetaY(), e[0]->mom.y, 1.0, "electron py vs Theta y", 500, 0, 4, "Theta y", 1500, 0, 2, "electron py", dir.c_str());
													 Hist->fill2(AUTO, "electron pz vs Theta z", e[0]->mom.Theta(), e[0]->mom.z, 1.0, "electron pz vs Theta z", 500, 0, 4, "Theta z", 1500, 0, 2, "electron pz", dir.c_str());


													 Hist->fill2(AUTO, "electron px vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->mom.x, 1.0, "electron px vs Phi YZ", 500, 0, 4, "Phi YZ", 1500, 0, 2, "electron px", dir.c_str());
													 Hist->fill2(AUTO, "electron py vs Phi ZX", e[0]->mom.PhiZX(), e[0]->mom.y, 1.0, "electron py vs Phi ZX", 500, 0, 4, "Phi ZX", 1500, 0, 2, "electron py", dir.c_str());
													 Hist->fill2(AUTO, "electron pz vs Phi XY", e[0]->mom.Phi(), e[0]->mom.z, 1.0, "electron pz vs Phi XY", 500, 0, 4, "Phi XY", 1500, 0, 2, "electron pz", dir.c_str());

													 */
								 Hist->fill2(AUTO, "KER vs recoil Theta X", r[0]->mom.ThetaX(), tiny_ker, 1.0, "KER vs recoil Theta X", 150, 0, PI, "Theta X", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Theta Y", r[0]->mom.ThetaY(), tiny_ker, 1.0, "KER vs recoil Theta Y", 150, 0, PI, "Theta Y", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Theta Z", r[0]->mom.Theta(), tiny_ker, 1.0, "KER vs recoil Theta Z", 150, 0, PI, "Theta Z", 400, .3, 1.1, "KER", dir.c_str());

								 Hist->fill2(AUTO, "KER vs recoil Phi XY", r[0]->mom.Phi(), tiny_ker, 1.0, "KER vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Phi YZ", r[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .3, 1.1, "KER", dir.c_str());
								 Hist->fill2(AUTO, "KER vs recoil Phi ZX", r[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .3, 1.1, "KER", dir.c_str());

								 Hist->fill2(AUTO, "Electron energy vs Theta X", e[0]->mom.ThetaX(), e[0]->energy(), 1.0, "Electron energy vs Theta X", 150, 0, PI, "Theta X", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Theta Y", e[0]->mom.ThetaY(), e[0]->energy(), 1.0, "Electron energy vs Theta Y", 150, 0, PI, "Theta Y", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Theta Z", e[0]->mom.Theta(), e[0]->energy(), 1.0, "Electron energy vs Theta Z", 150, 0, PI, "Theta Z", 400, .5, 1.4, "Electron energy", dir.c_str());

								 Hist->fill2(AUTO, "Electron energy vs Phi XY", e[0]->mom.Phi(), e[0]->energy(), 1.0, "Electron energy vs Phi XY", 150, 0, 2 * PI, "Phi XY", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Phi YZ", e[0]->mom.PhiYZ(), e[0]->energy(), 1.0, "Electron energy vs Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, .5, 1.4, "Electron energy", dir.c_str());
								 Hist->fill2(AUTO, "Electron energy vs Phi ZX", e[0]->mom.PhiZX(), e[0]->energy(), 1.0, "Electron energy vs Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, .5, 1.4, "Electron energy", dir.c_str());




								 /* Hist->fill2(AUTO, "PXY vs recoil Phi XY", r[0]->mom.Phi(), tinyPRXY, 1.0, "PXY vs recoil Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, 10, "PXY", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs recoil Phi YZ", r[0]->mom.PhiYZ(), tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PZX vs recoil Phi ZX", r[0]->mom.PhiZX(), tinyPRXZ, 1.0, "PZX vs recoil Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, 10, "PZX", dir.c_str());

								  Hist->fill2(AUTO, "PXY vs electron Phi XY", e[0]->mom.Phi(), tinyPEXZ, 1.0, "PXY vs electron Phi XY", 150, 0, 2 * PI, "Phi XY", 400, 0, .4, "PXY", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs electron Phi YZ", e[0]->mom.PhiYZ(), tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PZX vs electron Phi ZX", e[0]->mom.PhiZX(), tinyPEXZ, 1.0, "PZX vs electron Phi ZX", 150, 0, 2 * PI, "Phi ZX", 400, 0, .4, "PZX", dir.c_str());


								  Hist->fill2(AUTO, "PYZ vs electron cos Phi YZ", tinyPhiEYZ, tinyPEZY, 1.0, "PYZ vs electron Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, .4, "PYZ", dir.c_str());
								  Hist->fill2(AUTO, "PYZ vs recoil cos Phi YZ", tinyPhiRYZ, tinyPRZY, 1.0, "PYZ vs recoil Phi YZ", 150, 0, 2 * PI, "Phi YZ", 400, 0, 10, "PYZ", dir.c_str());
								 */
								 /*{
									 dir += "/TinyAngles";

									 Hist->fill2(AUTO, "KER vs TinyTheta X", tinyThetaX, tiny_ker, 1.0, "KER vs Theta X", 500, 0, 2 * PI, "Theta X", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyTheta Y", tinyThetaY, tiny_ker, 1.0, "KER vs Theta Y", 500, 0, 2 * PI, "Theta Y", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyTheta Z", tinyThetaZ, tiny_ker, 1.0, "KER vs Theta Z", 500, 0, 2 * PI, "Theta Z", 1500, 0, 2, "KER", dir.c_str());

									 Hist->fill2(AUTO, "KER vs Cos TinyTheta X", cos(tinyThetaX), tiny_ker, 1.0, "KER vs Cos Theta X", 500, -1, 1, "Cos Theta X", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Cos TinyTheta Y", cos(tinyThetaY), tiny_ker, 1.0, "KER vs Cos Theta Y", 500, -1, 1, "Cos Theta Y", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Cos TinyTheta Z", cos(tinyThetaZ), tiny_ker, 1.0, "KER vs Cos Theta Z", 500, -1, 1, "Cos Theta Z", 1500, 0, 2, "KER", dir.c_str());


									 Hist->fill2(AUTO, "KER vs Phi XY", e[0]->mom.Phi(), tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Phi YZ", e[0]->mom.PhiYZ(), tiny_ker, 1.0, "KER vs Phi YZ", 500, 0, 2 * PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs Phi ZX", e[0]->mom.PhiZX(), tiny_ker, 1.0, "KER vs Phi ZX", 500, 0, 2 * PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());

									 Hist->fill2(AUTO, "KER vs TinyPhi XY", tinyPhiXY, tiny_ker, 1.0, "KER vs Phi XY", 500, -PI, PI, "Phi XY", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyPhi YZ", tinyPhiYZ, tiny_ker, 1.0, "KER vs Phi YZ", 500, -PI, PI, "Phi YZ", 1500, 0, 2, "KER", dir.c_str());
									 Hist->fill2(AUTO, "KER vs TinyPhi ZX", tinyPhiZX, tiny_ker, 1.0, "KER vs Phi ZX", 500, -PI, PI, "Phi ZX", 1500, 0, 2, "KER", dir.c_str());
								 }
								 */




								 dir = reaction_dir;
								 dir += "/TinyTestH2->Hp+e-";

							 }
							 dir += "/v=12";

							 Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
							 Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 1500, 0, 2, "KER", 1500, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER 375 x 375", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 375, 0, 2, "KER", 375, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "Electron energy vs KER bigbin", tiny_ker, e[0]->energy(), 1.0, "Electron energy vs KER", 200, 0, 2, "KER", 160, 0, 1.6, "Electron energy", dir.c_str());
							 Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 801, 0., 10., "rec p (au)", 801, 0, 5, "elec p (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 501, 0., 5, "rec KE eV", 591, 0, 5, "elec KE eV", dir.c_str());
							 Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
							 Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
							 Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
							 Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
							 Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine Etime vs TOF", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (Methods < 7)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (Methods < 7)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, 38.20, 71.18, "TOF (ns)" "time (ns)", dir.c_str());
							 Hist->fill1(AUTO, "Number of electron hits", evt->e.num_hits, 1.0, "Number Electron Hits", 10, 0, 11, "", dir.c_str());
							 Hist->fill1(AUTO, "Number of recoil hits", evt->r.num_hits, 1.0, "Number Recoil Hits", 10, 0, 11, "", dir.c_str());
							 Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
							 Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
							 Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (Methods < 7)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
							 Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (Methods < 7)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
							 Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -2, 2, "p au", dir.c_str());
							 Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
							 Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
							 Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom x", -r[0]->mom.x - e[0]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom y", -r[0]->mom.y - e[0]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "tiny rec 2 mom z", -r[0]->mom.z - e[0]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -8, 8, "p au", dir.c_str());
							 Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -8, 8, "p au", dir.c_str());

							 Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
							 Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
							 Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());

							 dir += "/Tiny MFPAD";

							 if (cos(r[0]->mom.Theta()) < -.7 || cos(r[0]->mom.Theta()) > .7)
							 {
								 dir += "/Tiny MFPAD Theta Z cut";


								 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
								 Hist->fill2(AUTO, "MFPAD vs Recoil Theta Z", tiny_mfpad, r[0]->mom.Theta(), 1.0, "MFPAD vs Recoil Theta Z", 51, -1., 1., "MFPAD", 51, 0, PI, "theta z", dir.c_str());
								 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 if (tiny_mfpad < 0) {
									 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z (Ch)", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 }
								 if (tiny_mfpad > 0) {
									 Hist->fill2(AUTO, "MFPAD vs Recoil Cos Theta Z (Cp)", tiny_mfpad, cos(r[0]->mom.Theta()), 1.0, "MFPAD vs Recoil Cos Theta Z", 51, -1., 1., "MFPAD", 51, -1, 1, "cos theta z", dir.c_str());
								 }

							 }

							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";
							 dir += "/v=12";

							 dir += "/Tiny MFPAD";


							 {if (getasypar == 1) {
								 if (tiny_mfpad > asyparthreshold) {
									 cp12 = cp12 + 1;
								 }

								 if (tiny_mfpad < -asyparthreshold) {
									 ch12 = ch12 + 1;
								 }

								 asypar12 = (cp12 - ch12) / (cp12 + ch12);

								 // cout << " Asypar" << asypar;
								  //cout << " Cp" << cp;
								  //cout << " Ch" << ch;

								 ofstream myfile;
								 myfile.open("asyparvib.csv");


								 myfile << "Cp7," << cp7;
								 myfile << ",Ch7," << ch7;

								 myfile << ",Cp8," << cp8;
								 myfile << ",Ch8," << ch8;


								 myfile << ",Cp9," << cp9;
								 myfile << ",Ch9," << ch9;

								 myfile << ",Cp10," << cp10;
								 myfile << ",Ch10," << ch10;

								 myfile << ",Cp11," << cp11;
								 myfile << ",Ch11," << ch11;

								 myfile << ",Cp12," << cp12;
								 myfile << ",Ch12," << ch12;

								 myfile.close();
							 }
							 Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
							 Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 1000, 0., 15, "eV", dir.c_str());

							 Hist->fill1(AUTO, "MFPAD tiny 360", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "MFPAD tiny 180", tiny_mfpad, 1.0, "MFPAD", 180, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh
							 Hist->fill1(AUTO, "MFPAD tiny 36", tiny_mfpad, 1.0, "MFPAD", 36, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


							 Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
							 Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());
							 }
							 dir = reaction_dir;
							 dir += "/TinyTestH2->Hp+e-";
						 }

					 }
					 }

					 }




				}

		//He -> He+ e-
		if (ID == 7) {//Tiny using tag from presort 
					//Since default relative momentum, KER, and MFPAD all hate me and refuse to work
					double tinymom_relx = (r[0]->mom.x) / 2.0;
					double tinymom_rely = (r[0]->mom.y) / 2.0;
					double tinymom_relz = (r[0]->mom.z) / 2.0;
					double tinymom_relmag = sqrt(pow(tinymom_relx, 2) + pow(tinymom_rely, 2) + pow(tinymom_relz, 2));
					double tinyreducded_mass = r[0]->raw.m * MASSAU;
					double tiny_ker = (tinymom_relmag * tinymom_relmag / (2.0 * tinyreducded_mass))*EVAU;
					double tiny_mfpad = cos(e[0]->mom.Angle(r[0]->mom));
					double tinyKErec = pow(r[0]->mom.Mag(), 2) / (2 * r[0]->raw.m*MASSAU) *EVAU;
					double tinyKEelec = pow(e[0]->mom.Mag(), 2) / (2 * e[0]->raw.m*MASSAU) *EVAU;
					double tinyKE = tinyKErec + tinyKEelec;

					double etofmin = 0;
					double etofmax = 200;
					double rtofmin = 4900;
					double rtofmax = 5100;

					dir = reaction_dir;
					dir += "/TinyTestHe->He+e-";


					dir += "/All Methods";
					Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
					Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 2011, -1., 20., "rec p (au)", 2011, -1, 20., "elec p (au)", dir.c_str());
					Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 2011, -1., 100., "rec KE eV", 2011, -1, 100., "elec KE eV", dir.c_str());
					Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
					Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
					Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine TOF vs Etime", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (all methods)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (all methods)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (all methods)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", dir.c_str());
					Hist->fill1(AUTO, "Number of hits", evt->e.num_hits, 1.0, "Number Electron Hits (all methods)", 10, 0, 11, "", dir.c_str());
					Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
					Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (all methods)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (all methods)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
					Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum x", r[0]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum y", r[0]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum z", r[0]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
					Hist->fill1(AUTO, "psum rec x", r[0]->mom.x + r[1]->mom.x, 1.0, "psum x (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec y", r[0]->mom.y + r[1]->mom.y, 1.0, "psum y (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec z", r[0]->mom.z + r[1]->mom.z, 1.0, "psum z (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());


					dir += "/Tiny MFPAD";
					Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
					Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 2000, 0., 15, "eV", dir.c_str());

					Hist->fill1(AUTO, "MFPAD tiny", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


					Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
					Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());


					dir = reaction_dir;
					dir += "/TinyTestHe->He+e-";








				}

		//D2 -> D2+ e-
		if (ID == 12) {//Tiny using tag from presort 
					//Since default relative momentum, KER, and MFPAD all hate me and refuse to work
					double tinymom_relx = (r[0]->mom.x) / 2.0;
					double tinymom_rely = (r[0]->mom.y) / 2.0;
					double tinymom_relz = (r[0]->mom.z) / 2.0;
					double tinymom_relmag = sqrt(pow(tinymom_relx, 2) + pow(tinymom_rely, 2) + pow(tinymom_relz, 2));
					double tinyreducded_mass = r[0]->raw.m * MASSAU;
					double tiny_ker = (tinymom_relmag * tinymom_relmag / (2.0 * tinyreducded_mass))*EVAU;
					double tiny_mfpad = cos(e[0]->mom.Angle(r[0]->mom));
					double tinyKErec = pow(r[0]->mom.Mag(), 2) / (2 * r[0]->raw.m*MASSAU) *EVAU;
					double tinyKEelec = pow(e[0]->mom.Mag(), 2) / (2 * e[0]->raw.m*MASSAU) *EVAU;
					double tinyKE = tinyKErec + tinyKEelec;

					double etofmin = 0;
					double etofmax = 200;
					double rtofmin = 3750;
					double rtofmax = 3950;



					dir = reaction_dir;
					dir += "/TinyTestD2->D2+e-";


					dir += "/All Methods";
					Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
					Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 2011, -1., 20., "rec p (au)", 2011, -1, 20., "elec p (au)", dir.c_str());
					Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 2011, -1., 100., "rec KE eV", 2011, -1, 100., "elec KE eV", dir.c_str());
					Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
					Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
					Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine TOF vs Etime", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (all methods)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (all methods)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (all methods)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", dir.c_str());
					Hist->fill1(AUTO, "Number of hits", evt->e.num_hits, 1.0, "Number Electron Hits (all methods)", 10, 0, 11, "", dir.c_str());
					Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
					Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (all methods)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (all methods)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
					Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
					Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
					Hist->fill2(AUTO, "Rec 2 position fine", r[1]->raw.data.x, r[1]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec x", r[0]->mom.x + r[1]->mom.x, 1.0, "psum x (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec y", r[0]->mom.y + r[1]->mom.y, 1.0, "psum y (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec z", r[0]->mom.z + r[1]->mom.z, 1.0, "psum z (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());


					dir += "/Tiny MFPAD";
					Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
					Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 2000, 0., 15, "eV", dir.c_str());

					Hist->fill1(AUTO, "MFPAD tiny", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


					Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
					Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());


					dir = reaction_dir;
					dir += "/TinyTestD2->D2+e-";










				}

		//D2 -> D D+ e-
		if (ID == 13) {//Tiny using tag from presort 
							//Since default relative momentum, KER, and MFPAD all hate me and refuse to work
					double tinymom_relx = (r[0]->mom.x) / 2.0;
					double tinymom_rely = (r[0]->mom.y) / 2.0;
					double tinymom_relz = (r[0]->mom.z) / 2.0;
					double tinymom_relmag = sqrt(pow(tinymom_relx, 2) + pow(tinymom_rely, 2) + pow(tinymom_relz, 2));
					double tinyreducded_mass = r[0]->raw.m * MASSAU;
					double tiny_ker = (tinymom_relmag * tinymom_relmag / (2.0 * tinyreducded_mass))*EVAU;
					double tiny_mfpad = cos(e[0]->mom.Angle(r[0]->mom));
					double tinyKErec = pow(r[0]->mom.Mag(), 2) / (2 * r[0]->raw.m*MASSAU) *EVAU;
					double tinyKEelec = pow(e[0]->mom.Mag(), 2) / (2 * e[0]->raw.m*MASSAU) *EVAU;
					double tinyKE = tinyKErec + tinyKEelec;

					double etofmin = 0;
					double etofmax = 200;
					double rtofmin = 2600;
					double rtofmax = 2800;

					dir = reaction_dir;
					dir += "/TinyTestD2->DD+e-";


					dir += "/All Methods";
					Hist->fill1(AUTO, "Recoil TOF", r[0]->raw.data.tof, 1.0, "Recoil TOF (all methods)", 2000, rtofmin, rtofmax, "ns", dir.c_str());
					Hist->fill1(AUTO, "Elec TOF", e[0]->raw.data.tof, 1.0, "Elec TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					Hist->fill2(AUTO, "elec p mag vs rec p mag", r[0]->mom.Mag(), e[0]->mom.Mag(), 1.0, "elec p mag vs rec p mag", 2011, -1., 20., "rec p (au)", 2011, -1, 20., "elec p (au)", dir.c_str());
					Hist->fill2(AUTO, "elec KE vs rec KE", tinyKErec, tinyKEelec, 1.0, "elec KE vs rec KE", 2011, -1., 100., "rec KE eV", 2011, -1, 100., "elec KE eV", dir.c_str());
					Hist->fill2(AUTO, "elec px vs rec px", r[0]->mom.x, e[0]->mom.x, 1.0, "elec px vs rec px", 201, -4., 4., "rec px (au)", 201, -4, 4., "elec px (au)", dir.c_str());
					Hist->fill2(AUTO, "elec py vs rec py", r[0]->mom.y, e[0]->mom.y, 1.0, "elec py vs rec py", 201, -4., 4., "rec py (au)", 201, -4, 4., "elec py (au)", dir.c_str());
					Hist->fill2(AUTO, "elec pz vs rec pz", r[0]->mom.z, e[0]->mom.z, 1.0, "elec pz vs rec pz", 201, -4., 4., "rec pz (au)", 201, -4, 4., "elec pz (au)", dir.c_str());
					Hist->fill1(AUTO, "Electron Method", e[0]->raw.method, 1.0, "Electron reconstruction method", 21, 0, 20, "", dir.c_str());
					Hist->fill2(AUTO, "R position fine", r[0]->raw.data.x, r[0]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill2(AUTO, "E position fine", e[0]->raw.data.x, e[0]->raw.data.y, 1.0, "Electron Hit Position (all methods)", 401, -50., 50., "x", 401, -50, 50., "y", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine TOF vs Etime", e[0]->raw.data.time, e[0]->raw.data.tof, 1.0, "Electron TOF vs Electron Time (all methods)", 100, -1985, -1885, "time (ns)", 100, etofmin, etofmax, "TOF (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine Etime [1] vs  Etime [0]", e[0]->raw.data.time, e[1]->raw.data.time, 1.0, "Etime [1] vs  Etime [0] (all methods)", 100, -1985, -1885, "time (ns)", 100, -1985, -1885, "time (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine ETOF [1] vs  ETOF [0]", e[0]->raw.data.tof, e[1]->raw.data.tof, 1.0, "ETOF [1] vs  ETOF [0] (all methods)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", 100, etofmin, etofmax, "TOF (ns)" "time (ns)", dir.c_str());
					Hist->fill1(AUTO, "Number of hits", evt->e.num_hits, 1.0, "Number Electron Hits (all methods)", 10, 0, 11, "", dir.c_str());
					Hist->fill1(AUTO, "Elec 1 Time", e[1]->raw.data.time, 1.0, "Elec 1 Time", 100, -1985, -1885, "ns", dir.c_str());
					Hist->fill1(AUTO, "Elec 1 TOF", e[1]->raw.data.tof, 1.0, "Elec 1 TOF", 600, etofmin, etofmax, "ns", dir.c_str());
					Hist->fill2(AUTO, "Rtime vs Etime", e[0]->raw.data.time, r[0]->raw.data.time, 1.0, "Rtime vs Etime (all methods)", 100, -1985, -1885, "Electron time (ns)", 200, -10, 10, "Recoil time (ns)", dir.c_str());
					Hist->fill2(AUTO, "Ultra fine  RTOF vs ETOF", e[0]->raw.data.tof, r[0]->raw.data.tof, 1.0, "RTOF vs ETOF (all methods)", 100, etofmin, etofmax, "Electron TOF (ns)", 200, rtofmin, rtofmax, "Recoil TOF (ns) ", dir.c_str());
					Hist->fill1(AUTO, "rec mom x", r[0]->mom.x, 1.0, "Recoil momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec mom y", r[0]->mom.y, 1.0, "Recoil momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec mom z", r[0]->mom.z, 1.0, "Recoil momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom x", e[0]->mom.x, 1.0, "Electron momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom y", e[0]->mom.y, 1.0, "Electron momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "elec mom z", e[0]->mom.z, 1.0, "Electron momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum x", r[0]->mom.x + r[1]->mom.x + e[0]->mom.x, 1.0, "psum x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum y", r[0]->mom.y + r[1]->mom.y + e[0]->mom.y, 1.0, "psum y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum z", r[0]->mom.z + r[1]->mom.z + e[0]->mom.z, 1.0, "psum z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "Electron mass", e[0]->raw.m, 1.0, "electron mass ", 50, 0.00025, 0.00075, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil mass1", r[0]->raw.m, 1.0, "recoil 1 mass ", 100, 0., 10, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil mass2", r[1]->raw.m, 1.0, "recoil 2 mass ", 100, 0., 10, "m amu", dir.c_str());
					Hist->fill1(AUTO, "recoil charge1", r[0]->raw.q, 1.0, "recoil 1 charge", 100, 0., 10, "q au", dir.c_str());
					Hist->fill1(AUTO, "recoil charge2", r[1]->raw.q, 1.0, "recoil 2 charge", 100, 0., 10, "q qu", dir.c_str());
					Hist->fill2(AUTO, "Rec 2 position fine", r[1]->raw.data.x, r[1]->raw.data.y, 1.0, "", 401, -80., 80., "x", 401, -80, 80., "y", dir.c_str());
					Hist->fill1(AUTO, "rec 2 mom x", r[1]->mom.x, 1.0, "Recoil 2 momentum in x", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec 2 mom y", r[1]->mom.y, 1.0, "Recoil 2 momentum in y", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "rec 2 mom z", r[1]->mom.z, 1.0, "Recoil 2 momentum in z", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec x", r[0]->mom.x + r[1]->mom.x, 1.0, "psum x (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec y", r[0]->mom.y + r[1]->mom.y, 1.0, "psum y (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill1(AUTO, "psum rec z", r[0]->mom.z + r[1]->mom.z, 1.0, "psum z (recoils only)", 1000, -10., 10, "p au", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test", r[0]->mom.x, r[0]->mom.y, 1.0, "", 100, -50., 50., "px", 100, -50, 50., "py", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 200, -10., 10., "px", 200, -10, 10., "py", dir.c_str());
					Hist->fill2(AUTO, "rec  px vs py for jet test ultra fine", r[0]->mom.x, r[0]->mom.y, 1.0, "", 400, -10., 10., "px", 400, -10, 10., "py", dir.c_str());


					dir += "/Tiny MFPAD";
					Hist->fill1(AUTO, "mom rel tiny", (tinymom_relmag), 1.0, "relative momentum magnitude", 1000, 0., 15, "", dir.c_str());
					Hist->fill1(AUTO, "KER tiny", (tiny_ker), 1.0, "KER", 2000, 0., 15, "eV", dir.c_str());

					Hist->fill1(AUTO, "MFPAD tiny", tiny_mfpad, 1.0, "MFPAD", 360, -1., 1., "Cos(theta)", dir.c_str()); // working mfpad with help from Josh


					Hist->fill2(AUTO, "ctheta_ee", e[0]->mom.Cos_Theta(), e[0]->energy(), 1.0, "cos theta vs electron energy", 36, -1., 1., "cos(theta)", 200, 0.0, 10., "electron energy [eV]", dir.c_str());
					Hist->fill2(AUTO, "MFPAD vs KER", tiny_mfpad, tiny_ker, 1.0, "MFPAD vs KER", 36, -1., 1., "cos(theta)", 100, 0.0, 15., "KER [eV]", dir.c_str());


					dir = reaction_dir;
					dir += "/TinyTestD2->DD+e-";










				}

	}
		

		}
		//*/	

